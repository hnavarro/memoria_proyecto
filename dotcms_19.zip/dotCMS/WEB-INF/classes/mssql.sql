create table ABContact (
	contactId varchar(100) not null primary key,
	userId varchar(100) not null,
	firstName varchar(100) null,
	middleName varchar(100) null,
	lastName varchar(100) null,
	nickName varchar(100) null,
	emailAddress varchar(100) null,
	homeStreet varchar(100) null,
	homeCity varchar(100) null,
	homeState varchar(100) null,
	homeZip varchar(100) null,
	homeCountry varchar(100) null,
	homePhone varchar(100) null,
	homeFax varchar(100) null,
	homeCell varchar(100) null,
	homePager varchar(100) null,
	homeTollFree varchar(100) null,
	homeEmailAddress varchar(100) null,
	businessCompany varchar(100) null,
	businessStreet varchar(100) null,
	businessCity varchar(100) null,
	businessState varchar(100) null,
	businessZip varchar(100) null,
	businessCountry varchar(100) null,
	businessPhone varchar(100) null,
	businessFax varchar(100) null,
	businessCell varchar(100) null,
	businessPager varchar(100) null,
	businessTollFree varchar(100) null,
	businessEmailAddress varchar(100) null,
	employeeNumber varchar(100) null,
	jobTitle varchar(100) null,
	jobClass varchar(100) null,
	hoursOfOperation varchar(1000) null,
	birthday datetime null,
	timeZoneId varchar(100) null,
	instantMessenger varchar(100) null,
	website varchar(100) null,
	comments varchar(1000) null
);

create table ABContacts_ABLists (
	contactId varchar(100) not null,
	listId varchar(100) not null
);

create table ABList (
	listId varchar(100) not null primary key,
	userId varchar(100) not null,
	name varchar(100) null
);

create table Address (
	addressId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	className varchar(100) null,
	classPK varchar(100) null,
	description varchar(100) null,
	street1 varchar(100) null,
	street2 varchar(100) null,
	city varchar(100) null,
	state varchar(100) null,
	zip varchar(100) null,
	country varchar(100) null,
	phone varchar(100) null,
	fax varchar(100) null,
	cell varchar(100) null,
	priority int
);

create table AdminConfig (
	configId varchar(100) not null primary key,
	companyId varchar(100) not null,
	type_ varchar(100) null,
	name varchar(100) null,
	config text null
);

create table BJEntries_BJTopics (
	entryId varchar(100) not null,
	topicId varchar(100) not null
);

create table BJEntries_BJVerses (
	entryId varchar(100) not null,
	verseId varchar(100) not null
);

create table BJEntry (
	entryId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	name varchar(100) null,
	content text null,
	versesInput varchar(1000) null
);

create table BJTopic (
	topicId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	name varchar(100) null,
	description text null
);

create table BJVerse (
	verseId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	name varchar(100) null
);

create table BlogsCategory (
	categoryId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	name varchar(100) null
);

create table BlogsComments (
	commentsId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	entryId varchar(100) null,
	content text null
);

create table BlogsEntry (
	entryId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	categoryId varchar(100) null,
	title varchar(100) null,
	content text null,
	displayDate datetime null,
	sharing bit,
	commentable bit,
	propsCount int,
	commentsCount int
);

create table BlogsLink (
	linkId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	name varchar(100) null,
	url varchar(100) null
);

create table BlogsProps (
	propsId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	entryId varchar(100) null,
	quantity int
);

create table BlogsReferer (
	entryId varchar(100) not null,
	url varchar(100) not null,
	type_ varchar(100) not null,
	quantity int,
	primary key (entryId, url, type_)
);

create table BlogsUser (
	userId varchar(100) not null primary key,
	companyId varchar(100) not null,
	entryId varchar(100) not null,
	lastPostDate datetime null
);

create table BookmarksEntry (
	entryId varchar(100) not null primary key,
	userId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	folderId varchar(100) null,
	name varchar(100) null,
	url varchar(100) null,
	comments varchar(1000) null,
	visits int
);

create table BookmarksFolder (
	folderId varchar(100) not null primary key,
	userId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	parentFolderId varchar(100) null,
	name varchar(100) null
);

create table CalEvent (
	eventId varchar(100) not null primary key,
	groupId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	title varchar(100) null,
	description varchar(1000) null,
	startDate datetime null,
	endDate datetime null,
	durationHour int,
	durationMinute int,
	allDay bit,
	timeZoneSensitive bit,
	type_ varchar(100) null,
	location varchar(100) null,
	street varchar(100) null,
	city varchar(100) null,
	state varchar(100) null,
	zip varchar(100) null,
	phone varchar(100) null,
	repeating bit,
	recurrence text null,
	remindBy varchar(100) null,
	firstReminder int,
	secondReminder int
);

create table CalTask (
	taskId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	title varchar(100) null,
	description varchar(1000) null,
	noDueDate bit,
	dueDate datetime null,
	priority int,
	status int
);

create table Company (
	companyId varchar(100) not null primary key,
	key_ text null,
	portalURL varchar(100) not null,
	homeURL varchar(100) not null,
	mx varchar(100) not null,
	name varchar(100) not null,
	shortName varchar(100) not null,
	type_ varchar(100) null,
	size_ varchar(100) null,
	street varchar(100) null,
	city varchar(100) null,
	state varchar(100) null,
	zip varchar(100) null,
	phone varchar(100) null,
	fax varchar(100) null,
	emailAddress varchar(100) null,
	authType varchar(100) null,
	autoLogin bit,
	strangers bit
);

create table Counter (
	name varchar(100) not null primary key,
	currentId int
);

create table CyrusUser (
	userId varchar(100) not null primary key,
	password_ varchar(100) not null
);

create table CyrusVirtual (
	emailAddress varchar(100) not null primary key,
	userId varchar(100) not null
);

create table DLFileProfile (
	companyId varchar(100) not null,
	repositoryId varchar(100) not null,
	fileName varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	versionUserId varchar(100) not null,
	versionUserName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	readRoles varchar(100) null,
	writeRoles varchar(100) null,
	description text null,
	version float,
	size_ int,
	primary key (companyId, repositoryId, fileName)
);

create table DLFileRank (
	companyId varchar(100) not null,
	userId varchar(100) not null,
	repositoryId varchar(100) not null,
	fileName varchar(100) not null,
	createDate datetime null,
	primary key (companyId, userId, repositoryId, fileName)
);

create table DLFileVersion (
	companyId varchar(100) not null,
	repositoryId varchar(100) not null,
	fileName varchar(100) not null,
	version float not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	size_ int,
	primary key (companyId, repositoryId, fileName, version)
);

create table DLRepository (
	repositoryId varchar(100) not null primary key,
	groupId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	readRoles varchar(100) null,
	writeRoles varchar(100) null,
	name varchar(100) null,
	description varchar(1000) null,
	lastPostDate datetime null
);

create table IGFolder (
	folderId varchar(100) not null primary key,
	groupId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	parentFolderId varchar(100) null,
	name varchar(100) null
);

create table IGImage (
	imageId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	folderId varchar(100) null,
	description text null,
	height int,
	width int,
	size_ int,
	primary key (imageId, companyId)
);

create table Image (
	imageId varchar(200) not null primary key,
	text_ text not null
);

create table JournalArticle (
	articleId varchar(100) not null,
	version float not null,
	portletId varchar(100) not null,
	groupId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	title varchar(100) null,
	content text null,
	type_ varchar(100) null,
	structureId varchar(100) null,
	templateId varchar(100) null,
	displayDate datetime null,
	expirationDate datetime null,
	approved bit,
	approvedByUserId varchar(100) null,
	approvedByUserName varchar(100) null,
	primary key (articleId, version)
);

create table JournalStructure (
	structureId varchar(100) not null primary key,
	portletId varchar(100) not null,
	groupId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	name varchar(100) null,
	description varchar(1000) null,
	xsd text null
);

create table JournalTemplate (
	templateId varchar(100) not null primary key,
	portletId varchar(100) not null,
	groupId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	structureId varchar(100) null,
	name varchar(100) null,
	description varchar(1000) null,
	xsl text null,
	smallImage bit,
	smallImageURL varchar(100) null
);

create table Layer (
	layerId varchar(100) not null,
	skinId varchar(100) not null,
	href varchar(100) null,
	hrefHover varchar(100) null,
	background varchar(100) null,
	foreground varchar(100) null,
	negAlert varchar(100) null,
	posAlert varchar(100) null,
	primary key (layerId, skinId)
);

create table MailReceipt (
	receiptId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	recipientName varchar(100) null,
	recipientAddress varchar(100) null,
	subject varchar(100) null,
	sentDate datetime null,
	readCount int,
	firstReadDate datetime null,
	lastReadDate datetime null
);

create table MBMessage (
	messageId varchar(100) not null,
	topicId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	threadId varchar(100) null,
	parentMessageId varchar(100) null,
	subject varchar(100) null,
	body text null,
	attachments bit,
	anonymous bit,
	primary key (messageId, topicId)
);

create table MBMessageFlag (
	topicId varchar(100) not null,
	messageId varchar(100) not null,
	userId varchar(100) not null,
	flag varchar(100) null,
	primary key (topicId, messageId, userId)
);

create table MBThread (
	threadId varchar(100) not null primary key,
	rootMessageId varchar(100) null,
	topicId varchar(100) null,
	messageCount int,
	lastPostDate datetime null
);

create table MBTopic (
	topicId varchar(100) not null primary key,
	portletId varchar(100) not null,
	groupId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	readRoles varchar(100) null,
	writeRoles varchar(100) null,
	name varchar(100) null,
	description text null,
	lastPostDate datetime null
);

create table NetworkAddress (
	addressId varchar(100) not null primary key,
	userId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	name varchar(100) null,
	url varchar(100) null,
	comments varchar(1000) null,
	content text null,
	status int,
	lastUpdated datetime null,
	notifyBy varchar(100) null,
	interval_ int,
	active_ bit
);

create table Note (
	noteId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	className varchar(100) null,
	classPK varchar(100) null,
	content text null
);

create table PasswordTracker (
	passwordTrackerId varchar(100) not null primary key,
	userId varchar(100) not null,
	createDate datetime not null,
	password_ varchar(100) not null
);

create table PollsChoice (
	choiceId varchar(100) not null,
	questionId varchar(100) not null,
	description varchar(1000) null,
	primary key (choiceId, questionId)
);

create table PollsDisplay (
	layoutId varchar(100) not null,
	userId varchar(100) not null,
	portletId varchar(100) not null,
	questionId varchar(100) not null,
	primary key (layoutId, userId, portletId)
);

create table PollsQuestion (
	questionId varchar(100) not null primary key,
	portletId varchar(100) not null,
	groupId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	title varchar(100) null,
	description varchar(1000) null,
	expirationDate datetime null,
	lastVoteDate datetime null
);

create table PollsVote (
	questionId varchar(100) not null,
	userId varchar(100) not null,
	choiceId varchar(100) not null,
	voteDate datetime null,
	primary key (questionId, userId)
);

create table Portlet (
	portletId varchar(100) not null,
	groupId varchar(100) not null,
	companyId varchar(100) not null,
	defaultPreferences text null,
	narrow bit,
	roles varchar(1000) null,
	active_ bit,
	primary key (portletId, groupId, companyId)
);

create table PortletPreferences (
	portletId varchar(100) not null,
	userId varchar(100) not null,
	layoutId varchar(100) not null,
	preferences text null,
	primary key (portletId, userId, layoutId)
);

create table ProjFirm (
	firmId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	name varchar(100) null,
	description varchar(1000) null,
	url varchar(100) null
);

create table ProjProject (
	projectId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	firmId varchar(100) null,
	code varchar(100) null,
	name varchar(100) null,
	description varchar(1000) null
);

create table ProjTask (
	taskId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	projectId varchar(100) null,
	name varchar(100) null,
	description varchar(1000) null,
	comments text null,
	estimatedDuration int,
	estimatedEndDate datetime null,
	actualDuration int,
	actualEndDate datetime null,
	status int
);

create table ProjTime (
	timeId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	projectId varchar(100) null,
	taskId varchar(100) null,
	description varchar(1000) null,
	startDate datetime null,
	endDate datetime null
);

create table Release_ (
	releaseId varchar(100) not null primary key,
	createDate datetime null,
	modifiedDate datetime null,
	buildNumber int null,
	buildDate datetime null
);

create table Skin (
	skinId varchar(100) not null primary key,
	name varchar(100) null,
	imageId varchar(100) null,
	alphaLayerId varchar(100) null,
	alphaSkinId varchar(100) null,
	betaLayerId varchar(100) null,
	betaSkinId varchar(100) null,
	gammaLayerId varchar(100) null,
	gammaSkinId varchar(100) null,
	bgLayerId varchar(100) null,
	bgSkinId varchar(100) null
);

create table ShoppingCart (
	cartId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	itemIds varchar(1000) null,
	couponIds varchar(1000) null,
	altShipping int
);

create table ShoppingCategory (
	categoryId varchar(100) not null primary key,
	companyId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	parentCategoryId varchar(100) null,
	name varchar(100) null
);

create table ShoppingCoupon (
	couponId varchar(100) not null primary key,
	companyId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	name varchar(100) null,
	description varchar(1000) null,
	startDate datetime null,
	endDate datetime null,
	active_ bit,
	limitCategories varchar(1000) null,
	limitSkus varchar(1000) null,
	minOrder float,
	discount float,
	discountType varchar(100) null
);

create table ShoppingItem (
	itemId varchar(100) not null primary key,
	companyId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	categoryId varchar(100) null,
	sku varchar(100) null,
	name varchar(100) null,
	description varchar(1000) null,
	properties varchar(1000) null,
	supplierUserId varchar(100) null,
	fields_ bit,
	fieldsQuantities varchar(1000) null,
	minQuantity int,
	maxQuantity int,
	price float,
	discount float,
	taxable bit,
	shipping float,
	useShippingFormula bit,
	requiresShipping bit,
	stockQuantity int,
	featured_ bit,
	sale_ bit,
	smallImage bit,
	smallImageURL varchar(100) null,
	mediumImage bit,
	mediumImageURL varchar(100) null,
	largeImage bit,
	largeImageURL varchar(100) null
);

create table ShoppingItemField (
	itemFieldId varchar(100) not null primary key,
	itemId varchar(100) null,
	name varchar(100) null,
	values_ varchar(1000) null,
	description varchar(1000) null
);

create table ShoppingItemPrice (
	itemPriceId varchar(100) not null primary key,
	itemId varchar(100) null,
	minQuantity int,
	maxQuantity int,
	price float,
	discount float,
	taxable bit,
	shipping float,
	useShippingFormula bit,
	status int
);

create table ShoppingOrder (
	orderId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	tax float,
	shipping float,
	altShipping varchar(100),
	requiresShipping bit,
	couponIds varchar(1000) null,
	couponDiscount float,
	billingFirstName varchar(100) null,
	billingLastName varchar(100) null,
	billingEmailAddress varchar(100) null,
	billingCompany varchar(100) null,
	billingStreet varchar(100) null,
	billingCity varchar(100) null,
	billingState varchar(100) null,
	billingZip varchar(100) null,
	billingCountry varchar(100) null,
	billingPhone varchar(100) null,
	shipToBilling bit,
	shippingFirstName varchar(100) null,
	shippingLastName varchar(100) null,
	shippingEmailAddress varchar(100) null,
	shippingCompany varchar(100) null,
	shippingStreet varchar(100) null,
	shippingCity varchar(100) null,
	shippingState varchar(100) null,
	shippingZip varchar(100) null,
	shippingCountry varchar(100) null,
	shippingPhone varchar(100) null,
	ccName varchar(100) null,
	ccType varchar(100) null,
	ccNumber varchar(100) null,
	ccExpMonth int,
	ccExpYear int,
	ccVerNumber varchar(100) null,
	comments text null,
	ppTxnId varchar(100) null,
	ppPaymentStatus varchar(100) null,
	ppPaymentGross float,
	ppReceiverEmail varchar(100) null,
	ppPayerEmail varchar(100) null,
	sendOrderEmail bit,
	sendShippingEmail bit
);

create table ShoppingOrderItem (
	orderId varchar(100) not null,
	itemId varchar(100) not null,
	sku varchar(100) null,
	name varchar(100) null,
	description varchar(1000) null,
	properties varchar(1000) null,
	supplierUserId varchar(100) null,
	price float,
	quantity int,
	shippedDate datetime null,
	primary key (orderId, itemId)
);

create table User_ (
	userId varchar(100) not null primary key,
	companyId varchar(100) not null,
	createDate datetime null,
	password_ varchar(100) null,
	passwordEncrypted bit,
	passwordExpirationDate datetime null,
	passwordReset bit,
	firstName varchar(100) null,
	middleName varchar(100) null,
	lastName varchar(100) null,
	nickName varchar(100) null,
	male bit,
	birthday datetime null,
	emailAddress varchar(100) null,
	smsId varchar(100) null,
	aimId varchar(100) null,
	icqId varchar(100) null,
	msnId varchar(100) null,
	ymId varchar(100) null,
	favoriteActivity varchar(100) null,
	favoriteBibleVerse varchar(100) null,
	favoriteFood varchar(100) null,
	favoriteMovie varchar(100) null,
	favoriteMusic varchar(100) null,
	languageId varchar(100) null,
	timeZoneId varchar(100) null,
	skinId varchar(100) null,
	dottedSkins bit,
	roundedSkins bit,
	greeting varchar(100) null,
	resolution varchar(100) null,
	refreshRate varchar(100) null,
	layoutIds varchar(100) null,
	comments varchar(1000) null,
	loginDate datetime null,
	loginIP varchar(100) null,
	lastLoginDate datetime null,
	lastLoginIP varchar(100) null,
	failedLoginAttempts int,
	agreedToTermsOfUse bit,
	active_ bit
);

create table Users_ProjProjects (
	userId varchar(100) not null,
	projectId varchar(100) not null
);

create table Users_ProjTasks (
	userId varchar(100) not null,
	taskId varchar(100) not null
);

create table UserTracker (
	userTrackerId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	modifiedDate datetime null,
	remoteAddr varchar(100) null,
	remoteHost varchar(100) null,
	userAgent varchar(100) null
);

create table UserTrackerPath (
	userTrackerPathId varchar(100) not null primary key,
	userTrackerId varchar(100) not null,
	path varchar(1000) not null,
	pathDate datetime not null
);

create table WikiDisplay (
	layoutId varchar(100) not null,
	userId varchar(100) not null,
	portletId varchar(100) not null,
	nodeId varchar(100) not null,
	showBorders bit,
	primary key (layoutId, userId, portletId)
);

create table WikiNode (
	nodeId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	readRoles varchar(100) null,
	writeRoles varchar(100) null,
	name varchar(100) null,
	description varchar(1000) null,
	sharing bit,
	lastPostDate datetime null
);

create table WikiPage (
	nodeId varchar(100) not null,
	title varchar(100) not null,
	version float not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	content text null,
	format varchar(100) null,
	head bit,
	primary key (nodeId, title, version)
);

--
-- Global
--

insert into Counter values ('com.liferay.portal.model.Address', 10);
insert into Counter values ('com.liferay.portal.model.Group', 20);
insert into Counter values ('com.liferay.portal.model.Role', 100);
insert into Counter values ('com.liferay.portal.model.User.liferay.com', 10);
insert into Counter values ('com.liferay.portlet.imagegallery.model.IGFolder', 20);
insert into Counter values ('com.liferay.portlet.imagegallery.model.IGImage.liferay.com', 42);
insert into Counter values ('com.liferay.portlet.polls.model.PollsQuestion', 10);
insert into Counter values ('com.liferay.portlet.shopping.model.ShoppingCategory', 20);
insert into Counter values ('com.liferay.portlet.shopping.ejb.ShoppingItem', 40);
insert into Counter values ('com.liferay.portlet.wiki.model.WikiNode', 10);

--
-- Liferay, LLC
--

insert into Company (companyId, portalURL, homeURL, mx, name, shortName, type_, size_, emailAddress, authType, autoLogin, strangers) values ('liferay.com', 'localhost', 'localhost', 'liferay.com', 'Liferay, LLC', 'Liferay', 'biz', '', 'test@liferay.com', 'emailAddress', '1', '1');
update Company set street = '1220 Brea Canyon Rd.', city = 'Diamond Bar', state = 'CA', zip = '91789' where companyId = 'liferay.com';

insert into PollsDisplay (layoutId, userId, portletId, questionId) values ('1.1', 'group.1', '59', '1');
insert into PollsChoice (choiceId, questionId, description) values ('a', '1', 'Chocolate');
insert into PollsChoice (choiceId, questionId, description) values ('b', '1', 'Strawberry');
insert into PollsChoice (choiceId, questionId, description) values ('c', '1', 'Vanilla');
insert into PollsQuestion (questionId, portletId, groupId, companyId, userId, userName, createDate, modifiedDate, title, description) values ('1', '25', '-1', 'liferay.com', 'liferay.com.1', 'John Wayne', GetDate(), GetDate(), 'What is your favorite ice cream flavor?', 'What is your favorite ice cream flavor?');

insert into WikiDisplay (layoutId, userId, portletId, nodeId, showBorders) values ('1.1', 'group.1', '54', '1', '1');
insert into WikiNode (nodeId, companyId, userId, userName, createDate, modifiedDate, readRoles, writeRoles, name, description, sharing, lastPostDate) values ('1', 'liferay.com', 'liferay.com.1', 'John Wayne', GetDate(), GetDate(), 'User,' ,'User,', 'Welcome', '', '1', GetDate());
insert into WikiPage (nodeId, title, version, companyId, userId, userName, createDate, content, format, head) values ('1', 'FrontPage', 1.0, 'liferay.com', 'liferay.com.1', 'John Wayne', GetDate(), '<font class="bg" size="2">Welcome! Thank you for your interest in Liferay Enterprise Portal.<br><br>Your login is <b>test@liferay.com</b> and your password is <b>test</b>. The test user has the Administrator role.<br><br>To use the <b>Mail</b> portlet, make sure there is a mail server running on <i>localhost</i> accessible through the IMAP protocol.<br><br>The mail server must have an account with <b>liferay.com.1</b> as the user and <b>test</b> as the password.<br><br><hr><br>Is Liferay useful for your company? Tell us about it by email at <b>staff@liferay.com</b>.<br><br>We hope you enjoy our product!</font>', 'html', '1');

--
-- Default User
--

insert into User_ (userId, companyId, createDate, password_, passwordEncrypted, passwordReset, firstName, middleName, lastName, male, birthday, emailAddress, skinId, dottedSkins, roundedSkins, greeting, layoutIds, loginDate, failedLoginAttempts, agreedToTermsOfUse, active_) values ('liferay.com.default', 'default', GetDate(), 'password', '0', '0', '', '', '', '1', '19700101', 'default@liferay.com', '01', '0', '0', 'Welcome!', '', GetDate(), 0, '0', '1');

--
-- Test User
--

insert into User_ (userId, companyId, createDate, password_, passwordEncrypted, passwordReset, firstName, middleName, lastName, nickName, male, birthday, emailAddress, skinId, dottedSkins, roundedSkins, greeting, layoutIds, loginDate, failedLoginAttempts, agreedToTermsOfUse, active_) values ('liferay.com.1', 'liferay.com', GetDate(), 'test', '0', '0', 'John', '', 'Wayne', 'Duke', '1', '19700101', 'test@liferay.com', '01', '0', '1', 'Welcome John Wayne!', '1,', GetDate(), 0, '1', '1');

CREATE TABLE [dbo].[QRTZ_CALENDARS] (
  [CALENDAR_NAME] [VARCHAR] (80)  NOT NULL ,
  [CALENDAR] [IMAGE] NOT NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[QRTZ_CRON_TRIGGERS] (
  [TRIGGER_NAME] [VARCHAR] (80)  NOT NULL ,
  [TRIGGER_GROUP] [VARCHAR] (80)  NOT NULL ,
  [CRON_EXPRESSION] [VARCHAR] (80)  NOT NULL ,
  [TIME_ZONE_ID] [VARCHAR] (80) 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[QRTZ_FIRED_TRIGGERS] (
  [ENTRY_ID] [VARCHAR] (95)  NOT NULL ,
  [TRIGGER_NAME] [VARCHAR] (80)  NOT NULL ,
  [TRIGGER_GROUP] [VARCHAR] (80)  NOT NULL ,
  [IS_VOLATILE] [VARCHAR] (1)  NOT NULL ,
  [INSTANCE_NAME] [VARCHAR] (80)  NOT NULL ,
  [FIRED_TIME] [BIGINT] NOT NULL ,
  [PRIORITY] [INTEGER] NOT NULL ,
  [STATE] [VARCHAR] (16)  NOT NULL,
  [JOB_NAME] [VARCHAR] (80)  NULL ,
  [JOB_GROUP] [VARCHAR] (80)  NULL ,
  [IS_STATEFUL] [VARCHAR] (1)  NULL ,
  [REQUESTS_RECOVERY] [VARCHAR] (1)  NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[QRTZ_PAUSED_TRIGGER_GRPS] (
  [TRIGGER_GROUP] [VARCHAR] (80)  NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[QRTZ_SCHEDULER_STATE] (
  [INSTANCE_NAME] [VARCHAR] (80)  NOT NULL ,
  [LAST_CHECKIN_TIME] [BIGINT] NOT NULL ,
  [CHECKIN_INTERVAL] [BIGINT] NOT NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[QRTZ_LOCKS] (
  [LOCK_NAME] [VARCHAR] (40)  NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[QRTZ_JOB_DETAILS] (
  [JOB_NAME] [VARCHAR] (80)  NOT NULL ,
  [JOB_GROUP] [VARCHAR] (80)  NOT NULL ,
  [DESCRIPTION] [VARCHAR] (120) NULL ,
  [JOB_CLASS_NAME] [VARCHAR] (128)  NOT NULL ,
  [IS_DURABLE] [VARCHAR] (1)  NOT NULL ,
  [IS_VOLATILE] [VARCHAR] (1)  NOT NULL ,
  [IS_STATEFUL] [VARCHAR] (1)  NOT NULL ,
  [REQUESTS_RECOVERY] [VARCHAR] (1)  NOT NULL ,
  [JOB_DATA] [IMAGE] NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[QRTZ_JOB_LISTENERS] (
  [JOB_NAME] [VARCHAR] (80)  NOT NULL ,
  [JOB_GROUP] [VARCHAR] (80)  NOT NULL ,
  [JOB_LISTENER] [VARCHAR] (80)  NOT NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[QRTZ_SIMPLE_TRIGGERS] (
  [TRIGGER_NAME] [VARCHAR] (80)  NOT NULL ,
  [TRIGGER_GROUP] [VARCHAR] (80)  NOT NULL ,
  [REPEAT_COUNT] [BIGINT] NOT NULL ,
  [REPEAT_INTERVAL] [BIGINT] NOT NULL ,
  [TIMES_TRIGGERED] [BIGINT] NOT NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[QRTZ_BLOB_TRIGGERS] (
  [TRIGGER_NAME] [VARCHAR] (80)  NOT NULL ,
  [TRIGGER_GROUP] [VARCHAR] (80)  NOT NULL ,
  [BLOB_DATA] [IMAGE] NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[QRTZ_TRIGGER_LISTENERS] (
  [TRIGGER_NAME] [VARCHAR] (80)  NOT NULL ,
  [TRIGGER_GROUP] [VARCHAR] (80)  NOT NULL ,
  [TRIGGER_LISTENER] [VARCHAR] (80)  NOT NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[QRTZ_TRIGGERS] (
  [TRIGGER_NAME] [VARCHAR] (80)  NOT NULL ,
  [TRIGGER_GROUP] [VARCHAR] (80)  NOT NULL ,
  [JOB_NAME] [VARCHAR] (80)  NOT NULL ,
  [JOB_GROUP] [VARCHAR] (80)  NOT NULL ,
  [IS_VOLATILE] [VARCHAR] (1)  NOT NULL ,
  [DESCRIPTION] [VARCHAR] (120) NULL ,
  [NEXT_FIRE_TIME] [BIGINT] NULL ,
  [PREV_FIRE_TIME] [BIGINT] NULL ,
  [PRIORITY] [INTEGER] NULL ,
  [TRIGGER_STATE] [VARCHAR] (16)  NOT NULL ,
  [TRIGGER_TYPE] [VARCHAR] (8)  NOT NULL ,
  [START_TIME] [BIGINT] NOT NULL ,
  [END_TIME] [BIGINT] NULL ,
  [CALENDAR_NAME] [VARCHAR] (80)  NULL ,
  [MISFIRE_INSTR] [SMALLINT] NULL ,
  [JOB_DATA] [IMAGE] NULL
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[QRTZ_CALENDARS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_CALENDARS] PRIMARY KEY  CLUSTERED
  (
    [CALENDAR_NAME]
  )  ON [PRIMARY]
GO

ALTER TABLE [dbo].[QRTZ_CRON_TRIGGERS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_CRON_TRIGGERS] PRIMARY KEY  CLUSTERED
  (
    [TRIGGER_NAME],
    [TRIGGER_GROUP]
  )  ON [PRIMARY]
GO

ALTER TABLE [dbo].[QRTZ_FIRED_TRIGGERS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_FIRED_TRIGGERS] PRIMARY KEY  CLUSTERED
  (
    [ENTRY_ID]
  )  ON [PRIMARY]
GO

ALTER TABLE [dbo].[QRTZ_PAUSED_TRIGGER_GRPS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_PAUSED_TRIGGER_GRPS] PRIMARY KEY  CLUSTERED
  (
    [TRIGGER_GROUP]
  )  ON [PRIMARY]
GO

ALTER TABLE [dbo].[QRTZ_SCHEDULER_STATE] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_SCHEDULER_STATE] PRIMARY KEY  CLUSTERED
  (
    [INSTANCE_NAME]
  )  ON [PRIMARY]
GO

ALTER TABLE [dbo].[QRTZ_LOCKS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_LOCKS] PRIMARY KEY  CLUSTERED
  (
    [LOCK_NAME]
  )  ON [PRIMARY]
GO

ALTER TABLE [dbo].[QRTZ_JOB_DETAILS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_JOB_DETAILS] PRIMARY KEY  CLUSTERED
  (
    [JOB_NAME],
    [JOB_GROUP]
  )  ON [PRIMARY]
GO

ALTER TABLE [dbo].[QRTZ_JOB_LISTENERS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_JOB_LISTENERS] PRIMARY KEY  CLUSTERED
  (
    [JOB_NAME],
    [JOB_GROUP],
    [JOB_LISTENER]
  )  ON [PRIMARY]
GO

ALTER TABLE [dbo].[QRTZ_SIMPLE_TRIGGERS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_SIMPLE_TRIGGERS] PRIMARY KEY  CLUSTERED
  (
    [TRIGGER_NAME],
    [TRIGGER_GROUP]
  )  ON [PRIMARY]
GO

ALTER TABLE [dbo].[QRTZ_TRIGGER_LISTENERS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_TRIGGER_LISTENERS] PRIMARY KEY  CLUSTERED
  (
    [TRIGGER_NAME],
    [TRIGGER_GROUP],
    [TRIGGER_LISTENER]
  )  ON [PRIMARY]
GO

ALTER TABLE [dbo].[QRTZ_TRIGGERS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_TRIGGERS] PRIMARY KEY  CLUSTERED
  (
    [TRIGGER_NAME],
    [TRIGGER_GROUP]
  )  ON [PRIMARY]
GO

ALTER TABLE [dbo].[QRTZ_CRON_TRIGGERS] ADD
  CONSTRAINT [FK_QRTZ_CRON_TRIGGERS_QRTZ_TRIGGERS] FOREIGN KEY
  (
    [TRIGGER_NAME],
    [TRIGGER_GROUP]
  ) REFERENCES [dbo].[QRTZ_TRIGGERS] (
    [TRIGGER_NAME],
    [TRIGGER_GROUP]
  ) ON DELETE CASCADE
GO

ALTER TABLE [dbo].[QRTZ_JOB_LISTENERS] ADD
  CONSTRAINT [FK_QRTZ_JOB_LISTENERS_QRTZ_JOB_DETAILS] FOREIGN KEY
  (
    [JOB_NAME],
    [JOB_GROUP]
  ) REFERENCES [dbo].[QRTZ_JOB_DETAILS] (
    [JOB_NAME],
    [JOB_GROUP]
  ) ON DELETE CASCADE
GO

ALTER TABLE [dbo].[QRTZ_SIMPLE_TRIGGERS] ADD
  CONSTRAINT [FK_QRTZ_SIMPLE_TRIGGERS_QRTZ_TRIGGERS] FOREIGN KEY
  (
    [TRIGGER_NAME],
    [TRIGGER_GROUP]
  ) REFERENCES [dbo].[QRTZ_TRIGGERS] (
    [TRIGGER_NAME],
    [TRIGGER_GROUP]
  ) ON DELETE CASCADE
GO

ALTER TABLE [dbo].[QRTZ_TRIGGER_LISTENERS] ADD
  CONSTRAINT [FK_QRTZ_TRIGGER_LISTENERS_QRTZ_TRIGGERS] FOREIGN KEY
  (
    [TRIGGER_NAME],
    [TRIGGER_GROUP]
  ) REFERENCES [dbo].[QRTZ_TRIGGERS] (
    [TRIGGER_NAME],
    [TRIGGER_GROUP]
  ) ON DELETE CASCADE
GO

ALTER TABLE [dbo].[QRTZ_TRIGGERS] ADD
  CONSTRAINT [FK_QRTZ_TRIGGERS_QRTZ_JOB_DETAILS] FOREIGN KEY
  (
    [JOB_NAME],
    [JOB_GROUP]
  ) REFERENCES [dbo].[QRTZ_JOB_DETAILS] (
    [JOB_NAME],
    [JOB_GROUP]
  )
GO

INSERT INTO [dbo].[QRTZ_LOCKS] VALUES('TRIGGER_ACCESS');
INSERT INTO [dbo].[QRTZ_LOCKS] VALUES('JOB_ACCESS');
INSERT INTO [dbo].[QRTZ_LOCKS] VALUES('CALENDAR_ACCESS');
INSERT INTO [dbo].[QRTZ_LOCKS] VALUES('STATE_ACCESS');
INSERT INTO [dbo].[QRTZ_LOCKS] VALUES('MISFIRE_ACCESS');

CREATE TABLE [dbo].[QRTZ_EXCL_CALENDARS] (
  [CALENDAR_NAME] [VARCHAR] (80)  NOT NULL ,
  [CALENDAR] [IMAGE] NOT NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[QRTZ_EXCL_CRON_TRIGGERS] (
  [TRIGGER_NAME] [VARCHAR] (80)  NOT NULL ,
  [TRIGGER_GROUP] [VARCHAR] (80)  NOT NULL ,
  [CRON_EXPRESSION] [VARCHAR] (80)  NOT NULL ,
  [TIME_ZONE_ID] [VARCHAR] (80) 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[QRTZ_EXCL_FIRED_TRIGGERS] (
  [ENTRY_ID] [VARCHAR] (95)  NOT NULL ,
  [TRIGGER_NAME] [VARCHAR] (80)  NOT NULL ,
  [TRIGGER_GROUP] [VARCHAR] (80)  NOT NULL ,
  [IS_VOLATILE] [VARCHAR] (1)  NOT NULL ,
  [INSTANCE_NAME] [VARCHAR] (80)  NOT NULL ,
  [FIRED_TIME] [BIGINT] NOT NULL ,
  [PRIORITY] [INTEGER] NOT NULL ,
  [STATE] [VARCHAR] (16)  NOT NULL,
  [JOB_NAME] [VARCHAR] (80)  NULL ,
  [JOB_GROUP] [VARCHAR] (80)  NULL ,
  [IS_STATEFUL] [VARCHAR] (1)  NULL ,
  [REQUESTS_RECOVERY] [VARCHAR] (1)  NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[QRTZ_EXCL_PAUSED_TRIGGER_GRPS] (
  [TRIGGER_GROUP] [VARCHAR] (80)  NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[QRTZ_EXCL_SCHEDULER_STATE] (
  [INSTANCE_NAME] [VARCHAR] (80)  NOT NULL ,
  [LAST_CHECKIN_TIME] [BIGINT] NOT NULL ,
  [CHECKIN_INTERVAL] [BIGINT] NOT NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[QRTZ_EXCL_LOCKS] (
  [LOCK_NAME] [VARCHAR] (40)  NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[QRTZ_EXCL_JOB_DETAILS] (
  [JOB_NAME] [VARCHAR] (80)  NOT NULL ,
  [JOB_GROUP] [VARCHAR] (80)  NOT NULL ,
  [DESCRIPTION] [VARCHAR] (120) NULL ,
  [JOB_CLASS_NAME] [VARCHAR] (128)  NOT NULL ,
  [IS_DURABLE] [VARCHAR] (1)  NOT NULL ,
  [IS_VOLATILE] [VARCHAR] (1)  NOT NULL ,
  [IS_STATEFUL] [VARCHAR] (1)  NOT NULL ,
  [REQUESTS_RECOVERY] [VARCHAR] (1)  NOT NULL ,
  [JOB_DATA] [IMAGE] NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[QRTZ_EXCL_JOB_LISTENERS] (
  [JOB_NAME] [VARCHAR] (80)  NOT NULL ,
  [JOB_GROUP] [VARCHAR] (80)  NOT NULL ,
  [JOB_LISTENER] [VARCHAR] (80)  NOT NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[QRTZ_EXCL_SIMPLE_TRIGGERS] (
  [TRIGGER_NAME] [VARCHAR] (80)  NOT NULL ,
  [TRIGGER_GROUP] [VARCHAR] (80)  NOT NULL ,
  [REPEAT_COUNT] [BIGINT] NOT NULL ,
  [REPEAT_INTERVAL] [BIGINT] NOT NULL ,
  [TIMES_TRIGGERED] [BIGINT] NOT NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[QRTZ_EXCL_BLOB_TRIGGERS] (
  [TRIGGER_NAME] [VARCHAR] (80)  NOT NULL ,
  [TRIGGER_GROUP] [VARCHAR] (80)  NOT NULL ,
  [BLOB_DATA] [IMAGE] NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[QRTZ_EXCL_TRIGGER_LISTENERS] (
  [TRIGGER_NAME] [VARCHAR] (80)  NOT NULL ,
  [TRIGGER_GROUP] [VARCHAR] (80)  NOT NULL ,
  [TRIGGER_LISTENER] [VARCHAR] (80)  NOT NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[QRTZ_EXCL_TRIGGERS] (
  [TRIGGER_NAME] [VARCHAR] (80)  NOT NULL ,
  [TRIGGER_GROUP] [VARCHAR] (80)  NOT NULL ,
  [JOB_NAME] [VARCHAR] (80)  NOT NULL ,
  [JOB_GROUP] [VARCHAR] (80)  NOT NULL ,
  [IS_VOLATILE] [VARCHAR] (1)  NOT NULL ,
  [DESCRIPTION] [VARCHAR] (120) NULL ,
  [NEXT_FIRE_TIME] [BIGINT] NULL ,
  [PREV_FIRE_TIME] [BIGINT] NULL ,
  [PRIORITY] [INTEGER] NULL ,
  [TRIGGER_STATE] [VARCHAR] (16)  NOT NULL ,
  [TRIGGER_TYPE] [VARCHAR] (8)  NOT NULL ,
  [START_TIME] [BIGINT] NOT NULL ,
  [END_TIME] [BIGINT] NULL ,
  [CALENDAR_NAME] [VARCHAR] (80)  NULL ,
  [MISFIRE_INSTR] [SMALLINT] NULL ,
  [JOB_DATA] [IMAGE] NULL
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[QRTZ_EXCL_CALENDARS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_EXCL_CALENDARS] PRIMARY KEY  CLUSTERED
  (
    [CALENDAR_NAME]
  )  ON [PRIMARY]
GO

ALTER TABLE [dbo].[QRTZ_EXCL_CRON_TRIGGERS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_EXCL_CRON_TRIGGERS] PRIMARY KEY  CLUSTERED
  (
    [TRIGGER_NAME],
    [TRIGGER_GROUP]
  )  ON [PRIMARY]
GO

ALTER TABLE [dbo].[QRTZ_EXCL_FIRED_TRIGGERS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_EXCL_FIRED_TRIGGERS] PRIMARY KEY  CLUSTERED
  (
    [ENTRY_ID]
  )  ON [PRIMARY]
GO

ALTER TABLE [dbo].[QRTZ_EXCL_PAUSED_TRIGGER_GRPS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_EXCL_PAUSED_TRIGGER_GRPS] PRIMARY KEY  CLUSTERED
  (
    [TRIGGER_GROUP]
  )  ON [PRIMARY]
GO

ALTER TABLE [dbo].[QRTZ_EXCL_SCHEDULER_STATE] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_EXCL_SCHEDULER_STATE] PRIMARY KEY  CLUSTERED
  (
    [INSTANCE_NAME]
  )  ON [PRIMARY]
GO

ALTER TABLE [dbo].[QRTZ_EXCL_LOCKS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_EXCL_LOCKS] PRIMARY KEY  CLUSTERED
  (
    [LOCK_NAME]
  )  ON [PRIMARY]
GO

ALTER TABLE [dbo].[QRTZ_EXCL_JOB_DETAILS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_EXCL_JOB_DETAILS] PRIMARY KEY  CLUSTERED
  (
    [JOB_NAME],
    [JOB_GROUP]
  )  ON [PRIMARY]
GO

ALTER TABLE [dbo].[QRTZ_EXCL_JOB_LISTENERS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_EXCL_JOB_LISTENERS] PRIMARY KEY  CLUSTERED
  (
    [JOB_NAME],
    [JOB_GROUP],
    [JOB_LISTENER]
  )  ON [PRIMARY]
GO

ALTER TABLE [dbo].[QRTZ_EXCL_SIMPLE_TRIGGERS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_EXCL_SIMPLE_TRIGGERS] PRIMARY KEY  CLUSTERED
  (
    [TRIGGER_NAME],
    [TRIGGER_GROUP]
  )  ON [PRIMARY]
GO

ALTER TABLE [dbo].[QRTZ_EXCL_TRIGGER_LISTENERS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_EXCL_TRIGGER_LISTENERS] PRIMARY KEY  CLUSTERED
  (
    [TRIGGER_NAME],
    [TRIGGER_GROUP],
    [TRIGGER_LISTENER]
  )  ON [PRIMARY]
GO

ALTER TABLE [dbo].[QRTZ_EXCL_TRIGGERS] WITH NOCHECK ADD
  CONSTRAINT [PK_QRTZ_EXCL_TRIGGERS] PRIMARY KEY  CLUSTERED
  (
    [TRIGGER_NAME],
    [TRIGGER_GROUP]
  )  ON [PRIMARY]
GO

ALTER TABLE [dbo].[QRTZ_EXCL_CRON_TRIGGERS] ADD
  CONSTRAINT [FK_QRTZ_EXCL_CRON_TRIGGERS_QRTZ_EXCL_TRIGGERS] FOREIGN KEY
  (
    [TRIGGER_NAME],
    [TRIGGER_GROUP]
  ) REFERENCES [dbo].[QRTZ_EXCL_TRIGGERS] (
    [TRIGGER_NAME],
    [TRIGGER_GROUP]
  ) ON DELETE CASCADE
GO

ALTER TABLE [dbo].[QRTZ_EXCL_JOB_LISTENERS] ADD
  CONSTRAINT [FK_QRTZ_EXCL_JOB_LISTENERS_QRTZ_EXCL_JOB_DETAILS] FOREIGN KEY
  (
    [JOB_NAME],
    [JOB_GROUP]
  ) REFERENCES [dbo].[QRTZ_EXCL_JOB_DETAILS] (
    [JOB_NAME],
    [JOB_GROUP]
  ) ON DELETE CASCADE
GO

ALTER TABLE [dbo].[QRTZ_EXCL_SIMPLE_TRIGGERS] ADD
  CONSTRAINT [FK_QRTZ_EXCL_SIMPLE_TRIGGERS_QRTZ_EXCL_TRIGGERS] FOREIGN KEY
  (
    [TRIGGER_NAME],
    [TRIGGER_GROUP]
  ) REFERENCES [dbo].[QRTZ_EXCL_TRIGGERS] (
    [TRIGGER_NAME],
    [TRIGGER_GROUP]
  ) ON DELETE CASCADE
GO

ALTER TABLE [dbo].[QRTZ_EXCL_TRIGGER_LISTENERS] ADD
  CONSTRAINT [FK_QRTZ_EXCL_TRIGGER_LISTENERS_QRTZ_EXCL_TRIGGERS] FOREIGN KEY
  (
    [TRIGGER_NAME],
    [TRIGGER_GROUP]
  ) REFERENCES [dbo].[QRTZ_EXCL_TRIGGERS] (
    [TRIGGER_NAME],
    [TRIGGER_GROUP]
  ) ON DELETE CASCADE
GO

ALTER TABLE [dbo].[QRTZ_EXCL_TRIGGERS] ADD
  CONSTRAINT [FK_QRTZ_EXCL_TRIGGERS_QRTZ_EXCL_JOB_DETAILS] FOREIGN KEY
  (
    [JOB_NAME],
    [JOB_GROUP]
  ) REFERENCES [dbo].[QRTZ_EXCL_JOB_DETAILS] (
    [JOB_NAME],
    [JOB_GROUP]
  )
GO

INSERT INTO [dbo].[QRTZ_EXCL_LOCKS] VALUES('TRIGGER_ACCESS');
INSERT INTO [dbo].[QRTZ_EXCL_LOCKS] VALUES('JOB_ACCESS');
INSERT INTO [dbo].[QRTZ_EXCL_LOCKS] VALUES('CALENDAR_ACCESS');
INSERT INTO [dbo].[QRTZ_EXCL_LOCKS] VALUES('STATE_ACCESS');
INSERT INTO [dbo].[QRTZ_EXCL_LOCKS] VALUES('MISFIRE_ACCESS');
create table calendar_reminder (
   user_id varchar(255) not null,
   event_id varchar(100) not null,
   send_date datetime not null,
   primary key (user_id, event_id, send_date)
);
create table ecom_product_price (
   inode varchar(100) not null,
   product_format_inode varchar(100) not null,
   min_qty int null,
   max_qty int null,
   retail_price float not null,
   partner_price float not null,
   primary key (inode)
);
create table tag (
   tagname varchar(255) not null,
   user_id varchar(255) null,
   primary key (tagname)
);
create table entity (
   inode varchar(100) not null,
   entity_name varchar(255) null,
   primary key (inode)
);
create table user_comments (
   inode varchar(100) not null,
   user_id varchar(255) null,
   cdate datetime null,
   comment_user_id varchar(100) null,
   type varchar(255) null,
   method varchar(255) null,
   subject varchar(255) null,
   ucomment text null,
   communication_id varchar(100) null,
   primary key (inode)
);
create table permission_reference (
   id numeric(19,0) identity not null,
   asset_id varchar(100) null,
   reference_id varchar(100) null,
   permission_type varchar(100) null,
   primary key (id),
   unique (asset_id)
);
create table fixes_audit (
   id varchar(255) not null,
   table_name varchar(255) null,
   action varchar(255) null,
   records_altered int null,
   datetime datetime null,
   primary key (id)
);
create table trackback (
   id numeric(19,0) identity not null,
   asset_identifier varchar(100) null,
   title varchar(255) null,
   excerpt varchar(255) null,
   url varchar(255) null,
   blog_name varchar(255) null,
   track_date datetime not null,
   primary key (id)
);
create table plugin (
   id varchar(255) not null,
   plugin_name varchar(255) not null,
   plugin_version varchar(255) not null,
   author varchar(255) not null,
   first_deployed_date datetime not null,
   last_deployed_date datetime not null,
   primary key (id)
);
create table recipient (
   inode varchar(100) not null,
   name varchar(255) null,
   lastname varchar(255) null,
   email varchar(255) null,
   sent datetime null,
   opened datetime null,
   last_result int null,
   last_message varchar(255) null,
   user_id varchar(100) null,
   primary key (inode)
);
create table mailing_list (
   inode varchar(100) not null,
   title varchar(255) null,
   public_list tinyint null,
   user_id varchar(255) null,
   primary key (inode)
);
create table web_form (
   web_form_id varchar(100) not null,
   form_type varchar(255) null,
   submit_date datetime null,
   prefix varchar(255) null,
   first_name varchar(255) null,
   middle_initial varchar(255) null,
   middle_name varchar(255) null,
   full_name varchar(255) null,
   organization varchar(255) null,
   title varchar(255) null,
   last_name varchar(255) null,
   address varchar(255) null,
   address1 varchar(255) null,
   address2 varchar(255) null,
   city varchar(255) null,
   state varchar(255) null,
   zip varchar(255) null,
   country varchar(255) null,
   phone varchar(255) null,
   email varchar(255) null,
   custom_fields text null,
   user_inode varchar(100) null,
   categories varchar(255) null,
   primary key (web_form_id)
);
create table virtual_link (
   inode varchar(100) not null,
   title varchar(255) null,
   url varchar(255) null,
   uri varchar(255) null,
   active tinyint null,
   primary key (inode)
);
create table tree (
   child varchar(100) not null,
   parent varchar(100) not null,
   relation_type varchar(64) not null,
   tree_order int null,
   primary key (child, parent, relation_type)
);
create table event (
   inode varchar(100) not null,
   title varchar(255) null,
   subtitle varchar(255) null,
   start_date datetime null,
   end_date datetime null,
   location varchar(255) null,
   address1 varchar(255) null,
   address2 varchar(255) null,
   address3 varchar(255) null,
   city varchar(255) null,
   state varchar(255) null,
   zip varchar(32) null,
   country varchar(64) null,
   email varchar(64) null,
   phone varchar(64) null,
   fax varchar(64) null,
   url varchar(255) null,
   registration tinyint null,
   include_file varchar(255) null,
   show_public tinyint null,
   contact_name varchar(255) null,
   contact_company varchar(255) null,
   contact_phone varchar(255) null,
   contact_email varchar(255) null,
   contact_fax varchar(255) null,
   directions text null,
   description text null,
   email_response text null,
   web_address varchar(255) null,
   user_id varchar(255) null,
   featured tinyint null,
   setup_date datetime null,
   break_date datetime null,
   approval_status int null,
   comments_equipment text null,
   received_adm_approval tinyint null,
   time_tbd tinyint null,
   primary key (inode)
);
create table users_cms_roles (
   id varchar(255) not null,
   user_id varchar(100) not null,
   role_id varchar(100) not null,
   primary key (id)
);
create table web_event (
   inode varchar(100) not null,
   title varchar(255) null,
   subtitle varchar(255) null,
   summary varchar(1000) null,
   description varchar(255) null,
   terms_conditions varchar(255) null,
   comments varchar(255) null,
   partners_only tinyint null,
   show_on_web tinyint null,
   sort_order int null,
   event_image_1 varchar(100) null,
   event_image_2 varchar(100) null,
   event_image_3 varchar(100) null,
   event_image_4 varchar(100) null,
   is_institute tinyint null,
   primary key (inode)
);
create table ecom_product (
   inode varchar(100) not null,
   title varchar(255) not null,
   short_description text null,
   long_description text null,
   req_shipping tinyint null,
   featured tinyint null,
   sort_order int null,
   comments text null,
   showonweb tinyint null,
   primary key (inode)
);
create table template (
   inode varchar(100) not null,
   live tinyint null,
   working tinyint null,
   deleted tinyint null,
   locked tinyint null,
   show_on_menu tinyint null,
   title varchar(255) null,
   mod_date datetime null,
   mod_user varchar(100) null,
   sort_order int null,
   friendly_name varchar(255) null,
   body text null,
   header text null,
   footer text null,
   image varchar(100) null,
   primary key (inode)
);
create table ecom_order_item (
   inode varchar(100) not null,
   order_inode varchar(100) null,
   product_inode varchar(100) null,
   item_qty int null,
   item_price float null,
   primary key (inode)
);
create table structure (
   inode varchar(100) not null,
   name varchar(255) null,
   description varchar(255) null,
   default_structure tinyint null,
   review_interval varchar(255) null,
   reviewer_role varchar(255) null,
   page_detail varchar(100) null,
   structuretype int null,
   system tinyint null,
   fixed tinyint not null,
   velocity_var_name varchar(255) null,
   url_map_pattern varchar(512) null,
   primary key (inode)
);
create table ecom_discount_code (
   inode varchar(100) not null,
   discount_type int null,
   start_date datetime null,
   end_date datetime null,
   code_id varchar(50) null,
   code_description varchar(100) null,
   free_shipping tinyint null,
   no_bulk_disc tinyint null,
   discount_amount float null,
   min_order int null,
   primary key (inode)
);
create table cms_role (
   id varchar(100) not null,
   role_name varchar(255) not null,
   description text null,
   role_key varchar(255) null,
   db_fqn varchar(1000) not null,
   parent varchar(100) not null,
   edit_permissions tinyint null,
   edit_users tinyint null,
   edit_layouts tinyint null,
   locked tinyint null,
   system tinyint null,
   primary key (id)
);
create table web_event_registration (
   inode varchar(100) not null,
   event_inode varchar(100) null,
   event_location_inode varchar(100) null,
   user_inode varchar(100) null,
   registration_status int null,
   date_posted datetime null,
   last_mod_date datetime null,
   total_paid float null,
   total_due float null,
   total_registration float null,
   payment_type int null,
   billing_address_1 varchar(255) null,
   billing_address_2 varchar(255) null,
   billing_city varchar(255) null,
   billing_state varchar(50) null,
   billing_zip varchar(50) null,
   billing_country varchar(50) null,
   billing_contact_name varchar(255) null,
   billing_contact_phone varchar(50) null,
   billing_contact_email varchar(255) null,
   card_name varchar(255) null,
   card_type varchar(50) null,
   card_number varchar(50) null,
   card_exp_month varchar(50) null,
   card_exp_year varchar(50) null,
   card_verification_value varchar(10) null,
   check_number varchar(50) null,
   check_bank_name varchar(255) null,
   po_number varchar(50) null,
   invoice_number varchar(50) null,
   badge_printed tinyint null,
   how_did_you_hear varchar(255) null,
   ceo_name varchar(255) null,
   modified_qb tinyint null,
   reminder_email_sent tinyint null,
   post_email_sent tinyint null,
   primary key (inode)
);
create table permission (
   id numeric(19,0) identity not null,
   permission_type varchar(100) null,
   inode_id varchar(100) null,
   roleid varchar(100) null,
   permission int null,
   primary key (id),
   unique (permission_type, inode_id, roleid)
);
create table recurance (
   inode varchar(100) not null,
   recurrance_occurs varchar(255) null,
   recurrance_interval int null,
   recurrance_starting datetime null,
   recurrance_ending datetime null,
   recurrance_days_of_week varchar(255) null,
   recurrance_day_of_month int null,
   primary key (inode)
);
	create table contentlet (inode varchar(100) not null,
	live tinyint null,
	working tinyint null,
	deleted tinyint null,
	locked tinyint null,
	show_on_menu tinyint null,
	title varchar(255) null,
	mod_date datetime null,
	mod_user varchar(100) null,
	sort_order int null,
	friendly_name varchar(255) null,
	language_id numeric(19,0) null,
	structure_inode varchar(100) null,
	last_review datetime null,
	next_review datetime null,
	review_interval varchar(255) null,
	disabled_wysiwyg varchar(255) null,
	folder varchar(100) null,
	date1 datetime null,
	date2 datetime null,
	date3 datetime null,
	date4 datetime null,
	date5 datetime null,
	date6 datetime null,
	date7 datetime null,
	date8 datetime null,
	date9 datetime null,
	date10 datetime null,
	date11 datetime null,
	date12 datetime null,
	date13 datetime null,
	date14 datetime null,
	date15 datetime null,
	date16 datetime null,
	date17 datetime null,
	date18 datetime null,
	date19 datetime null,
	date20 datetime null,
	date21 datetime null,
	date22 datetime null,
	date23 datetime null,
	date24 datetime null,
	date25 datetime null,
	text1 varchar(255) null,
	text2 varchar(255) null,
	text3 varchar(255) null,
	text4 varchar(255) null,
	text5 varchar(255) null,
	text6 varchar(255) null,
	text7 varchar(255) null,
	text8 varchar(255) null,
	text9 varchar(255) null,
	text10 varchar(255) null,
	text11 varchar(255) null,
	text12 varchar(255) null,
	text13 varchar(255) null,
	text14 varchar(255) null,
	text15 varchar(255) null,
	text16 varchar(255) null,
	text17 varchar(255) null,
	text18 varchar(255) null,
	text19 varchar(255) null,
	text20 varchar(255) null,
	text21 varchar(255) null,
	text22 varchar(255) null,
	text23 varchar(255) null,
	text24 varchar(255) null,
	text25 varchar(255) null,
	text_area1 text null,
	text_area2 text null,
	text_area3 text null,
	text_area4 text null,
	text_area5 text null,
	text_area6 text null,
	text_area7 text null,
	text_area8 text null,
	text_area9 text null,
	text_area10 text null,
	text_area11 text null,
	text_area12 text null,
	text_area13 text null,
	text_area14 text null,
	text_area15 text null,
	text_area16 text null,
	text_area17 text null,
	text_area18 text null,
	text_area19 text null,
	text_area20 text null,
	text_area21 text null,
	text_area22 text null,
	text_area23 text null,
	text_area24 text null,
	text_area25 text null,
	integer1 numeric(19,0) null,
	integer2 numeric(19,0) null,
	integer3 numeric(19,0) null,
	integer4 numeric(19,0) null,
	integer5 numeric(19,0) null,
	integer6 numeric(19,0) null,
	integer7 numeric(19,0) null,
	integer8 numeric(19,0) null,
	integer9 numeric(19,0) null,
	integer10 numeric(19,0) null,
	integer11 numeric(19,0) null,
	integer12 numeric(19,0) null,
	integer13 numeric(19,0) null,
	integer14 numeric(19,0) null,
	integer15 numeric(19,0) null,
	integer16 numeric(19,0) null,
	integer17 numeric(19,0) null,
	integer18 numeric(19,0) null,
	integer19 numeric(19,0) null,
	integer20 numeric(19,0) null,
	integer21 numeric(19,0) null,
	integer22 numeric(19,0) null,
	integer23 numeric(19,0) null,
	integer24 numeric(19,0) null,
	integer25 numeric(19,0) null,
	"float1" float null,
	"float2" float null,
	"float3" float null,
	"float4" float null,
	"float5" float null,
	"float6" float null,
	"float7" float null,
	"float8" float null,
	"float9" float null,
	"float10" float null,
	"float11" float null,
	"float12" float null,
	"float13" float null,
	"float14" float null,
	"float15" float null,
	"float16" float null,
	"float17" float null,
	"float18" float null,
	"float19" float null,
	"float20" float null,
	"float21" float null,
	"float22" float null,
	"float23" float null,
	"float24" float null,
	"float25" float null,
	bool1 tinyint null,
	bool2 tinyint null,
	bool3 tinyint null,
	bool4 tinyint null,
	bool5 tinyint null,
	bool6 tinyint null,
	bool7 tinyint null,
	bool8 tinyint null,
	bool9 tinyint null,
	bool10 tinyint null,
	bool11 tinyint null,
	bool12 tinyint null,
	bool13 tinyint null,
	bool14 tinyint null,
	bool15 tinyint null,
	bool16 tinyint null,
	bool17 tinyint null,
	bool18 tinyint null,
	bool19 tinyint null,
	bool20 tinyint null,
	bool21 tinyint null,
	bool22 tinyint null,
	bool23 tinyint null,
	bool24 tinyint null,
	bool25 tinyint null,
	primary key (inode));
create table cms_layouts_portlets (
   id varchar(255) not null,
   layout_id varchar(100) not null,
   portlet_id varchar(100) not null,
   portlet_order int null,
   primary key (id)
);
create table workflow_comment (
   inode varchar(100) not null,
   creation_date datetime null,
   posted_by varchar(255) null,
   wf_comment text null,
   primary key (inode)
);
create table report_asset (
   inode varchar(100) not null,
   report_name varchar(255) not null,
   report_description varchar(1000) not null,
   requires_input tinyint null,
   ds varchar(100) not null,
   web_form_report tinyint null,
   primary key (inode)
);
create table category (
   inode varchar(100) not null,
   category_name varchar(255) null,
   category_key varchar(255) null,
   sort_order int null,
   active tinyint null,
   keywords text null,
   category_velocity_var_name varchar(255) null,
   primary key (inode)
);
create table htmlpage (
   inode varchar(100) not null,
   live tinyint null,
   working tinyint null,
   deleted tinyint null,
   locked tinyint null,
   show_on_menu tinyint null,
   title varchar(255) null,
   mod_date datetime null,
   mod_user varchar(100) null,
   sort_order int null,
   friendly_name varchar(255) null,
   metadata text null,
   start_date datetime null,
   end_date datetime null,
   page_url varchar(255) null,
   https_required tinyint null,
   redirect varchar(255) null,
   primary key (inode)
);
create table chain_link_code (
   id numeric(19,0) identity not null,
   class_name varchar(255) null unique,
   code text not null,
   last_mod_date datetime not null,
   language varchar(255) not null,
   primary key (id)
);
create table language (
   id numeric(19,0) identity not null,
   language_code varchar(5) null,
   country_code varchar(255) null,
   language varchar(255) null,
   country varchar(255) null,
   primary key (id)
);
create table user_preferences (
   id numeric(19,0) identity not null,
   user_id varchar(100) not null,
   preference varchar(255) null,
   pref_value text null,
   primary key (id)
);
create table users_to_delete (
   id numeric(19,0) identity not null,
   user_id varchar(255) null,
   primary key (id)
);
create table identifier (
   inode varchar(100) not null,
   uri varchar(255) null,
   host_inode varchar(255) null,
   primary key (inode),
   unique (uri, host_inode)
);
create table clickstream (
   clickstream_id numeric(19,0) identity not null,
   cookie_id varchar(255) null,
   user_id varchar(255) null,
   start_date datetime null,
   end_date datetime null,
   referer varchar(255) null,
   remote_address varchar(255) null,
   remote_hostname varchar(255) null,
   user_agent varchar(255) null,
   bot tinyint null,
   number_of_requests int null,
   host_id varchar(50) null,
   last_page_id varchar(50) null,
   first_page_id varchar(50) null,
   operating_system varchar(50) null,
   browser_name varchar(50) null,
   browser_version varchar(50) null,
   mobile_device tinyint null,
   primary key (clickstream_id)
);
create table web_event_location (
   inode varchar(100) not null,
   web_event_inode varchar(100) null,
   city varchar(255) null,
   state varchar(50) null,
   start_date datetime null,
   end_date datetime null,
   show_on_web tinyint null,
   web_reg_active tinyint null,
   hotel_name varchar(255) null,
   hotel_link numeric(19,0) null,
   past_event_link numeric(19,0) null,
   partner_price float null,
   non_partner_price float null,
   short_description varchar(255) null,
   text_email varchar(1000) null,
   almost_at_capacity tinyint null,
   full_capacity tinyint null,
   default_contract_partner_price tinyint null,
   primary key (inode)
);
create table multi_tree (
   child varchar(100) not null,
   parent1 varchar(100) not null,
   parent2 varchar(100) not null,
   relation_type varchar(64) null,
   tree_order int null,
   primary key (child, parent1, parent2)
);
create table tag_inode (
   inode varchar(100) not null,
   tagname varchar(255) not null,
   primary key (inode, tagname)
);
create table workflow_task (
   inode varchar(100) not null,
   creation_date datetime null,
   mod_date datetime null,
   due_date datetime null,
   created_by varchar(255) null,
   assigned_to varchar(255) null,
   belongs_to varchar(255) null,
   title varchar(255) null,
   description text null,
   status varchar(255) null,
   webasset varchar(255) null,
   primary key (inode)
);
create table click (
   inode varchar(100) not null,
   link varchar(255) null,
   click_count int null,
   primary key (inode)
);
create table event_registration (
   inode varchar(100) not null,
   registration_date datetime null,
   full_name varchar(255) null,
   number_attending int null,
   comments text null,
   email varchar(255) null,
   primary key (inode)
);
create table challenge_question (
   cquestionid numeric(19,0) not null,
   cqtext varchar(255) null,
   primary key (cquestionid)
);
create table file_asset (
   inode varchar(100) not null,
   file_name varchar(255) null,
   file_size int null,
   width int null,
   height int null,
   mime_type varchar(255) null,
   author varchar(255) null,
   publish_date datetime null,
   live tinyint null,
   working tinyint null,
   deleted tinyint null,
   locked tinyint null,
   show_on_menu tinyint null,
   title varchar(255) null,
   friendly_name varchar(255) null,
   mod_date datetime null,
   mod_user varchar(255) null,
   sort_order int null,
   primary key (inode)
);
create table layouts_cms_roles (
   id varchar(255) not null,
   layout_id varchar(100) not null,
   role_id varchar(100) not null,
   primary key (id)
);
create table organization (
   inode varchar(100) not null,
   title varchar(255) null,
   ceo_name varchar(255) null,
   partner_url varchar(255) null,
   partner_key varchar(255) null,
   partner_logo varchar(100) null,
   street1 varchar(255) null,
   street2 varchar(255) null,
   city varchar(255) null,
   state varchar(255) null,
   zip varchar(100) null,
   phone varchar(100) null,
   fax varchar(100) null,
   country varchar(255) null,
   is_system tinyint null,
   parent_organization varchar(100) null,
   primary key (inode)
);
create table facility (
   inode varchar(100) not null,
   facility_name varchar(255) not null,
   facility_description varchar(255) null,
   sort_order int null,
   active tinyint null,
   primary key (inode)
);
create table clickstream_request (
   clickstream_request_id numeric(19,0) identity not null,
   clickstream_id numeric(19,0) null,
   server_name varchar(255) null,
   protocol varchar(255) null,
   server_port int null,
   request_uri varchar(255) null,
   request_order int null,
   query_string text null,
   language_id numeric(19,0) null,
   timestampper datetime null,
   host_id varchar(255) null,
   associated_identifier varchar(50) null,
   primary key (clickstream_request_id)
);
create table chain_state (
   id numeric(19,0) identity not null,
   chain_id numeric(19,0) not null,
   link_code_id numeric(19,0) not null,
   state_order numeric(19,0) not null,
   primary key (id)
);
create table content_rating (
   id numeric(19,0) identity not null,
   rating float null,
   user_id varchar(255) null,
   session_id varchar(255) null,
   identifier varchar(100) null,
   rating_date datetime null,
   user_ip varchar(255) null,
   long_live_cookie_id varchar(255) null,
   primary key (id)
);
create table campaign (
   inode varchar(100) not null,
   title varchar(255) null,
   from_email varchar(255) null,
   from_name varchar(255) null,
   subject varchar(255) null,
   message text null,
   user_id varchar(255) null,
   start_date datetime null,
   completed_date datetime null,
   active tinyint null,
   locked tinyint null,
   sends_per_hour varchar(15) null,
   sendemail tinyint null,
   communicationinode varchar(100) null,
   userfilterinode varchar(100) null,
   sendto varchar(15) null,
   isrecurrent tinyint null,
   wassent tinyint null,
   expiration_date datetime null,
   parent_campaign varchar(100) null,
   primary key (inode)
);
create table banner (
   inode varchar(100) not null,
   title varchar(255) null,
   caption text null,
   new_window tinyint null,
   link varchar(255) null,
   start_date datetime null,
   end_date datetime null,
   body varchar(255) null,
   active tinyint null,
   nmbr_views int null,
   nmbr_clicks int null,
   image varchar(100) null,
   path varchar(500) null,
   placement varchar(255) null,
   primary key (inode)
);
create table containers (
   inode varchar(100) not null,
   code text null,
   pre_loop text null,
   post_loop text null,
   live tinyint null,
   working tinyint null,
   deleted tinyint null,
   locked tinyint null,
   show_on_menu tinyint null,
   title varchar(255) null,
   mod_date datetime null,
   mod_user varchar(100) null,
   sort_order int null,
   friendly_name varchar(255) null,
   max_contentlets int null,
   use_div tinyint null,
   staticify tinyint null,
   sort_contentlets_by varchar(255) null,
   lucene_query text null,
   notes varchar(255) null,
   primary key (inode)
);
create table ecom_order (
   inode varchar(100) not null,
   user_inode varchar(100) null,
   order_status int null,
   payment_status int null,
   date_posted datetime null,
   last_mod_date datetime null,
   billing_address1 varchar(255) null,
   billing_address2 varchar(255) null,
   billing_city varchar(100) null,
   billing_state varchar(50) null,
   billing_zip varchar(50) null,
   billing_country varchar(50) null,
   billing_phone varchar(50) null,
   billing_fax varchar(50) null,
   billing_first_name varchar(100) null,
   billing_last_name varchar(100) null,
   billing_contact_name varchar(100) null,
   billing_contact_phone varchar(50) null,
   billing_contact_email varchar(100) null,
   shipping_address1 varchar(255) null,
   shipping_address2 varchar(255) null,
   shipping_city varchar(50) null,
   shipping_state varchar(50) null,
   shipping_zip varchar(50) null,
   shipping_country varchar(50) null,
   shipping_phone varchar(50) null,
   shipping_fax varchar(50) null,
   payment_type varchar(10) null,
   name_on_card varchar(100) null,
   card_type varchar(50) null,
   card_number varchar(50) null,
   card_exp_month int null,
   card_exp_year int null,
   card_verification_value varchar(50) null,
   order_sub_total float null,
   order_shipping float null,
   order_ship_type int null,
   order_tax float null,
   order_discount float null,
   tax_exempt_number varchar(50) null,
   discount_codes varchar(50) null,
   order_total float null,
   order_total_paid float null,
   order_total_due float null,
   invoice_number varchar(50) null,
   invoice_date datetime null,
   check_number varchar(50) null,
   check_bank_name varchar(100) null,
   po_number varchar(50) null,
   tracking_number varchar(255) null,
   modified_qb tinyint null,
   modified_fh tinyint null,
   backend_user varchar(100) null,
   shipping_label varchar(50) null,
   primary key (inode)
);
create table web_event_attendee (
   inode varchar(100) not null,
   event_registration_inode varchar(100) null,
   first_name varchar(255) null,
   last_name varchar(255) null,
   badge_name varchar(255) null,
   email varchar(255) null,
   title varchar(255) null,
   registration_price float null,
   primary key (inode)
);
create table communication (
   inode varchar(100) not null,
   title varchar(255) null,
   trackback_link_inode varchar(100) null,
   communication_type varchar(255) null,
   from_name varchar(255) null,
   from_email varchar(255) null,
   email_subject varchar(255) null,
   html_page_inode varchar(100) null,
   text_message text null,
   mod_date datetime null,
   modified_by varchar(255) null,
   ext_comm_id varchar(255) null,
   primary key (inode)
);
create table workflow_history (
   inode varchar(100) not null,
   creation_date datetime null,
   made_by varchar(255) null,
   change_desc text null,
   primary key (inode)
);
create table host_variable (
   id varchar(255) not null,
   host_id varchar(255) null,
   variable_name varchar(255) null,
   variable_key varchar(255) null,
   variable_value varchar(255) null,
   user_id varchar(255) null,
   last_mod_date datetime null,
   primary key (id)
);
create table links (
   inode varchar(100) not null,
   live tinyint null,
   working tinyint null,
   deleted tinyint null,
   locked tinyint null,
   show_on_menu tinyint null,
   title varchar(255) null,
   mod_date datetime null,
   mod_user varchar(100) null,
   sort_order int null,
   friendly_name varchar(255) null,
   protocal varchar(100) null,
   url varchar(255) null,
   target varchar(100) null,
   internal_link_identifier varchar(100) null,
   link_type varchar(255) null,
   link_code text null,
   primary key (inode)
);
create table event_recurrence (
   inode varchar(100) not null,
   occurs varchar(255) null,
   rec_interval int null,
   rec_starting datetime null,
   ending datetime null,
   days_of_week varchar(255) null,
   day_of_month int null,
   primary key (inode)
);
create table user_proxy (
   inode varchar(100) not null,
   user_id varchar(255) null,
   prefix varchar(255) null,
   suffix varchar(255) null,
   title varchar(255) null,
   school varchar(255) null,
   how_heard varchar(255) null,
   company varchar(255) null,
   long_lived_cookie varchar(255) null,
   website varchar(255) null,
   graduation_year int null,
   organization varchar(255) null,
   mail_subscription tinyint null,
   var1 varchar(255) null,
   var2 varchar(255) null,
   var3 varchar(255) null,
   var4 varchar(255) null,
   var5 varchar(255) null,
   var6 varchar(255) null,
   var7 varchar(255) null,
   var8 varchar(255) null,
   var9 varchar(255) null,
   var10 varchar(255) null,
   var11 varchar(255) null,
   var12 varchar(255) null,
   var13 varchar(255) null,
   var14 varchar(255) null,
   var15 varchar(255) null,
   var16 varchar(255) null,
   var17 varchar(255) null,
   var18 varchar(255) null,
   var19 varchar(255) null,
   var20 varchar(255) null,
   var21 varchar(255) null,
   var22 varchar(255) null,
   var23 varchar(255) null,
   var24 varchar(255) null,
   var25 varchar(255) null,
   last_result int null,
   last_message varchar(255) null,
   no_click_tracking tinyint null,
   cquestionid varchar(255) null,
   cqanswer varchar(255) null,
   chapter_officer varchar(255) null,
   primary key (inode),
   unique (user_id)
);
create table chain_state_parameter (
   id numeric(19,0) identity not null,
   chain_state_id numeric(19,0) not null,
   name varchar(255) not null,
   value varchar(255) not null,
   primary key (id)
);
create table folder (
   inode varchar(100) not null,
   name varchar(255) null,
   path varchar(255) not null,
   title varchar(255) not null,
   show_on_menu tinyint null,
   sort_order int null,
   host_inode varchar(100) null,
   files_masks varchar(255) null,
   primary key (inode)
);
create table relationship (
   inode varchar(100) not null,
   parent_structure_inode varchar(255) null,
   child_structure_inode varchar(255) null,
   parent_relation_name varchar(255) null,
   child_relation_name varchar(255) null,
   relation_type_value varchar(255) null,
   cardinality int null,
   parent_required tinyint null,
   child_required tinyint null,
   fixed tinyint null,
   primary key (inode)
);
create table field (
   inode varchar(100) not null,
   structure_inode varchar(255) null,
   field_name varchar(255) null,
   field_type varchar(255) null,
   field_relation_type varchar(255) null,
   field_contentlet varchar(255) null,
   required tinyint null,
   indexed tinyint null,
   listed tinyint null,
   velocity_var_name varchar(255) null,
   sort_order int null,
   field_values text null,
   regex_check varchar(255) null,
   hint varchar(255) null,
   default_value varchar(255) null,
   fixed tinyint null,
   read_only tinyint null,
   searchable tinyint null,
   unique_ tinyint null,
   primary key (inode)
);
create table cms_layout (
   id varchar(100) not null,
   layout_name varchar(255) not null,
   description varchar(255) null,
   tab_order int null,
   primary key (id)
);
create table ecom_product_format (
   inode varchar(100) not null,
   product_inode varchar(100) not null,
   format_name varchar(255) not null,
   item_num varchar(50) null,
   format varchar(100) not null,
   inventory_quantity int null,
   reorder_trigger int null,
   weight float null,
   width int null,
   height int null,
   depth int null,
   primary key (inode)
);
create table report_parameter (
   inode varchar(100) not null,
   report_inode varchar(100) null,
   parameter_description varchar(1000) null,
   parameter_name varchar(255) null,
   class_type varchar(250) null,
   default_value varchar(4000) null,
   primary key (inode),
   unique (report_inode, parameter_name)
);
create table chain (
   id numeric(19,0) identity not null,
   key_name varchar(255) null unique,
   name varchar(255) not null,
   success_value varchar(255) not null,
   failure_value varchar(255) not null,
   primary key (id)
);
create table inode (
   inode varchar(100) not null,
   owner varchar(255) null,
   idate datetime null,
   type varchar(64) null,
   identifier varchar(100) null,
   primary key (inode)
);
create table user_filter (
   inode varchar(100) not null,
   title varchar(255) null,
   firstname varchar(100) null,
   middlename varchar(100) null,
   lastname varchar(100) null,
   emailaddress varchar(100) null,
   birthdaytypesearch varchar(100) null,
   birthday datetime null,
   birthdayfrom datetime null,
   birthdayto datetime null,
   lastlogintypesearch varchar(100) null,
   lastloginsince varchar(100) null,
   loginfrom datetime null,
   loginto datetime null,
   createdtypesearch varchar(100) null,
   createdsince varchar(100) null,
   createdfrom datetime null,
   createdto datetime null,
   lastvisittypesearch varchar(100) null,
   lastvisitsince varchar(100) null,
   lastvisitfrom datetime null,
   lastvisitto datetime null,
   city varchar(100) null,
   state varchar(100) null,
   country varchar(100) null,
   zip varchar(100) null,
   cell varchar(100) null,
   phone varchar(100) null,
   fax varchar(100) null,
   active_ varchar(255) null,
   tagname varchar(255) null,
   var1 varchar(255) null,
   var2 varchar(255) null,
   var3 varchar(255) null,
   var4 varchar(255) null,
   var5 varchar(255) null,
   var6 varchar(255) null,
   var7 varchar(255) null,
   var8 varchar(255) null,
   var9 varchar(255) null,
   var10 varchar(255) null,
   var11 varchar(255) null,
   var12 varchar(255) null,
   var13 varchar(255) null,
   var14 varchar(255) null,
   var15 varchar(255) null,
   var16 varchar(255) null,
   var17 varchar(255) null,
   var18 varchar(255) null,
   var19 varchar(255) null,
   var20 varchar(255) null,
   var21 varchar(255) null,
   var22 varchar(255) null,
   var23 varchar(255) null,
   var24 varchar(255) null,
   var25 varchar(255) null,
   categories varchar(255) null,
   primary key (inode)
);
alter table ecom_product_price add constraint fkf3aa85f65fb51eb foreign key (inode) references inode;
create index idx_entity_1 on entity (entity_name);
alter table entity add constraint fkb29de3e35fb51eb foreign key (inode) references inode;
create index idx_user_comments_1 on user_comments (user_id);
alter table user_comments add constraint fkdf1b37e85fb51eb foreign key (inode) references inode;
create index idx_trackback_2 on trackback (url);
create index idx_trackback_1 on trackback (asset_identifier);
create index idx_communication_user_id on recipient (user_id);
create index idx_recipiets_1 on recipient (email);
create index idx_recipiets_2 on recipient (sent);
alter table recipient add constraint fk30e172195fb51eb foreign key (inode) references inode;
create index idx_mailinglist_1 on mailing_list (user_id);
alter table mailing_list add constraint fk7bc2cd925fb51eb foreign key (inode) references inode;
create index idx_user_webform_1 on web_form (form_type);
create index idx_virtual_link_1 on virtual_link (url);
alter table virtual_link add constraint fkd844f8ae5fb51eb foreign key (inode) references inode;
create index idx_event_2 on event (end_date);
create index idx_event_1 on event (start_date);
alter table event add constraint fk5c6729a5fb51eb foreign key (inode) references inode;
create index ix_web_event on web_event (title);
create index ix_web_event_1 on web_event (sort_order);
alter table web_event add constraint fkcfabd1ef5fb51eb foreign key (inode) references inode;
alter table ecom_product add constraint fk24a022ac5fb51eb foreign key (inode) references inode;
alter table template add constraint fkb13acc7a5fb51eb foreign key (inode) references inode;
create index ix_ecom_order_item on ecom_order_item (order_inode);
alter table ecom_order_item add constraint fkebb882875fb51eb foreign key (inode) references inode;
alter table structure add constraint fk89d2d735fb51eb foreign key (inode) references inode;
create index uk_discount_code_id on ecom_discount_code (code_id);
alter table ecom_discount_code add constraint fk994566285fb51eb foreign key (inode) references inode;
create index ix_web_event_registration_3 on web_event_registration (date_posted);
create index ix_web_event_registration_2 on web_event_registration (user_inode);
create index ix_web_event_registration_1 on web_event_registration (event_location_inode);
create index ix_web_event_registration on web_event_registration (event_inode);
alter table web_event_registration add constraint fk60025d095fb51eb foreign key (inode) references inode;
create index idx_permission_2 on permission (permission_type, inode_id);
create index idx_permission_3 on permission (roleid);
alter table recurance add constraint fk457445fc5fb51eb foreign key (inode) references inode;
alter table contentlet add constraint fkfc4ef025fb51eb foreign key (inode) references inode;
alter table workflow_comment add constraint fk94993ddf5fb51eb foreign key (inode) references inode;
alter table report_asset add constraint fk3765ec255fb51eb foreign key (inode) references inode;
create index idx_category_1 on category (category_name);
create index idx_category_2 on category (category_key);
alter table category add constraint fk302bcfe5fb51eb foreign key (inode) references inode;
alter table htmlpage add constraint fkebf39cba5fb51eb foreign key (inode) references inode;
create index idx_chain_link_code_classname on chain_link_code (class_name);
create index idx_preference_1 on user_preferences (preference);
alter table identifier add constraint fk9f88aca95fb51eb foreign key (inode) references inode;
create index idx_user_clickstream11 on clickstream (host_id);
create index idx_user_clickstream12 on clickstream (last_page_id);
create index idx_user_clickstream15 on clickstream (browser_name);
create index idx_user_clickstream_2 on clickstream (user_id);
create index idx_user_clickstream16 on clickstream (browser_version);
create index idx_user_clickstream_1 on clickstream (cookie_id);
create index idx_user_clickstream13 on clickstream (first_page_id);
create index idx_user_clickstream14 on clickstream (operating_system);
create index ix_web_event_location_1 on web_event_location (state);
create index ix_web_event_location on web_event_location (city);
create index ix_web_event_location_3 on web_event_location (end_date);
create index ix_web_event_location_2 on web_event_location (start_date);
alter table web_event_location add constraint fk1d54bc055fb51eb foreign key (inode) references inode;
create index idx_multitree_1 on multi_tree (relation_type);
create index idx_workflow_4 on workflow_task (webasset);
create index idx_workflow_5 on workflow_task (created_by);
create index idx_workflow_2 on workflow_task (belongs_to);
create index idx_workflow_3 on workflow_task (status);
create index idx_workflow_1 on workflow_task (assigned_to);
alter table workflow_task add constraint fk441116055fb51eb foreign key (inode) references inode;
create index idx_click_1 on click (link);
alter table click add constraint fk5a5c5885fb51eb foreign key (inode) references inode;
alter table event_registration add constraint fke1516a3e5fb51eb foreign key (inode) references inode;
create index idx_file_1 on file_asset (mod_user);
alter table file_asset add constraint fk7ed2366d5fb51eb foreign key (inode) references inode;
alter table organization add constraint fk4644ed335fb51eb foreign key (inode) references inode;
alter table facility add constraint fk1dde6ea35fb51eb foreign key (inode) references inode;
create index idx_user_clickstream_request_2 on clickstream_request (request_uri);
create index idx_user_clickstream_request_1 on clickstream_request (clickstream_id);
create index idx_user_clickstream_request_3 on clickstream_request (associated_identifier);
create index idx_campaign_4 on campaign (expiration_date);
create index idx_campaign_3 on campaign (completed_date);
create index idx_campaign_2 on campaign (start_date);
create index idx_campaign_1 on campaign (user_id);
alter table campaign add constraint fkf7a901105fb51eb foreign key (inode) references inode;
alter table banner add constraint fkacc57f2c5fb51eb foreign key (inode) references inode;
alter table containers add constraint fk8a844125fb51eb foreign key (inode) references inode;
alter table ecom_order add constraint fkf088284b5fb51eb foreign key (inode) references inode;
create index ix_web_event_attendee on web_event_attendee (event_registration_inode);
create index ix_web_event_attendee_1 on web_event_attendee (first_name);
create index ix_web_event_attendee_2 on web_event_attendee (last_name);
alter table web_event_attendee add constraint fkcc5ee90a5fb51eb foreign key (inode) references inode;
alter table communication add constraint fkc24acfd65fb51eb foreign key (inode) references inode;
alter table workflow_history add constraint fk933334145fb51eb foreign key (inode) references inode;
alter table links add constraint fk6234fb95fb51eb foreign key (inode) references inode;
alter table event_recurrence add constraint fk29da39f55fb51eb foreign key (inode) references inode;
alter table user_proxy add constraint fk7327d4fa5fb51eb foreign key (inode) references inode;
create index idx_folder_1 on folder (name);
alter table folder add constraint fkb45d1c6e5fb51eb foreign key (inode) references inode;
create index idx_relationship_1 on relationship (parent_structure_inode);
create index idx_relationship_2 on relationship (child_structure_inode);
alter table relationship add constraint fkf06476385fb51eb foreign key (inode) references inode;
create index idx_field_1 on field (structure_inode);
alter table field add constraint fk5cea0fa5fb51eb foreign key (inode) references inode;
alter table ecom_product_format add constraint fk706fb8ea5fb51eb foreign key (inode) references inode;
alter table report_parameter add constraint fk22da125e5fb51eb foreign key (inode) references inode;
create index idx_chain_key_name on chain (key_name);
create index idx_index_2 on inode (identifier);
create index idx_index_1 on inode (type);
alter table user_filter add constraint fke042126c5fb51eb foreign key (inode) references inode;
--mssql
CREATE INDEX idx_tree ON tree (child, parent, relation_type);
CREATE INDEX idx_tree_1 ON tree (parent);
CREATE INDEX idx_tree_2 ON tree (child);
CREATE INDEX idx_tree_3 ON tree (relation_type);
CREATE INDEX idx_tree_4 ON tree (parent, child, relation_type);
CREATE INDEX idx_tree_5 ON tree (parent, relation_type);
CREATE INDEX idx_tree_6 ON tree (child, relation_type);
CREATE INDEX idx_contentlet_1 ON contentlet (inode, live);
CREATE INDEX idx_contentlet_2 ON contentlet (inode, working);

CREATE INDEX idx_contentlet_3 ON contentlet (inode);

CREATE INDEX idx_identifier ON identifier (inode);
CREATE INDEX idx_permisision_4 ON permission (permission_type);


CREATE INDEX idx_permission_reference_2 ON permission_reference (reference_id);
CREATE INDEX idx_permission_reference_3 ON permission_reference (reference_id,permission_type);
CREATE INDEX idx_permission_reference_4 ON permission_reference (asset_id,permission_type);
CREATE INDEX idx_permission_reference_5 ON permission_reference (asset_id,reference_id,permission_type);
CREATE INDEX idx_permission_reference_6 ON permission_reference (permission_type);

CREATE UNIQUE INDEX idx_field_velocity_structure ON field (velocity_var_name,structure_inode); 
 

alter table tree add constraint FK36739EC4AB08AA foreign key (parent) references inode;
alter table tree add constraint FK36739E5A3F51C foreign key (child) references inode;

alter table chain_state add constraint fk_state_chain foreign key (chain_id) references chain(id);
alter table chain_state add constraint fk_state_code foreign key (link_code_id) references chain_link_code(id);
alter table chain_state_parameter add constraint fk_parameter_state foreign key (chain_state_id) references chain_state(id);

alter table permission add constraint permission_inode_fk foreign key (inode_id) references inode(inode);
alter table permission add constraint permission_role_fk foreign key (roleid) references cms_role(id);

alter table permission_reference add constraint permission_asset_id_fk foreign key (asset_id) references inode(inode);
alter table permission_reference add constraint permission_reference_id_fk foreign key (reference_id) references inode(inode);

alter table contentlet add constraint FK_structure_inode foreign key (structure_inode) references structure(inode);

ALTER TABLE structure ALTER COLUMN fixed tinyint NOT NULL;
alter table structure add CONSTRAINT [DF_structure_fixed]  DEFAULT ((0)) for fixed;

ALTER TABLE field ALTER COLUMN fixed tinyint NOT NULL; 
ALTER TABLE field ALTER COLUMN read_only tinyint  NOT NULL;
ALTER TABLE campaign ALTER COLUMN active tinyint NOT NULL; 
alter table field add CONSTRAINT [DF_field_fixed]  DEFAULT ((0)) for fixed;
alter table field add CONSTRAINT [DF_field_read_only]  DEFAULT ((0)) for read_only;

insert into User_ (userId, companyId, createDate, password_, passwordEncrypted, passwordReset, firstName, middleName, lastName, male, birthday, emailAddress, skinId, dottedSkins, roundedSkins, greeting, layoutIds, loginDate, failedLoginAttempts, agreedToTermsOfUse, active_) values ('dotcms.org.default', 'default', GetDate(), 'password', '0', '0', '', '', '', '1', '19700101', 'default@dotcms.org', '01', '0', '0', 'Welcome!', '', GetDate(), 0, '0', '1');

create index addres_userid_index on address(userid);
create index tag_user_id_index on tag(user_id);
create index tag_inode_tagname on tag_inode(tagname);
create index tag_inode_inode on tag_inode(inode);
CREATE TABLE dist_journal
	   (
       id bigint NOT NULL IDENTITY (1, 1),
       object_to_index VARCHAR(1024) NOT NULL,
       serverid varchar(64) NOT NULL,
       journal_type int NOT NULL,
       time_entered datetime NOT NULL
       ) ;

ALTER TABLE dist_journal ADD CONSTRAINT
       PK_dist_journal PRIMARY KEY CLUSTERED
       (
       id
       );


ALTER TABLE dist_journal ADD CONSTRAINT
       IX_dist_journal UNIQUE NONCLUSTERED
       (
       object_to_index,
       serverid,
       journal_type
       );
CREATE TABLE dist_process ( id bigint NOT NULL IDENTITY (1, 1), object_to_index varchar(1024) NOT NULL, serverid varchar(64) NOT NULL, journal_type int NOT NULL, time_entered datetime NOT NULL ) ;
ALTER TABLE dist_process ADD CONSTRAINT PK_dist_process PRIMARY KEY CLUSTERED ( id);
	
create table plugin_property (
   plugin_id varchar(255) not null,
   propkey varchar(255) not null,
   original_value varchar(255) not null,
   current_value varchar(255) not null,
   primary key (plugin_id, propkey)
);

alter table plugin_property add constraint fk_plugin_plugin_property foreign key (plugin_id) references plugin(id);

CREATE TABLE dist_reindex_journal ( id bigint NOT NULL IDENTITY (1, 1), inode_to_index varchar(100) NOT NULL,ident_to_index varchar(100) NOT NULL, serverid varchar(64) NOT NULL, priority int NOT NULL, time_entered datetime DEFAULT getDate(), index_val varchar(325),dist_action integer NOT NULL DEFAULT 1);
	
CREATE INDEX dist_reindex_index1 on dist_reindex_journal (inode_to_index);
CREATE INDEX dist_reindex_index2 on dist_reindex_journal (dist_action);
CREATE INDEX dist_reindex_index3 on dist_reindex_journal (serverid);
CREATE INDEX dist_reindex_index on dist_reindex_journal (serverid,dist_action);

ALTER TABLE dist_reindex_journal ADD CONSTRAINT PK_dist_reindex_journal PRIMARY KEY CLUSTERED ( id);

CREATE TABLE quartz_log ( id bigint NOT NULL IDENTITY (1, 1), JOB_NAME varchar(255) NOT NULL, serverid varchar(64) , time_started datetime NOT NULL, primary key (id));

CREATE TRIGGER check_role_key_uniqueness
ON cms_role
FOR INSERT, UPDATE
AS
DECLARE @c varchar(100)
SELECT @c = count(*)
FROM cms_role e INNER JOIN inserted i ON i.role_key = e.role_key WHERE i.role_key IS NOT NULL AND i.id <> e.id
IF (@c > 0)  
BEGIN
   RAISERROR ('Duplicated role key.', 16, 1)
   ROLLBACK TRANSACTION
END;

CREATE TRIGGER check_identifier_host_inode
ON identifier
FOR INSERT, UPDATE AS
DECLARE @uri varchar(10) 
DECLARE @hostInode varchar(50)
DECLARE cur_Inserted cursor for
 Select uri, host_inode
 from inserted 
 for Read Only
open cur_Inserted
fetch next from cur_Inserted into @uri,@hostInode 
while @@FETCH_STATUS <> -1
BEGIN
 IF(@uri <> 'content' AND (@hostInode is null OR @hostInode = ''))
 BEGIN
	RAISERROR (N'Cannot insert/update a null or empty host inode for this kind of identifier', 10, 1)
	ROLLBACK WORK
 END
fetch next from cur_Inserted into @uri,@hostInode
END;

ALTER TABLE cms_role ADD CONSTRAINT IX_cms_role2 UNIQUE NONCLUSTERED (db_fqn);
alter table cms_role add constraint fkcms_role_parent foreign key (parent) references cms_role;

ALTER TABLE users_cms_roles ADD CONSTRAINT IX_cms_role UNIQUE NONCLUSTERED (role_id, user_id);
alter table users_cms_roles add constraint fkusers_cms_roles1 foreign key (role_id) references cms_role;
alter table users_cms_roles add constraint fkusers_cms_roles2 foreign key (user_id) references user_;

ALTER TABLE cms_layout ADD CONSTRAINT IX_cms_layout UNIQUE NONCLUSTERED (layout_name); 

ALTER TABLE portlet ADD CONSTRAINT IX_portletid UNIQUE NONCLUSTERED (portletid);

ALTER TABLE cms_layouts_portlets ADD CONSTRAINT IX_cms_layouts_portlets UNIQUE NONCLUSTERED (portlet_id, layout_id); 
alter table cms_layouts_portlets add constraint fklcms_layouts_portlets foreign key (layout_id) references cms_layout;

ALTER TABLE layouts_cms_roles ADD CONSTRAINT IX_layouts_cms_roles UNIQUE NONCLUSTERED (role_id, layout_id); 
alter table layouts_cms_roles add constraint fklayouts_cms_roles1 foreign key (role_id) references cms_role;
alter table layouts_cms_roles add constraint fklayouts_cms_roles2 foreign key (layout_id) references cms_layout;

alter table contentlet add constraint fk_folder foreign key (folder) references folder(inode);


create table dist_reindex_lock (dummy int);
create table dist_lock (dummy int);
insert into dist_reindex_lock (dummy) values (1);
insert into dist_lock (dummy) values (1);

create table import_audit (
	id bigint not null,
	start_date datetime,
	userid varchar(255), 
	filename varchar(512),
	status int,
	last_inode varchar(100),
	records_to_import bigint,
	serverid varchar(255),
	primary key (id)
	);
	
alter table category alter column category_velocity_var_name varchar(255) not null;
