create table ABContact (
	contactId varchar(100) not null primary key,
	userId varchar(100) not null,
	firstName varchar(100) null,
	middleName varchar(100) null,
	lastName varchar(100) null,
	nickName varchar(100) null,
	emailAddress varchar(100) null,
	homeStreet varchar(100) null,
	homeCity varchar(100) null,
	homeState varchar(100) null,
	homeZip varchar(100) null,
	homeCountry varchar(100) null,
	homePhone varchar(100) null,
	homeFax varchar(100) null,
	homeCell varchar(100) null,
	homePager varchar(100) null,
	homeTollFree varchar(100) null,
	homeEmailAddress varchar(100) null,
	businessCompany varchar(100) null,
	businessStreet varchar(100) null,
	businessCity varchar(100) null,
	businessState varchar(100) null,
	businessZip varchar(100) null,
	businessCountry varchar(100) null,
	businessPhone varchar(100) null,
	businessFax varchar(100) null,
	businessCell varchar(100) null,
	businessPager varchar(100) null,
	businessTollFree varchar(100) null,
	businessEmailAddress varchar(100) null,
	employeeNumber varchar(100) null,
	jobTitle varchar(100) null,
	jobClass varchar(100) null,
	hoursOfOperation longtext null,
	birthday datetime null,
	timeZoneId varchar(100) null,
	instantMessenger varchar(100) null,
	website varchar(100) null,
	comments longtext null
);

create table ABContacts_ABLists (
	contactId varchar(100) not null,
	listId varchar(100) not null
);

create table ABList (
	listId varchar(100) not null primary key,
	userId varchar(100) not null,
	name varchar(100) null
);

create table Address (
	addressId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	className varchar(100) null,
	classPK varchar(100) null,
	description varchar(100) null,
	street1 varchar(100) null,
	street2 varchar(100) null,
	city varchar(100) null,
	state varchar(100) null,
	zip varchar(100) null,
	country varchar(100) null,
	phone varchar(100) null,
	fax varchar(100) null,
	cell varchar(100) null,
	priority integer
);

create table AdminConfig (
	configId varchar(100) not null primary key,
	companyId varchar(100) not null,
	type_ varchar(100) null,
	name varchar(100) null,
	config longtext null
);

create table BJEntries_BJTopics (
	entryId varchar(100) not null,
	topicId varchar(100) not null
);

create table BJEntries_BJVerses (
	entryId varchar(100) not null,
	verseId varchar(100) not null
);

create table BJEntry (
	entryId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	name varchar(100) null,
	content longtext null,
	versesInput longtext null
);

create table BJTopic (
	topicId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	name varchar(100) null,
	description longtext null
);

create table BJVerse (
	verseId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	name varchar(100) null
);

create table BlogsCategory (
	categoryId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	name varchar(100) null
);

create table BlogsComments (
	commentsId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	entryId varchar(100) null,
	content longtext null
);

create table BlogsEntry (
	entryId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	categoryId varchar(100) null,
	title varchar(100) null,
	content longtext null,
	displayDate datetime null,
	sharing tinyint,
	commentable tinyint,
	propsCount integer,
	commentsCount integer
);

create table BlogsLink (
	linkId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	name varchar(100) null,
	url varchar(100) null
);

create table BlogsProps (
	propsId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	entryId varchar(100) null,
	quantity integer
);

create table BlogsReferer (
	entryId varchar(100) not null,
	url varchar(100) not null,
	type_ varchar(100) not null,
	quantity integer,
	primary key (entryId, url, type_)
);

create table BlogsUser (
	userId varchar(100) not null primary key,
	companyId varchar(100) not null,
	entryId varchar(100) not null,
	lastPostDate datetime null
);

create table BookmarksEntry (
	entryId varchar(100) not null primary key,
	userId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	folderId varchar(100) null,
	name varchar(100) null,
	url varchar(100) null,
	comments longtext null,
	visits integer
);

create table BookmarksFolder (
	folderId varchar(100) not null primary key,
	userId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	parentFolderId varchar(100) null,
	name varchar(100) null
);

create table CalEvent (
	eventId varchar(100) not null primary key,
	groupId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	title varchar(100) null,
	description longtext null,
	startDate datetime null,
	endDate datetime null,
	durationHour integer,
	durationMinute integer,
	allDay tinyint,
	timeZoneSensitive tinyint,
	type_ varchar(100) null,
	location varchar(100) null,
	street varchar(100) null,
	city varchar(100) null,
	state varchar(100) null,
	zip varchar(100) null,
	phone varchar(100) null,
	repeating tinyint,
	recurrence longtext null,
	remindBy varchar(100) null,
	firstReminder integer,
	secondReminder integer
);

create table CalTask (
	taskId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	title varchar(100) null,
	description longtext null,
	noDueDate tinyint,
	dueDate datetime null,
	priority integer,
	status integer
);

create table Company (
	companyId varchar(100) not null primary key,
	key_ longtext null,
	portalURL varchar(100) not null,
	homeURL varchar(100) not null,
	mx varchar(100) not null,
	name varchar(100) not null,
	shortName varchar(100) not null,
	type_ varchar(100) null,
	size_ varchar(100) null,
	street varchar(100) null,
	city varchar(100) null,
	state varchar(100) null,
	zip varchar(100) null,
	phone varchar(100) null,
	fax varchar(100) null,
	emailAddress varchar(100) null,
	authType varchar(100) null,
	autoLogin tinyint,
	strangers tinyint
);

create table Counter (
	name varchar(100) not null primary key,
	currentId integer
);

create table CyrusUser (
	userId varchar(100) not null primary key,
	password_ varchar(100) not null
);

create table CyrusVirtual (
	emailAddress varchar(100) not null primary key,
	userId varchar(100) not null
);

create table DLFileProfile (
	companyId varchar(100) not null,
	repositoryId varchar(100) not null,
	fileName varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	versionUserId varchar(100) not null,
	versionUserName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	readRoles varchar(100) null,
	writeRoles varchar(100) null,
	description longtext null,
	version double,
	size_ integer,
	primary key (companyId, repositoryId, fileName)
);

create table DLFileRank (
	companyId varchar(100) not null,
	userId varchar(100) not null,
	repositoryId varchar(100) not null,
	fileName varchar(100) not null,
	createDate datetime null,
	primary key (companyId, userId, repositoryId)
);

create table DLFileVersion (
	companyId varchar(100) not null,
	repositoryId varchar(100) not null,
	fileName varchar(100) not null,
	version double not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	size_ integer,
	primary key (companyId, repositoryId, fileName, version)
);

create table DLRepository (
	repositoryId varchar(100) not null primary key,
	groupId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	readRoles varchar(100) null,
	writeRoles varchar(100) null,
	name varchar(100) null,
	description longtext null,
	lastPostDate datetime null
);

create table IGFolder (
	folderId varchar(100) not null primary key,
	groupId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	parentFolderId varchar(100) null,
	name varchar(100) null
);

create table IGImage (
	imageId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	folderId varchar(100) null,
	description longtext null,
	height integer,
	width integer,
	size_ integer,
	primary key (imageId, companyId)
);

create table Image (
	imageId varchar(200) not null primary key,
	text_ longtext not null
);

create table JournalArticle (
	articleId varchar(100) not null,
	version double not null,
	portletId varchar(100) not null,
	groupId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	title varchar(100) null,
	content longtext null,
	type_ varchar(100) null,
	structureId varchar(100) null,
	templateId varchar(100) null,
	displayDate datetime null,
	expirationDate datetime null,
	approved tinyint,
	approvedByUserId varchar(100) null,
	approvedByUserName varchar(100) null,
	primary key (articleId, version)
);

create table JournalStructure (
	structureId varchar(100) not null primary key,
	portletId varchar(100) not null,
	groupId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	name varchar(100) null,
	description longtext null,
	xsd longtext null
);

create table JournalTemplate (
	templateId varchar(100) not null primary key,
	portletId varchar(100) not null,
	groupId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	structureId varchar(100) null,
	name varchar(100) null,
	description longtext null,
	xsl longtext null,
	smallImage tinyint,
	smallImageURL varchar(100) null
);

create table Layer (
	layerId varchar(100) not null,
	skinId varchar(100) not null,
	href varchar(100) null,
	hrefHover varchar(100) null,
	background varchar(100) null,
	foreground varchar(100) null,
	negAlert varchar(100) null,
	posAlert varchar(100) null,
	primary key (layerId, skinId)
);

create table MailReceipt (
	receiptId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	recipientName varchar(100) null,
	recipientAddress varchar(100) null,
	subject varchar(100) null,
	sentDate datetime null,
	readCount integer,
	firstReadDate datetime null,
	lastReadDate datetime null
);

create table MBMessage (
	messageId varchar(100) not null,
	topicId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	threadId varchar(100) null,
	parentMessageId varchar(100) null,
	subject varchar(100) null,
	body longtext null,
	attachments tinyint,
	anonymous tinyint,
	primary key (messageId, topicId)
);

create table MBMessageFlag (
	topicId varchar(100) not null,
	messageId varchar(100) not null,
	userId varchar(100) not null,
	flag varchar(100) null,
	primary key (topicId, messageId, userId)
);

create table MBThread (
	threadId varchar(100) not null primary key,
	rootMessageId varchar(100) null,
	topicId varchar(100) null,
	messageCount integer,
	lastPostDate datetime null
);

create table MBTopic (
	topicId varchar(100) not null primary key,
	portletId varchar(100) not null,
	groupId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	readRoles varchar(100) null,
	writeRoles varchar(100) null,
	name varchar(100) null,
	description longtext null,
	lastPostDate datetime null
);

create table NetworkAddress (
	addressId varchar(100) not null primary key,
	userId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	name varchar(100) null,
	url varchar(100) null,
	comments longtext null,
	content longtext null,
	status integer,
	lastUpdated datetime null,
	notifyBy varchar(100) null,
	interval_ integer,
	active_ tinyint
);

create table Note (
	noteId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	className varchar(100) null,
	classPK varchar(100) null,
	content longtext null
);

create table PasswordTracker (
	passwordTrackerId varchar(100) not null primary key,
	userId varchar(100) not null,
	createDate datetime not null,
	password_ varchar(100) not null
);

create table PollsChoice (
	choiceId varchar(100) not null,
	questionId varchar(100) not null,
	description longtext null,
	primary key (choiceId, questionId)
);

create table PollsDisplay (
	layoutId varchar(100) not null,
	userId varchar(100) not null,
	portletId varchar(100) not null,
	questionId varchar(100) not null,
	primary key (layoutId, userId, portletId)
);

create table PollsQuestion (
	questionId varchar(100) not null primary key,
	portletId varchar(100) not null,
	groupId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	title varchar(100) null,
	description longtext null,
	expirationDate datetime null,
	lastVoteDate datetime null
);

create table PollsVote (
	questionId varchar(100) not null,
	userId varchar(100) not null,
	choiceId varchar(100) not null,
	voteDate datetime null,
	primary key (questionId, userId)
);

create table Portlet (
	portletId varchar(100) not null,
	groupId varchar(100) not null,
	companyId varchar(100) not null,
	defaultPreferences longtext null,
	narrow tinyint,
	roles longtext null,
	active_ tinyint,
	primary key (portletId, groupId, companyId)
);

create table PortletPreferences (
	portletId varchar(100) not null,
	userId varchar(100) not null,
	layoutId varchar(100) not null,
	preferences longtext null,
	primary key (portletId, userId, layoutId)
);

create table ProjFirm (
	firmId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	name varchar(100) null,
	description longtext null,
	url varchar(100) null
);

create table ProjProject (
	projectId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	firmId varchar(100) null,
	code varchar(100) null,
	name varchar(100) null,
	description longtext null
);

create table ProjTask (
	taskId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	projectId varchar(100) null,
	name varchar(100) null,
	description longtext null,
	comments longtext null,
	estimatedDuration integer,
	estimatedEndDate datetime null,
	actualDuration integer,
	actualEndDate datetime null,
	status integer
);

create table ProjTime (
	timeId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	projectId varchar(100) null,
	taskId varchar(100) null,
	description longtext null,
	startDate datetime null,
	endDate datetime null
);

create table Release_ (
	releaseId varchar(100) not null primary key,
	createDate datetime null,
	modifiedDate datetime null,
	buildNumber integer null,
	buildDate datetime null
);

create table Skin (
	skinId varchar(100) not null primary key,
	name varchar(100) null,
	imageId varchar(100) null,
	alphaLayerId varchar(100) null,
	alphaSkinId varchar(100) null,
	betaLayerId varchar(100) null,
	betaSkinId varchar(100) null,
	gammaLayerId varchar(100) null,
	gammaSkinId varchar(100) null,
	bgLayerId varchar(100) null,
	bgSkinId varchar(100) null
);

create table ShoppingCart (
	cartId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	itemIds longtext null,
	couponIds longtext null,
	altShipping integer
);

create table ShoppingCategory (
	categoryId varchar(100) not null primary key,
	companyId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	parentCategoryId varchar(100) null,
	name varchar(100) null
);

create table ShoppingCoupon (
	couponId varchar(100) not null primary key,
	companyId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	name varchar(100) null,
	description longtext null,
	startDate datetime null,
	endDate datetime null,
	active_ tinyint,
	limitCategories longtext null,
	limitSkus longtext null,
	minOrder double,
	discount double,
	discountType varchar(100) null
);

create table ShoppingItem (
	itemId varchar(100) not null primary key,
	companyId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	categoryId varchar(100) null,
	sku varchar(100) null,
	name varchar(100) null,
	description longtext null,
	properties longtext null,
	supplierUserId varchar(100) null,
	fields_ tinyint,
	fieldsQuantities longtext null,
	minQuantity integer,
	maxQuantity integer,
	price double,
	discount double,
	taxable tinyint,
	shipping double,
	useShippingFormula tinyint,
	requiresShipping tinyint,
	stockQuantity integer,
	featured_ tinyint,
	sale_ tinyint,
	smallImage tinyint,
	smallImageURL varchar(100) null,
	mediumImage tinyint,
	mediumImageURL varchar(100) null,
	largeImage tinyint,
	largeImageURL varchar(100) null
);

create table ShoppingItemField (
	itemFieldId varchar(100) not null primary key,
	itemId varchar(100) null,
	name varchar(100) null,
	values_ longtext null,
	description longtext null
);

create table ShoppingItemPrice (
	itemPriceId varchar(100) not null primary key,
	itemId varchar(100) null,
	minQuantity integer,
	maxQuantity integer,
	price double,
	discount double,
	taxable tinyint,
	shipping double,
	useShippingFormula tinyint,
	status integer
);

create table ShoppingOrder (
	orderId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate datetime null,
	modifiedDate datetime null,
	tax double,
	shipping double,
	altShipping varchar(100),
	requiresShipping tinyint,
	couponIds longtext null,
	couponDiscount double,
	billingFirstName varchar(100) null,
	billingLastName varchar(100) null,
	billingEmailAddress varchar(100) null,
	billingCompany varchar(100) null,
	billingStreet varchar(100) null,
	billingCity varchar(100) null,
	billingState varchar(100) null,
	billingZip varchar(100) null,
	billingCountry varchar(100) null,
	billingPhone varchar(100) null,
	shipToBilling tinyint,
	shippingFirstName varchar(100) null,
	shippingLastName varchar(100) null,
	shippingEmailAddress varchar(100) null,
	shippingCompany varchar(100) null,
	shippingStreet varchar(100) null,
	shippingCity varchar(100) null,
	shippingState varchar(100) null,
	shippingZip varchar(100) null,
	shippingCountry varchar(100) null,
	shippingPhone varchar(100) null,
	ccName varchar(100) null,
	ccType varchar(100) null,
	ccNumber varchar(100) null,
	ccExpMonth integer,
	ccExpYear integer,
	ccVerNumber varchar(100) null,
	comments longtext null,
	ppTxnId varchar(100) null,
	ppPaymentStatus varchar(100) null,
	ppPaymentGross double,
	ppReceiverEmail varchar(100) null,
	ppPayerEmail varchar(100) null,
	sendOrderEmail tinyint,
	sendShippingEmail tinyint
);

create table ShoppingOrderItem (
	orderId varchar(100) not null,
	itemId varchar(100) not null,
	sku varchar(100) null,
	name varchar(100) null,
	description longtext null,
	properties longtext null,
	supplierUserId varchar(100) null,
	price double,
	quantity integer,
	shippedDate datetime null,
	primary key (orderId, itemId)
);

create table User_ (
	userId varchar(100) not null primary key,
	companyId varchar(100) not null,
	createDate datetime null,
	password_ varchar(100) null,
	passwordEncrypted tinyint,
	passwordExpirationDate datetime null,
	passwordReset tinyint,
	firstName varchar(100) null,
	middleName varchar(100) null,
	lastName varchar(100) null,
	nickName varchar(100) null,
	male tinyint,
	birthday datetime null,
	emailAddress varchar(100) null,
	smsId varchar(100) null,
	aimId varchar(100) null,
	icqId varchar(100) null,
	msnId varchar(100) null,
	ymId varchar(100) null,
	favoriteActivity varchar(100) null,
	favoriteBibleVerse varchar(100) null,
	favoriteFood varchar(100) null,
	favoriteMovie varchar(100) null,
	favoriteMusic varchar(100) null,
	languageId varchar(100) null,
	timeZoneId varchar(100) null,
	skinId varchar(100) null,
	dottedSkins tinyint,
	roundedSkins tinyint,
	greeting varchar(100) null,
	resolution varchar(100) null,
	refreshRate varchar(100) null,
	layoutIds varchar(100) null,
	comments longtext null,
	loginDate datetime null,
	loginIP varchar(100) null,
	lastLoginDate datetime null,
	lastLoginIP varchar(100) null,
	failedLoginAttempts integer,
	agreedToTermsOfUse tinyint,
	active_ tinyint
);

create table Users_ProjProjects (
	userId varchar(100) not null,
	projectId varchar(100) not null
);

create table Users_ProjTasks (
	userId varchar(100) not null,
	taskId varchar(100) not null
);

create table UserTracker (
	userTrackerId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	modifiedDate datetime null,
	remoteAddr varchar(100) null,
	remoteHost varchar(100) null,
	userAgent varchar(100) null
);

create table UserTrackerPath (
	userTrackerPathId varchar(100) not null primary key,
	userTrackerId varchar(100) not null,
	path longtext not null,
	pathDate datetime not null
);

create table WikiDisplay (
	layoutId varchar(100) not null,
	userId varchar(100) not null,
	portletId varchar(100) not null,
	nodeId varchar(100) not null,
	showBorders tinyint,
	primary key (layoutId, userId, portletId)
);

create table WikiNode (
	nodeId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	modifiedDate datetime null,
	readRoles varchar(100) null,
	writeRoles varchar(100) null,
	name varchar(100) null,
	description longtext null,
	sharing tinyint,
	lastPostDate datetime null
);

create table WikiPage (
	nodeId varchar(100) not null,
	title varchar(100) not null,
	version double not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate datetime null,
	content longtext null,
	format varchar(100) null,
	head tinyint,
	primary key (nodeId, title, version)
);

##
## Global
##

insert into Counter values ('com.liferay.portal.model.Address', 10);
insert into Counter values ('com.liferay.portal.model.Group', 20);
insert into Counter values ('com.liferay.portal.model.Role', 100);
insert into Counter values ('com.liferay.portal.model.User.liferay.com', 10);
insert into Counter values ('com.liferay.portlet.imagegallery.model.IGFolder', 20);
insert into Counter values ('com.liferay.portlet.imagegallery.model.IGImage.liferay.com', 42);
insert into Counter values ('com.liferay.portlet.polls.model.PollsQuestion', 10);
insert into Counter values ('com.liferay.portlet.shopping.model.ShoppingCategory', 20);
insert into Counter values ('com.liferay.portlet.shopping.ejb.ShoppingItem', 40);
insert into Counter values ('com.liferay.portlet.wiki.model.WikiNode', 10);

##
## Liferay, LLC
##

insert into Company (companyId, portalURL, homeURL, mx, name, shortName, type_, size_, emailAddress, authType, autoLogin, strangers) values ('liferay.com', 'localhost', 'localhost', 'liferay.com', 'Liferay, LLC', 'Liferay', 'biz', '', 'test@liferay.com', 'emailAddress', '1', '1');
update Company set street = '1220 Brea Canyon Rd.', city = 'Diamond Bar', state = 'CA', zip = '91789' where companyId = 'liferay.com';

insert into PollsDisplay (layoutId, userId, portletId, questionId) values ('1.1', 'group.1', '59', '1');
insert into PollsChoice (choiceId, questionId, description) values ('a', '1', 'Chocolate');
insert into PollsChoice (choiceId, questionId, description) values ('b', '1', 'Strawberry');
insert into PollsChoice (choiceId, questionId, description) values ('c', '1', 'Vanilla');
insert into PollsQuestion (questionId, portletId, groupId, companyId, userId, userName, createDate, modifiedDate, title, description) values ('1', '25', '-1', 'liferay.com', 'liferay.com.1', 'John Wayne', now(), now(), 'What is your favorite ice cream flavor?', 'What is your favorite ice cream flavor?');

insert into WikiDisplay (layoutId, userId, portletId, nodeId, showBorders) values ('1.1', 'group.1', '54', '1', '1');
insert into WikiNode (nodeId, companyId, userId, userName, createDate, modifiedDate, readRoles, writeRoles, name, description, sharing, lastPostDate) values ('1', 'liferay.com', 'liferay.com.1', 'John Wayne', now(), now(), 'User,' ,'User,', 'Welcome', '', '1', now());
insert into WikiPage (nodeId, title, version, companyId, userId, userName, createDate, content, format, head) values ('1', 'FrontPage', 1.0, 'liferay.com', 'liferay.com.1', 'John Wayne', now(), '<font class="bg" size="2">Welcome! Thank you for your interest in Liferay Enterprise Portal.<br><br>Your login is <b>test@liferay.com</b> and your password is <b>test</b>. The test user has the Administrator role.<br><br>To use the <b>Mail</b> portlet, make sure there is a mail server running on <i>localhost</i> accessible through the IMAP protocol.<br><br>The mail server must have an account with <b>liferay.com.1</b> as the user and <b>test</b> as the password.<br><br><hr><br>Is Liferay useful for your company? Tell us about it by email at <b>staff@liferay.com</b>.<br><br>We hope you enjoy our product!</font>', 'html', '1');

##
## Default User
##

insert into User_ (userId, companyId, createDate, password_, passwordEncrypted, passwordReset, firstName, middleName, lastName, male, birthday, emailAddress, skinId, dottedSkins, roundedSkins, greeting, layoutIds, loginDate, failedLoginAttempts, agreedToTermsOfUse, active_) values ('liferay.com.default', 'default', now(), 'password', '0', '0', '', '', '', '1', '1970-01-01', 'default@liferay.com', '01', '0', '0', 'Welcome!', '', now(), 0, '0', '1');

##
## Test User
##

insert into User_ (userId, companyId, createDate, password_, passwordEncrypted, passwordReset, firstName, middleName, lastName, nickName, male, birthday, emailAddress, skinId, dottedSkins, roundedSkins, greeting, layoutIds, loginDate, failedLoginAttempts, agreedToTermsOfUse, active_) values ('liferay.com.1', 'liferay.com', now(), 'test', '0', '0', 'John', '', 'Wayne', 'Duke', '1', '1970-01-01', 'test@liferay.com', '01', '0', '1', 'Welcome John Wayne!', '1,', now(), 0, '1', '1');
CREATE TABLE QRTZ_JOB_DETAILS
  (
    JOB_NAME  VARCHAR(80) NOT NULL,
    JOB_GROUP VARCHAR(80) NOT NULL,
    DESCRIPTION VARCHAR(120) NULL,
    JOB_CLASS_NAME   VARCHAR(128) NOT NULL,
    IS_DURABLE tinyint(1) NOT NULL,
    IS_VOLATILE tinyint(1) NOT NULL,
    IS_STATEFUL tinyint(1) NOT NULL,
    REQUESTS_RECOVERY tinyint(1) NOT NULL,
    JOB_DATA BLOB NULL,
    PRIMARY KEY (JOB_NAME,JOB_GROUP)
);

CREATE TABLE QRTZ_JOB_LISTENERS
  (
    JOB_NAME  VARCHAR(80) NOT NULL,
    JOB_GROUP VARCHAR(80) NOT NULL,
    JOB_LISTENER VARCHAR(80) NOT NULL,
    PRIMARY KEY (JOB_NAME,JOB_GROUP,JOB_LISTENER),
    FOREIGN KEY (JOB_NAME,JOB_GROUP)
        REFERENCES QRTZ_JOB_DETAILS(JOB_NAME,JOB_GROUP)
);

CREATE TABLE QRTZ_TRIGGERS
  (
    TRIGGER_NAME VARCHAR(80) NOT NULL,
    TRIGGER_GROUP VARCHAR(80) NOT NULL,
    JOB_NAME  VARCHAR(80) NOT NULL,
    JOB_GROUP VARCHAR(80) NOT NULL,
    IS_VOLATILE tinyint(1) NOT NULL,
    DESCRIPTION VARCHAR(120) NULL,
    NEXT_FIRE_TIME BIGINT(13) NULL,
    PREV_FIRE_TIME BIGINT(13) NULL,
    PRIORITY INTEGER NULL,
    TRIGGER_STATE VARCHAR(16) NOT NULL,
    TRIGGER_TYPE VARCHAR(8) NOT NULL,
    START_TIME BIGINT(13) NOT NULL,
    END_TIME BIGINT(13) NULL,
    CALENDAR_NAME VARCHAR(80) NULL,
    MISFIRE_INSTR SMALLINT(2) NULL,
    JOB_DATA BLOB NULL,
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP),
    FOREIGN KEY (JOB_NAME,JOB_GROUP)
        REFERENCES QRTZ_JOB_DETAILS(JOB_NAME,JOB_GROUP)
);

CREATE TABLE QRTZ_SIMPLE_TRIGGERS
  (
    TRIGGER_NAME VARCHAR(80) NOT NULL,
    TRIGGER_GROUP VARCHAR(80) NOT NULL,
    REPEAT_COUNT BIGINT(7) NOT NULL,
    REPEAT_INTERVAL BIGINT(12) NOT NULL,
    TIMES_TRIGGERED BIGINT(7) NOT NULL,
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP),
    FOREIGN KEY (TRIGGER_NAME,TRIGGER_GROUP)
        REFERENCES QRTZ_TRIGGERS(TRIGGER_NAME,TRIGGER_GROUP)
);

CREATE TABLE QRTZ_CRON_TRIGGERS
  (
    TRIGGER_NAME VARCHAR(80) NOT NULL,
    TRIGGER_GROUP VARCHAR(80) NOT NULL,
    CRON_EXPRESSION VARCHAR(80) NOT NULL,
    TIME_ZONE_ID VARCHAR(80),
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP),
    FOREIGN KEY (TRIGGER_NAME,TRIGGER_GROUP)
        REFERENCES QRTZ_TRIGGERS(TRIGGER_NAME,TRIGGER_GROUP)
);

CREATE TABLE QRTZ_BLOB_TRIGGERS
  (
    TRIGGER_NAME VARCHAR(80) NOT NULL,
    TRIGGER_GROUP VARCHAR(80) NOT NULL,
    BLOB_DATA BLOB NULL,
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP),
    FOREIGN KEY (TRIGGER_NAME,TRIGGER_GROUP)
        REFERENCES QRTZ_TRIGGERS(TRIGGER_NAME,TRIGGER_GROUP)
);

CREATE TABLE QRTZ_TRIGGER_LISTENERS
  (
    TRIGGER_NAME  VARCHAR(80) NOT NULL,
    TRIGGER_GROUP VARCHAR(80) NOT NULL,
    TRIGGER_LISTENER VARCHAR(80) NOT NULL,
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP,TRIGGER_LISTENER),
    FOREIGN KEY (TRIGGER_NAME,TRIGGER_GROUP)
        REFERENCES QRTZ_TRIGGERS(TRIGGER_NAME,TRIGGER_GROUP)
);


CREATE TABLE QRTZ_CALENDARS
  (
    CALENDAR_NAME  VARCHAR(80) NOT NULL,
    CALENDAR BLOB NOT NULL,
    PRIMARY KEY (CALENDAR_NAME)
);



CREATE TABLE QRTZ_PAUSED_TRIGGER_GRPS
  (
    TRIGGER_GROUP  VARCHAR(80) NOT NULL, 
    PRIMARY KEY (TRIGGER_GROUP)
);

CREATE TABLE QRTZ_FIRED_TRIGGERS
  (
    ENTRY_ID VARCHAR(95) NOT NULL,
    TRIGGER_NAME VARCHAR(80) NOT NULL,
    TRIGGER_GROUP VARCHAR(80) NOT NULL,
    IS_VOLATILE tinyint(1) NOT NULL,
    INSTANCE_NAME VARCHAR(80) NOT NULL,
    FIRED_TIME BIGINT(13) NOT NULL,
    PRIORITY INTEGER NOT NULL,
    STATE VARCHAR(16) NOT NULL,
    JOB_NAME VARCHAR(80) NULL,
    JOB_GROUP VARCHAR(80) NULL,
    IS_STATEFUL tinyint(1) NULL,
    REQUESTS_RECOVERY tinyint(1) NULL,
    PRIMARY KEY (ENTRY_ID)
);

CREATE TABLE QRTZ_SCHEDULER_STATE
  (
    INSTANCE_NAME VARCHAR(80) NOT NULL,
    LAST_CHECKIN_TIME BIGINT(13) NOT NULL,
    CHECKIN_INTERVAL BIGINT(13) NOT NULL,
    PRIMARY KEY (INSTANCE_NAME)
);

CREATE TABLE QRTZ_LOCKS
  (
    LOCK_NAME  VARCHAR(40) NOT NULL, 
    PRIMARY KEY (LOCK_NAME)
);


INSERT INTO QRTZ_LOCKS values('TRIGGER_ACCESS');
INSERT INTO QRTZ_LOCKS values('JOB_ACCESS');
INSERT INTO QRTZ_LOCKS values('CALENDAR_ACCESS');
INSERT INTO QRTZ_LOCKS values('STATE_ACCESS');
INSERT INTO QRTZ_LOCKS values('MISFIRE_ACCESS');

CREATE TABLE QRTZ_EXCL_JOB_DETAILS
  (
    JOB_NAME  VARCHAR(80) NOT NULL,
    JOB_GROUP VARCHAR(80) NOT NULL,
    DESCRIPTION VARCHAR(120) NULL,
    JOB_CLASS_NAME   VARCHAR(128) NOT NULL,
    IS_DURABLE tinyint(1) NOT NULL,
    IS_VOLATILE tinyint(1) NOT NULL,
    IS_STATEFUL tinyint(1) NOT NULL,
    REQUESTS_RECOVERY tinyint(1) NOT NULL,
    JOB_DATA BLOB NULL,
    PRIMARY KEY (JOB_NAME,JOB_GROUP)
);

CREATE TABLE QRTZ_EXCL_JOB_LISTENERS
  (
    JOB_NAME  VARCHAR(80) NOT NULL,
    JOB_GROUP VARCHAR(80) NOT NULL,
    JOB_LISTENER VARCHAR(80) NOT NULL,
    PRIMARY KEY (JOB_NAME,JOB_GROUP,JOB_LISTENER),
    FOREIGN KEY (JOB_NAME,JOB_GROUP)
        REFERENCES QRTZ_EXCL_JOB_DETAILS(JOB_NAME,JOB_GROUP)
);

CREATE TABLE QRTZ_EXCL_TRIGGERS
  (
    TRIGGER_NAME VARCHAR(80) NOT NULL,
    TRIGGER_GROUP VARCHAR(80) NOT NULL,
    JOB_NAME  VARCHAR(80) NOT NULL,
    JOB_GROUP VARCHAR(80) NOT NULL,
    IS_VOLATILE tinyint(1) NOT NULL,
    DESCRIPTION VARCHAR(120) NULL,
    NEXT_FIRE_TIME BIGINT(13) NULL,
    PREV_FIRE_TIME BIGINT(13) NULL,
    PRIORITY INTEGER NULL,
    TRIGGER_STATE VARCHAR(16) NOT NULL,
    TRIGGER_TYPE VARCHAR(8) NOT NULL,
    START_TIME BIGINT(13) NOT NULL,
    END_TIME BIGINT(13) NULL,
    CALENDAR_NAME VARCHAR(80) NULL,
    MISFIRE_INSTR SMALLINT(2) NULL,
    JOB_DATA BLOB NULL,
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP),
    FOREIGN KEY (JOB_NAME,JOB_GROUP)
        REFERENCES QRTZ_EXCL_JOB_DETAILS(JOB_NAME,JOB_GROUP)
);

CREATE TABLE QRTZ_EXCL_SIMPLE_TRIGGERS
  (
    TRIGGER_NAME VARCHAR(80) NOT NULL,
    TRIGGER_GROUP VARCHAR(80) NOT NULL,
    REPEAT_COUNT BIGINT(7) NOT NULL,
    REPEAT_INTERVAL BIGINT(12) NOT NULL,
    TIMES_TRIGGERED BIGINT(7) NOT NULL,
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP),
    FOREIGN KEY (TRIGGER_NAME,TRIGGER_GROUP)
        REFERENCES QRTZ_EXCL_TRIGGERS(TRIGGER_NAME,TRIGGER_GROUP)
);

CREATE TABLE QRTZ_EXCL_CRON_TRIGGERS
  (
    TRIGGER_NAME VARCHAR(80) NOT NULL,
    TRIGGER_GROUP VARCHAR(80) NOT NULL,
    CRON_EXPRESSION VARCHAR(80) NOT NULL,
    TIME_ZONE_ID VARCHAR(80),
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP),
    FOREIGN KEY (TRIGGER_NAME,TRIGGER_GROUP)
        REFERENCES QRTZ_EXCL_TRIGGERS(TRIGGER_NAME,TRIGGER_GROUP)
);

CREATE TABLE QRTZ_EXCL_BLOB_TRIGGERS
  (
    TRIGGER_NAME VARCHAR(80) NOT NULL,
    TRIGGER_GROUP VARCHAR(80) NOT NULL,
    BLOB_DATA BLOB NULL,
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP),
    FOREIGN KEY (TRIGGER_NAME,TRIGGER_GROUP)
        REFERENCES QRTZ_EXCL_TRIGGERS(TRIGGER_NAME,TRIGGER_GROUP)
);

CREATE TABLE QRTZ_EXCL_TRIGGER_LISTENERS
  (
    TRIGGER_NAME  VARCHAR(80) NOT NULL,
    TRIGGER_GROUP VARCHAR(80) NOT NULL,
    TRIGGER_LISTENER VARCHAR(80) NOT NULL,
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP,TRIGGER_LISTENER),
    FOREIGN KEY (TRIGGER_NAME,TRIGGER_GROUP)
        REFERENCES QRTZ_EXCL_TRIGGERS(TRIGGER_NAME,TRIGGER_GROUP)
);


CREATE TABLE QRTZ_EXCL_CALENDARS
  (
    CALENDAR_NAME  VARCHAR(80) NOT NULL,
    CALENDAR BLOB NOT NULL,
    PRIMARY KEY (CALENDAR_NAME)
);



CREATE TABLE QRTZ_EXCL_PAUSED_TRIGGER_GRPS
  (
    TRIGGER_GROUP  VARCHAR(80) NOT NULL, 
    PRIMARY KEY (TRIGGER_GROUP)
);

CREATE TABLE QRTZ_EXCL_FIRED_TRIGGERS
  (
    ENTRY_ID VARCHAR(95) NOT NULL,
    TRIGGER_NAME VARCHAR(80) NOT NULL,
    TRIGGER_GROUP VARCHAR(80) NOT NULL,
    IS_VOLATILE tinyint(1) NOT NULL,
    INSTANCE_NAME VARCHAR(80) NOT NULL,
    FIRED_TIME BIGINT(13) NOT NULL,
    PRIORITY INTEGER NOT NULL,
    STATE VARCHAR(16) NOT NULL,
    JOB_NAME VARCHAR(80) NULL,
    JOB_GROUP VARCHAR(80) NULL,
    IS_STATEFUL tinyint(1) NULL,
    REQUESTS_RECOVERY tinyint(1) NULL,
    PRIMARY KEY (ENTRY_ID)
);

CREATE TABLE QRTZ_EXCL_SCHEDULER_STATE
  (
    INSTANCE_NAME VARCHAR(80) NOT NULL,
    LAST_CHECKIN_TIME BIGINT(13) NOT NULL,
    CHECKIN_INTERVAL BIGINT(13) NOT NULL,
    PRIMARY KEY (INSTANCE_NAME)
);

CREATE TABLE QRTZ_EXCL_LOCKS
  (
    LOCK_NAME  VARCHAR(40) NOT NULL, 
    PRIMARY KEY (LOCK_NAME)
);


INSERT INTO QRTZ_EXCL_LOCKS values('TRIGGER_ACCESS');
INSERT INTO QRTZ_EXCL_LOCKS values('JOB_ACCESS');
INSERT INTO QRTZ_EXCL_LOCKS values('CALENDAR_ACCESS');
INSERT INTO QRTZ_EXCL_LOCKS values('STATE_ACCESS');
INSERT INTO QRTZ_EXCL_LOCKS values('MISFIRE_ACCESS');
create table calendar_reminder (
   user_id varchar(255) not null,
   event_id varchar(100) not null,
   send_date datetime not null,
   primary key (user_id, event_id, send_date)
);
create table ecom_product_price (
   inode varchar(100) not null,
   product_format_inode varchar(100) not null,
   min_qty integer,
   max_qty integer,
   retail_price float not null,
   partner_price float not null,
   primary key (inode)
);
create table tag (
   tagname varchar(255) not null,
   user_id varchar(255),
   primary key (tagname)
);
create table entity (
   inode varchar(100) not null,
   entity_name varchar(255),
   primary key (inode)
);
create table user_comments (
   inode varchar(100) not null,
   user_id varchar(255),
   cdate datetime,
   comment_user_id varchar(100),
   type varchar(255),
   method varchar(255),
   subject varchar(255),
   ucomment longtext,
   communication_id varchar(100),
   primary key (inode)
);
create table permission_reference (
   id bigint not null auto_increment,
   asset_id varchar(100),
   reference_id varchar(100),
   permission_type varchar(100),
   primary key (id),
   unique (asset_id)
);
create table fixes_audit (
   id varchar(255) not null,
   table_name varchar(255),
   action varchar(255),
   records_altered integer,
   datetime date,
   primary key (id)
);
create table trackback (
   id bigint not null auto_increment,
   asset_identifier varchar(100),
   title varchar(255),
   excerpt varchar(255),
   url varchar(255),
   blog_name varchar(255),
   track_date datetime not null,
   primary key (id)
);
create table plugin (
   id varchar(255) not null,
   plugin_name varchar(255) not null,
   plugin_version varchar(255) not null,
   author varchar(255) not null,
   first_deployed_date date not null,
   last_deployed_date date not null,
   primary key (id)
);
create table recipient (
   inode varchar(100) not null,
   name varchar(255),
   lastname varchar(255),
   email varchar(255),
   sent datetime,
   opened datetime,
   last_result integer,
   last_message varchar(255),
   user_id varchar(100),
   primary key (inode)
);
create table mailing_list (
   inode varchar(100) not null,
   title varchar(255),
   public_list tinyint(1),
   user_id varchar(255),
   primary key (inode)
);
create table web_form (
   web_form_id varchar(100) not null,
   form_type varchar(255),
   submit_date datetime,
   prefix varchar(255),
   first_name varchar(255),
   middle_initial varchar(255),
   middle_name varchar(255),
   full_name varchar(255),
   organization varchar(255),
   title varchar(255),
   last_name varchar(255),
   address varchar(255),
   address1 varchar(255),
   address2 varchar(255),
   city varchar(255),
   state varchar(255),
   zip varchar(255),
   country varchar(255),
   phone varchar(255),
   email varchar(255),
   custom_fields longtext,
   user_inode varchar(100),
   categories varchar(255),
   primary key (web_form_id)
);
create table virtual_link (
   inode varchar(100) not null,
   title varchar(255),
   url varchar(255),
   uri varchar(255),
   active tinyint(1),
   primary key (inode)
);
create table tree (
   child varchar(100) not null,
   parent varchar(100) not null,
   relation_type varchar(64) not null,
   tree_order integer,
   primary key (child, parent, relation_type)
);
create table event (
   inode varchar(100) not null,
   title varchar(255),
   subtitle varchar(255),
   start_date datetime,
   end_date datetime,
   location varchar(255),
   address1 varchar(255),
   address2 varchar(255),
   address3 varchar(255),
   city varchar(255),
   state varchar(255),
   zip varchar(32),
   country varchar(64),
   email varchar(64),
   phone varchar(64),
   fax varchar(64),
   url varchar(255),
   registration tinyint(1),
   include_file varchar(255),
   show_public tinyint(1),
   contact_name varchar(255),
   contact_company varchar(255),
   contact_phone varchar(255),
   contact_email varchar(255),
   contact_fax varchar(255),
   directions longtext,
   description longtext,
   email_response longtext,
   web_address varchar(255),
   user_id varchar(255),
   featured tinyint(1),
   setup_date datetime,
   break_date datetime,
   approval_status integer,
   comments_equipment longtext,
   received_adm_approval tinyint(1),
   time_tbd tinyint(1),
   primary key (inode)
);
create table users_cms_roles (
   id varchar(255) not null,
   user_id varchar(100) not null,
   role_id varchar(100) not null,
   primary key (id)
);
create table web_event (
   inode varchar(100) not null,
   title varchar(255),
   subtitle varchar(255),
   summary text,
   description varchar(255),
   terms_conditions varchar(255),
   comments varchar(255),
   partners_only tinyint(1),
   show_on_web tinyint(1),
   sort_order integer,
   event_image_1 varchar(100),
   event_image_2 varchar(100),
   event_image_3 varchar(100),
   event_image_4 varchar(100),
   is_institute tinyint(1),
   primary key (inode)
);
create table ecom_product (
   inode varchar(100) not null,
   title varchar(255) not null,
   short_description longtext,
   long_description longtext,
   req_shipping tinyint(1),
   featured tinyint(1),
   sort_order integer,
   comments longtext,
   showonweb tinyint(1),
   primary key (inode)
);
create table template (
   inode varchar(100) not null,
   live tinyint(1),
   working tinyint(1),
   deleted tinyint(1),
   locked tinyint(1),
   show_on_menu tinyint(1),
   title varchar(255),
   mod_date datetime,
   mod_user varchar(100),
   sort_order integer,
   friendly_name varchar(255),
   body longtext,
   header longtext,
   footer longtext,
   image varchar(100),
   primary key (inode)
);
create table ecom_order_item (
   inode varchar(100) not null,
   order_inode varchar(100),
   product_inode varchar(100),
   item_qty integer,
   item_price float,
   primary key (inode)
);
create table structure (
   inode varchar(100) not null,
   name varchar(255),
   description varchar(255),
   default_structure tinyint(1),
   review_interval varchar(255),
   reviewer_role varchar(255),
   page_detail varchar(100),
   structuretype integer,
   system tinyint(1),
   fixed bit not null,
   velocity_var_name varchar(255),
   url_map_pattern text,
   primary key (inode)
);
create table ecom_discount_code (
   inode varchar(100) not null,
   discount_type integer,
   start_date datetime,
   end_date datetime,
   code_id varchar(50),
   code_description varchar(100),
   free_shipping tinyint(1),
   no_bulk_disc tinyint(1),
   discount_amount float,
   min_order integer,
   primary key (inode)
);
create table cms_role (
   id varchar(100) not null,
   role_name varchar(255) not null,
   description longtext,
   role_key varchar(255),
   db_fqn text not null,
   parent varchar(100) not null,
   edit_permissions tinyint(1),
   edit_users tinyint(1),
   edit_layouts tinyint(1),
   locked tinyint(1),
   system tinyint(1),
   primary key (id)
);
create table web_event_registration (
   inode varchar(100) not null,
   event_inode varchar(100),
   event_location_inode varchar(100),
   user_inode varchar(100),
   registration_status integer,
   date_posted datetime,
   last_mod_date datetime,
   total_paid float,
   total_due float,
   total_registration float,
   payment_type integer,
   billing_address_1 varchar(255),
   billing_address_2 varchar(255),
   billing_city varchar(255),
   billing_state varchar(50),
   billing_zip varchar(50),
   billing_country varchar(50),
   billing_contact_name varchar(255),
   billing_contact_phone varchar(50),
   billing_contact_email varchar(255),
   card_name varchar(255),
   card_type varchar(50),
   card_number varchar(50),
   card_exp_month varchar(50),
   card_exp_year varchar(50),
   card_verification_value varchar(10),
   check_number varchar(50),
   check_bank_name varchar(255),
   po_number varchar(50),
   invoice_number varchar(50),
   badge_printed tinyint(1),
   how_did_you_hear varchar(255),
   ceo_name varchar(255),
   modified_qb tinyint(1),
   reminder_email_sent tinyint(1),
   post_email_sent tinyint(1),
   primary key (inode)
);
create table permission (
   id bigint not null auto_increment,
   permission_type varchar(100),
   inode_id varchar(100),
   roleid varchar(100),
   permission integer,
   primary key (id),
   unique (permission_type, inode_id, roleid)
);
create table recurance (
   inode varchar(100) not null,
   recurrance_occurs varchar(255),
   recurrance_interval integer,
   recurrance_starting datetime,
   recurrance_ending datetime,
   recurrance_days_of_week varchar(255),
   recurrance_day_of_month integer,
   primary key (inode)
);
create table contentlet (
   inode varchar(100) not null,
   live tinyint(1),
   working tinyint(1),
   deleted tinyint(1),
   locked tinyint(1),
   show_on_menu tinyint(1),
   title varchar(255),
   mod_date datetime,
   mod_user varchar(100),
   sort_order integer,
   friendly_name varchar(255),
   language_id bigint,
   structure_inode varchar(100),
   last_review datetime,
   next_review datetime,
   review_interval varchar(255),
   disabled_wysiwyg varchar(255),
   folder varchar(100),
   date1 datetime,
   date2 datetime,
   date3 datetime,
   date4 datetime,
   date5 datetime,
   date6 datetime,
   date7 datetime,
   date8 datetime,
   date9 datetime,
   date10 datetime,
   date11 datetime,
   date12 datetime,
   date13 datetime,
   date14 datetime,
   date15 datetime,
   date16 datetime,
   date17 datetime,
   date18 datetime,
   date19 datetime,
   date20 datetime,
   date21 datetime,
   date22 datetime,
   date23 datetime,
   date24 datetime,
   date25 datetime,
   text1 varchar(255),
   text2 varchar(255),
   text3 varchar(255),
   text4 varchar(255),
   text5 varchar(255),
   text6 varchar(255),
   text7 varchar(255),
   text8 varchar(255),
   text9 varchar(255),
   text10 varchar(255),
   text11 varchar(255),
   text12 varchar(255),
   text13 varchar(255),
   text14 varchar(255),
   text15 varchar(255),
   text16 varchar(255),
   text17 varchar(255),
   text18 varchar(255),
   text19 varchar(255),
   text20 varchar(255),
   text21 varchar(255),
   text22 varchar(255),
   text23 varchar(255),
   text24 varchar(255),
   text25 varchar(255),
   text_area1 longtext,
   text_area2 longtext,
   text_area3 longtext,
   text_area4 longtext,
   text_area5 longtext,
   text_area6 longtext,
   text_area7 longtext,
   text_area8 longtext,
   text_area9 longtext,
   text_area10 longtext,
   text_area11 longtext,
   text_area12 longtext,
   text_area13 longtext,
   text_area14 longtext,
   text_area15 longtext,
   text_area16 longtext,
   text_area17 longtext,
   text_area18 longtext,
   text_area19 longtext,
   text_area20 longtext,
   text_area21 longtext,
   text_area22 longtext,
   text_area23 longtext,
   text_area24 longtext,
   text_area25 longtext,
   integer1 bigint,
   integer2 bigint,
   integer3 bigint,
   integer4 bigint,
   integer5 bigint,
   integer6 bigint,
   integer7 bigint,
   integer8 bigint,
   integer9 bigint,
   integer10 bigint,
   integer11 bigint,
   integer12 bigint,
   integer13 bigint,
   integer14 bigint,
   integer15 bigint,
   integer16 bigint,
   integer17 bigint,
   integer18 bigint,
   integer19 bigint,
   integer20 bigint,
   integer21 bigint,
   integer22 bigint,
   integer23 bigint,
   integer24 bigint,
   integer25 bigint,
   `float1` float,
   `float2` float,
   `float3` float,
   `float4` float,
   `float5` float,
   `float6` float,
   `float7` float,
   `float8` float,
   `float9` float,
   `float10` float,
   `float11` float,
   `float12` float,
   `float13` float,
   `float14` float,
   `float15` float,
   `float16` float,
   `float17` float,
   `float18` float,
   `float19` float,
   `float20` float,
   `float21` float,
   `float22` float,
   `float23` float,
   `float24` float,
   `float25` float,
   bool1 tinyint(1),
   bool2 tinyint(1),
   bool3 tinyint(1),
   bool4 tinyint(1),
   bool5 tinyint(1),
   bool6 tinyint(1),
   bool7 tinyint(1),
   bool8 tinyint(1),
   bool9 tinyint(1),
   bool10 tinyint(1),
   bool11 tinyint(1),
   bool12 tinyint(1),
   bool13 tinyint(1),
   bool14 tinyint(1),
   bool15 tinyint(1),
   bool16 tinyint(1),
   bool17 tinyint(1),
   bool18 tinyint(1),
   bool19 tinyint(1),
   bool20 tinyint(1),
   bool21 tinyint(1),
   bool22 tinyint(1),
   bool23 tinyint(1),
   bool24 tinyint(1),
   bool25 tinyint(1),
   primary key (inode)
);
create table cms_layouts_portlets (
   id varchar(255) not null,
   layout_id varchar(100) not null,
   portlet_id varchar(100) not null,
   portlet_order integer,
   primary key (id)
);
create table workflow_comment (
   inode varchar(100) not null,
   creation_date datetime,
   posted_by varchar(255),
   wf_comment longtext,
   primary key (inode)
);
create table report_asset (
   inode varchar(100) not null,
   report_name varchar(255) not null,
   report_description text not null,
   requires_input tinyint(1),
   ds varchar(100) not null,
   web_form_report tinyint(1),
   primary key (inode)
);
create table category (
   inode varchar(100) not null,
   category_name varchar(255),
   category_key varchar(255),
   sort_order integer,
   active tinyint(1),
   keywords longtext,
   category_velocity_var_name varchar(255),
   primary key (inode)
);
create table htmlpage (
   inode varchar(100) not null,
   live tinyint(1),
   working tinyint(1),
   deleted tinyint(1),
   locked tinyint(1),
   show_on_menu tinyint(1),
   title varchar(255),
   mod_date datetime,
   mod_user varchar(100),
   sort_order integer,
   friendly_name varchar(255),
   metadata longtext,
   start_date datetime,
   end_date datetime,
   page_url varchar(255),
   https_required tinyint(1),
   redirect varchar(255),
   primary key (inode)
);
create table chain_link_code (
   id bigint not null auto_increment,
   class_name varchar(255) unique,
   code longtext not null,
   last_mod_date date not null,
   language varchar(255) not null,
   primary key (id)
);
create table language (
   id bigint not null auto_increment,
   language_code varchar(5),
   country_code varchar(255),
   language varchar(255),
   country varchar(255),
   primary key (id)
);
create table user_preferences (
   id bigint not null auto_increment,
   user_id varchar(100) not null,
   preference varchar(255),
   pref_value longtext,
   primary key (id)
);
create table users_to_delete (
   id bigint not null auto_increment,
   user_id varchar(255),
   primary key (id)
);
create table identifier (
   inode varchar(100) not null,
   uri varchar(255),
   host_inode varchar(255),
   primary key (inode),
   unique (uri, host_inode)
);
create table clickstream (
   clickstream_id bigint not null auto_increment,
   cookie_id varchar(255),
   user_id varchar(255),
   start_date datetime,
   end_date datetime,
   referer varchar(255),
   remote_address varchar(255),
   remote_hostname varchar(255),
   user_agent varchar(255),
   bot tinyint(1),
   number_of_requests integer,
   host_id varchar(50),
   last_page_id varchar(50),
   first_page_id varchar(50),
   operating_system varchar(50),
   browser_name varchar(50),
   browser_version varchar(50),
   mobile_device tinyint(1),
   primary key (clickstream_id)
);
create table web_event_location (
   inode varchar(100) not null,
   web_event_inode varchar(100),
   city varchar(255),
   state varchar(50),
   start_date datetime,
   end_date datetime,
   show_on_web tinyint(1),
   web_reg_active tinyint(1),
   hotel_name varchar(255),
   hotel_link bigint,
   past_event_link bigint,
   partner_price float,
   non_partner_price float,
   short_description varchar(255),
   text_email text,
   almost_at_capacity tinyint(1),
   full_capacity tinyint(1),
   default_contract_partner_price tinyint(1),
   primary key (inode)
);
create table multi_tree (
   child varchar(100) not null,
   parent1 varchar(100) not null,
   parent2 varchar(100) not null,
   relation_type varchar(64),
   tree_order integer,
   primary key (child, parent1, parent2)
);
create table tag_inode (
   inode varchar(100) not null,
   tagname varchar(255) not null,
   primary key (inode, tagname)
);
create table workflow_task (
   inode varchar(100) not null,
   creation_date datetime,
   mod_date datetime,
   due_date datetime,
   created_by varchar(255),
   assigned_to varchar(255),
   belongs_to varchar(255),
   title varchar(255),
   description longtext,
   status varchar(255),
   webasset varchar(255),
   primary key (inode)
);
create table click (
   inode varchar(100) not null,
   link varchar(255),
   click_count integer,
   primary key (inode)
);
create table event_registration (
   inode varchar(100) not null,
   registration_date datetime,
   full_name varchar(255),
   number_attending integer,
   comments longtext,
   email varchar(255),
   primary key (inode)
);
create table challenge_question (
   cquestionid bigint not null,
   cqtext varchar(255),
   primary key (cquestionid)
);
create table file_asset (
   inode varchar(100) not null,
   file_name varchar(255),
   file_size integer,
   width integer,
   height integer,
   mime_type varchar(255),
   author varchar(255),
   publish_date datetime,
   live tinyint(1),
   working tinyint(1),
   deleted tinyint(1),
   locked tinyint(1),
   show_on_menu tinyint(1),
   title varchar(255),
   friendly_name varchar(255),
   mod_date datetime,
   mod_user varchar(255),
   sort_order integer,
   primary key (inode)
);
create table layouts_cms_roles (
   id varchar(255) not null,
   layout_id varchar(100) not null,
   role_id varchar(100) not null,
   primary key (id)
);
create table organization (
   inode varchar(100) not null,
   title varchar(255),
   ceo_name varchar(255),
   partner_url varchar(255),
   partner_key varchar(255),
   partner_logo varchar(100),
   street1 varchar(255),
   street2 varchar(255),
   city varchar(255),
   state varchar(255),
   zip varchar(100),
   phone varchar(100),
   fax varchar(100),
   country varchar(255),
   is_system tinyint(1),
   parent_organization varchar(100),
   primary key (inode)
);
create table facility (
   inode varchar(100) not null,
   facility_name varchar(255) not null,
   facility_description varchar(255),
   sort_order integer,
   active tinyint(1),
   primary key (inode)
);
create table clickstream_request (
   clickstream_request_id bigint not null auto_increment,
   clickstream_id bigint,
   server_name varchar(255),
   protocol varchar(255),
   server_port integer,
   request_uri varchar(255),
   request_order integer,
   query_string longtext,
   language_id bigint,
   timestampper datetime,
   host_id varchar(255),
   associated_identifier varchar(50),
   primary key (clickstream_request_id)
);
create table chain_state (
   id bigint not null auto_increment,
   chain_id bigint not null,
   link_code_id bigint not null,
   state_order bigint not null,
   primary key (id)
);
create table content_rating (
   id bigint not null auto_increment,
   rating float,
   user_id varchar(255),
   session_id varchar(255),
   identifier varchar(100),
   rating_date datetime,
   user_ip varchar(255),
   long_live_cookie_id varchar(255),
   primary key (id)
);
create table campaign (
   inode varchar(100) not null,
   title varchar(255),
   from_email varchar(255),
   from_name varchar(255),
   subject varchar(255),
   message longtext,
   user_id varchar(255),
   start_date datetime,
   completed_date datetime,
   active tinyint(1),
   locked tinyint(1),
   sends_per_hour varchar(15),
   sendemail tinyint(1),
   communicationinode varchar(100),
   userfilterinode varchar(100),
   sendto varchar(15),
   isrecurrent tinyint(1),
   wassent tinyint(1),
   expiration_date datetime,
   parent_campaign varchar(100),
   primary key (inode)
);
create table banner (
   inode varchar(100) not null,
   title varchar(255),
   caption longtext,
   new_window tinyint(1),
   link varchar(255),
   start_date datetime,
   end_date datetime,
   body varchar(255),
   active tinyint(1),
   nmbr_views integer,
   nmbr_clicks integer,
   image varchar(100),
   path text,
   placement varchar(255),
   primary key (inode)
);
create table containers (
   inode varchar(100) not null,
   code longtext,
   pre_loop longtext,
   post_loop longtext,
   live tinyint(1),
   working tinyint(1),
   deleted tinyint(1),
   locked tinyint(1),
   show_on_menu tinyint(1),
   title varchar(255),
   mod_date datetime,
   mod_user varchar(100),
   sort_order integer,
   friendly_name varchar(255),
   max_contentlets integer,
   use_div tinyint(1),
   staticify tinyint(1),
   sort_contentlets_by varchar(255),
   lucene_query longtext,
   notes varchar(255),
   primary key (inode)
);
create table ecom_order (
   inode varchar(100) not null,
   user_inode varchar(100),
   order_status integer,
   payment_status integer,
   date_posted datetime,
   last_mod_date datetime,
   billing_address1 varchar(255),
   billing_address2 varchar(255),
   billing_city varchar(100),
   billing_state varchar(50),
   billing_zip varchar(50),
   billing_country varchar(50),
   billing_phone varchar(50),
   billing_fax varchar(50),
   billing_first_name varchar(100),
   billing_last_name varchar(100),
   billing_contact_name varchar(100),
   billing_contact_phone varchar(50),
   billing_contact_email varchar(100),
   shipping_address1 varchar(255),
   shipping_address2 varchar(255),
   shipping_city varchar(50),
   shipping_state varchar(50),
   shipping_zip varchar(50),
   shipping_country varchar(50),
   shipping_phone varchar(50),
   shipping_fax varchar(50),
   payment_type varchar(10),
   name_on_card varchar(100),
   card_type varchar(50),
   card_number varchar(50),
   card_exp_month integer,
   card_exp_year integer,
   card_verification_value varchar(50),
   order_sub_total float,
   order_shipping float,
   order_ship_type integer,
   order_tax float,
   order_discount float,
   tax_exempt_number varchar(50),
   discount_codes varchar(50),
   order_total float,
   order_total_paid float,
   order_total_due float,
   invoice_number varchar(50),
   invoice_date datetime,
   check_number varchar(50),
   check_bank_name varchar(100),
   po_number varchar(50),
   tracking_number varchar(255),
   modified_qb tinyint(1),
   modified_fh tinyint(1),
   backend_user varchar(100),
   shipping_label varchar(50),
   primary key (inode)
);
create table web_event_attendee (
   inode varchar(100) not null,
   event_registration_inode varchar(100),
   first_name varchar(255),
   last_name varchar(255),
   badge_name varchar(255),
   email varchar(255),
   title varchar(255),
   registration_price float,
   primary key (inode)
);
create table communication (
   inode varchar(100) not null,
   title varchar(255),
   trackback_link_inode varchar(100),
   communication_type varchar(255),
   from_name varchar(255),
   from_email varchar(255),
   email_subject varchar(255),
   html_page_inode varchar(100),
   text_message longtext,
   mod_date datetime,
   modified_by varchar(255),
   ext_comm_id varchar(255),
   primary key (inode)
);
create table workflow_history (
   inode varchar(100) not null,
   creation_date datetime,
   made_by varchar(255),
   change_desc longtext,
   primary key (inode)
);
create table host_variable (
   id varchar(255) not null,
   host_id varchar(255),
   variable_name varchar(255),
   variable_key varchar(255),
   variable_value varchar(255),
   user_id varchar(255),
   last_mod_date date,
   primary key (id)
);
create table links (
   inode varchar(100) not null,
   live tinyint(1),
   working tinyint(1),
   deleted tinyint(1),
   locked tinyint(1),
   show_on_menu tinyint(1),
   title varchar(255),
   mod_date datetime,
   mod_user varchar(100),
   sort_order integer,
   friendly_name varchar(255),
   protocal varchar(100),
   url varchar(255),
   target varchar(100),
   internal_link_identifier varchar(100),
   link_type varchar(255),
   link_code longtext,
   primary key (inode)
);
create table event_recurrence (
   inode varchar(100) not null,
   occurs varchar(255),
   rec_interval integer,
   rec_starting datetime,
   ending datetime,
   days_of_week varchar(255),
   day_of_month integer,
   primary key (inode)
);
create table user_proxy (
   inode varchar(100) not null,
   user_id varchar(255),
   prefix varchar(255),
   suffix varchar(255),
   title varchar(255),
   school varchar(255),
   how_heard varchar(255),
   company varchar(255),
   long_lived_cookie varchar(255),
   website varchar(255),
   graduation_year integer,
   organization varchar(255),
   mail_subscription tinyint(1),
   var1 varchar(255),
   var2 varchar(255),
   var3 varchar(255),
   var4 varchar(255),
   var5 varchar(255),
   var6 varchar(255),
   var7 varchar(255),
   var8 varchar(255),
   var9 varchar(255),
   var10 varchar(255),
   var11 varchar(255),
   var12 varchar(255),
   var13 varchar(255),
   var14 varchar(255),
   var15 varchar(255),
   var16 varchar(255),
   var17 varchar(255),
   var18 varchar(255),
   var19 varchar(255),
   var20 varchar(255),
   var21 varchar(255),
   var22 varchar(255),
   var23 varchar(255),
   var24 varchar(255),
   var25 varchar(255),
   last_result integer,
   last_message varchar(255),
   no_click_tracking tinyint(1),
   cquestionid varchar(255),
   cqanswer varchar(255),
   chapter_officer varchar(255),
   primary key (inode),
   unique (user_id)
);
create table chain_state_parameter (
   id bigint not null auto_increment,
   chain_state_id bigint not null,
   name varchar(255) not null,
   value varchar(255) not null,
   primary key (id)
);
create table folder (
   inode varchar(100) not null,
   name varchar(255),
   path varchar(255) not null,
   title varchar(255) not null,
   show_on_menu tinyint(1),
   sort_order integer,
   host_inode varchar(100),
   files_masks varchar(255),
   primary key (inode)
);
create table relationship (
   inode varchar(100) not null,
   parent_structure_inode varchar(255),
   child_structure_inode varchar(255),
   parent_relation_name varchar(255),
   child_relation_name varchar(255),
   relation_type_value varchar(255),
   cardinality integer,
   parent_required tinyint(1),
   child_required tinyint(1),
   fixed tinyint(1),
   primary key (inode)
);
create table field (
   inode varchar(100) not null,
   structure_inode varchar(255),
   field_name varchar(255),
   field_type varchar(255),
   field_relation_type varchar(255),
   field_contentlet varchar(255),
   required tinyint(1),
   indexed tinyint(1),
   listed tinyint(1),
   velocity_var_name varchar(255),
   sort_order integer,
   field_values longtext,
   regex_check varchar(255),
   hint varchar(255),
   default_value varchar(255),
   fixed tinyint(1),
   read_only tinyint(1),
   searchable tinyint(1),
   unique_ tinyint(1),
   primary key (inode)
);
create table cms_layout (
   id varchar(100) not null,
   layout_name varchar(255) not null,
   description varchar(255),
   tab_order integer,
   primary key (id)
);
create table ecom_product_format (
   inode varchar(100) not null,
   product_inode varchar(100) not null,
   format_name varchar(255) not null,
   item_num varchar(50),
   format varchar(100) not null,
   inventory_quantity integer,
   reorder_trigger integer,
   weight float,
   width integer,
   height integer,
   depth integer,
   primary key (inode)
);
create table report_parameter (
   inode varchar(100) not null,
   report_inode varchar(100),
   parameter_description text,
   parameter_name varchar(255),
   class_type varchar(250),
   default_value text,
   primary key (inode),
   unique (report_inode, parameter_name)
);
create table chain (
   id bigint not null auto_increment,
   key_name varchar(255) unique,
   name varchar(255) not null,
   success_value varchar(255) not null,
   failure_value varchar(255) not null,
   primary key (id)
);
create table inode (
   inode varchar(100) not null,
   owner varchar(255),
   idate datetime,
   type varchar(64),
   identifier varchar(100),
   primary key (inode)
);
create table user_filter (
   inode varchar(100) not null,
   title varchar(255),
   firstname varchar(100),
   middlename varchar(100),
   lastname varchar(100),
   emailaddress varchar(100),
   birthdaytypesearch varchar(100),
   birthday datetime,
   birthdayfrom datetime,
   birthdayto datetime,
   lastlogintypesearch varchar(100),
   lastloginsince varchar(100),
   loginfrom datetime,
   loginto datetime,
   createdtypesearch varchar(100),
   createdsince varchar(100),
   createdfrom datetime,
   createdto datetime,
   lastvisittypesearch varchar(100),
   lastvisitsince varchar(100),
   lastvisitfrom datetime,
   lastvisitto datetime,
   city varchar(100),
   state varchar(100),
   country varchar(100),
   zip varchar(100),
   cell varchar(100),
   phone varchar(100),
   fax varchar(100),
   active_ varchar(255),
   tagname varchar(255),
   var1 varchar(255),
   var2 varchar(255),
   var3 varchar(255),
   var4 varchar(255),
   var5 varchar(255),
   var6 varchar(255),
   var7 varchar(255),
   var8 varchar(255),
   var9 varchar(255),
   var10 varchar(255),
   var11 varchar(255),
   var12 varchar(255),
   var13 varchar(255),
   var14 varchar(255),
   var15 varchar(255),
   var16 varchar(255),
   var17 varchar(255),
   var18 varchar(255),
   var19 varchar(255),
   var20 varchar(255),
   var21 varchar(255),
   var22 varchar(255),
   var23 varchar(255),
   var24 varchar(255),
   var25 varchar(255),
   categories varchar(255),
   primary key (inode)
);
alter table ecom_product_price add index fkf3aa85f65fb51eb (inode), add constraint fkf3aa85f65fb51eb foreign key (inode) references inode (inode);
create index idx_entity_1 on entity (entity_name);
alter table entity add index fkb29de3e35fb51eb (inode), add constraint fkb29de3e35fb51eb foreign key (inode) references inode (inode);
create index idx_user_comments_1 on user_comments (user_id);
alter table user_comments add index fkdf1b37e85fb51eb (inode), add constraint fkdf1b37e85fb51eb foreign key (inode) references inode (inode);
create index idx_trackback_2 on trackback (url);
create index idx_trackback_1 on trackback (asset_identifier);
create index idx_communication_user_id on recipient (user_id);
create index idx_recipiets_1 on recipient (email);
create index idx_recipiets_2 on recipient (sent);
alter table recipient add index fk30e172195fb51eb (inode), add constraint fk30e172195fb51eb foreign key (inode) references inode (inode);
create index idx_mailinglist_1 on mailing_list (user_id);
alter table mailing_list add index fk7bc2cd925fb51eb (inode), add constraint fk7bc2cd925fb51eb foreign key (inode) references inode (inode);
create index idx_user_webform_1 on web_form (form_type);
create index idx_virtual_link_1 on virtual_link (url);
alter table virtual_link add index fkd844f8ae5fb51eb (inode), add constraint fkd844f8ae5fb51eb foreign key (inode) references inode (inode);
create index idx_event_2 on event (end_date);
create index idx_event_1 on event (start_date);
alter table event add index fk5c6729a5fb51eb (inode), add constraint fk5c6729a5fb51eb foreign key (inode) references inode (inode);
create index ix_web_event on web_event (title);
create index ix_web_event_1 on web_event (sort_order);
alter table web_event add index fkcfabd1ef5fb51eb (inode), add constraint fkcfabd1ef5fb51eb foreign key (inode) references inode (inode);
alter table ecom_product add index fk24a022ac5fb51eb (inode), add constraint fk24a022ac5fb51eb foreign key (inode) references inode (inode);
alter table template add index fkb13acc7a5fb51eb (inode), add constraint fkb13acc7a5fb51eb foreign key (inode) references inode (inode);
create index ix_ecom_order_item on ecom_order_item (order_inode);
alter table ecom_order_item add index fkebb882875fb51eb (inode), add constraint fkebb882875fb51eb foreign key (inode) references inode (inode);
alter table structure add index fk89d2d735fb51eb (inode), add constraint fk89d2d735fb51eb foreign key (inode) references inode (inode);
create index uk_discount_code_id on ecom_discount_code (code_id);
alter table ecom_discount_code add index fk994566285fb51eb (inode), add constraint fk994566285fb51eb foreign key (inode) references inode (inode);
create index ix_web_event_registration_3 on web_event_registration (date_posted);
create index ix_web_event_registration_2 on web_event_registration (user_inode);
create index ix_web_event_registration_1 on web_event_registration (event_location_inode);
create index ix_web_event_registration on web_event_registration (event_inode);
alter table web_event_registration add index fk60025d095fb51eb (inode), add constraint fk60025d095fb51eb foreign key (inode) references inode (inode);
create index idx_permission_2 on permission (permission_type, inode_id);
create index idx_permission_3 on permission (roleid);
alter table recurance add index fk457445fc5fb51eb (inode), add constraint fk457445fc5fb51eb foreign key (inode) references inode (inode);
alter table contentlet add index fkfc4ef025fb51eb (inode), add constraint fkfc4ef025fb51eb foreign key (inode) references inode (inode);
alter table workflow_comment add index fk94993ddf5fb51eb (inode), add constraint fk94993ddf5fb51eb foreign key (inode) references inode (inode);
alter table report_asset add index fk3765ec255fb51eb (inode), add constraint fk3765ec255fb51eb foreign key (inode) references inode (inode);
create index idx_category_1 on category (category_name);
create index idx_category_2 on category (category_key);
alter table category add index fk302bcfe5fb51eb (inode), add constraint fk302bcfe5fb51eb foreign key (inode) references inode (inode);
alter table htmlpage add index fkebf39cba5fb51eb (inode), add constraint fkebf39cba5fb51eb foreign key (inode) references inode (inode);
create index idx_chain_link_code_classname on chain_link_code (class_name);
create index idx_preference_1 on user_preferences (preference);
alter table identifier add index fk9f88aca95fb51eb (inode), add constraint fk9f88aca95fb51eb foreign key (inode) references inode (inode);
create index idx_user_clickstream11 on clickstream (host_id);
create index idx_user_clickstream12 on clickstream (last_page_id);
create index idx_user_clickstream15 on clickstream (browser_name);
create index idx_user_clickstream_2 on clickstream (user_id);
create index idx_user_clickstream16 on clickstream (browser_version);
create index idx_user_clickstream_1 on clickstream (cookie_id);
create index idx_user_clickstream13 on clickstream (first_page_id);
create index idx_user_clickstream14 on clickstream (operating_system);
create index ix_web_event_location_1 on web_event_location (state);
create index ix_web_event_location on web_event_location (city);
create index ix_web_event_location_3 on web_event_location (end_date);
create index ix_web_event_location_2 on web_event_location (start_date);
alter table web_event_location add index fk1d54bc055fb51eb (inode), add constraint fk1d54bc055fb51eb foreign key (inode) references inode (inode);
create index idx_multitree_1 on multi_tree (relation_type);
create index idx_workflow_4 on workflow_task (webasset);
create index idx_workflow_5 on workflow_task (created_by);
create index idx_workflow_2 on workflow_task (belongs_to);
create index idx_workflow_3 on workflow_task (status);
create index idx_workflow_1 on workflow_task (assigned_to);
alter table workflow_task add index fk441116055fb51eb (inode), add constraint fk441116055fb51eb foreign key (inode) references inode (inode);
create index idx_click_1 on click (link);
alter table click add index fk5a5c5885fb51eb (inode), add constraint fk5a5c5885fb51eb foreign key (inode) references inode (inode);
alter table event_registration add index fke1516a3e5fb51eb (inode), add constraint fke1516a3e5fb51eb foreign key (inode) references inode (inode);
create index idx_file_1 on file_asset (mod_user);
alter table file_asset add index fk7ed2366d5fb51eb (inode), add constraint fk7ed2366d5fb51eb foreign key (inode) references inode (inode);
alter table organization add index fk4644ed335fb51eb (inode), add constraint fk4644ed335fb51eb foreign key (inode) references inode (inode);
alter table facility add index fk1dde6ea35fb51eb (inode), add constraint fk1dde6ea35fb51eb foreign key (inode) references inode (inode);
create index idx_user_clickstream_request_2 on clickstream_request (request_uri);
create index idx_user_clickstream_request_1 on clickstream_request (clickstream_id);
create index idx_user_clickstream_request_3 on clickstream_request (associated_identifier);
create index idx_campaign_4 on campaign (expiration_date);
create index idx_campaign_3 on campaign (completed_date);
create index idx_campaign_2 on campaign (start_date);
create index idx_campaign_1 on campaign (user_id);
alter table campaign add index fkf7a901105fb51eb (inode), add constraint fkf7a901105fb51eb foreign key (inode) references inode (inode);
alter table banner add index fkacc57f2c5fb51eb (inode), add constraint fkacc57f2c5fb51eb foreign key (inode) references inode (inode);
alter table containers add index fk8a844125fb51eb (inode), add constraint fk8a844125fb51eb foreign key (inode) references inode (inode);
alter table ecom_order add index fkf088284b5fb51eb (inode), add constraint fkf088284b5fb51eb foreign key (inode) references inode (inode);
create index ix_web_event_attendee on web_event_attendee (event_registration_inode);
create index ix_web_event_attendee_1 on web_event_attendee (first_name);
create index ix_web_event_attendee_2 on web_event_attendee (last_name);
alter table web_event_attendee add index fkcc5ee90a5fb51eb (inode), add constraint fkcc5ee90a5fb51eb foreign key (inode) references inode (inode);
alter table communication add index fkc24acfd65fb51eb (inode), add constraint fkc24acfd65fb51eb foreign key (inode) references inode (inode);
alter table workflow_history add index fk933334145fb51eb (inode), add constraint fk933334145fb51eb foreign key (inode) references inode (inode);
alter table links add index fk6234fb95fb51eb (inode), add constraint fk6234fb95fb51eb foreign key (inode) references inode (inode);
alter table event_recurrence add index fk29da39f55fb51eb (inode), add constraint fk29da39f55fb51eb foreign key (inode) references inode (inode);
alter table user_proxy add index fk7327d4fa5fb51eb (inode), add constraint fk7327d4fa5fb51eb foreign key (inode) references inode (inode);
create index idx_folder_1 on folder (name);
alter table folder add index fkb45d1c6e5fb51eb (inode), add constraint fkb45d1c6e5fb51eb foreign key (inode) references inode (inode);
create index idx_relationship_1 on relationship (parent_structure_inode);
create index idx_relationship_2 on relationship (child_structure_inode);
alter table relationship add index fkf06476385fb51eb (inode), add constraint fkf06476385fb51eb foreign key (inode) references inode (inode);
create index idx_field_1 on field (structure_inode);
alter table field add index fk5cea0fa5fb51eb (inode), add constraint fk5cea0fa5fb51eb foreign key (inode) references inode (inode);
alter table ecom_product_format add index fk706fb8ea5fb51eb (inode), add constraint fk706fb8ea5fb51eb foreign key (inode) references inode (inode);
alter table report_parameter add index fk22da125e5fb51eb (inode), add constraint fk22da125e5fb51eb foreign key (inode) references inode (inode);
create index idx_chain_key_name on chain (key_name);
create index idx_index_2 on inode (identifier);
create index idx_index_1 on inode (type);
alter table user_filter add index fke042126c5fb51eb (inode), add constraint fke042126c5fb51eb foreign key (inode) references inode (inode);
-- mysql
CREATE INDEX idx_tree ON tree (child, parent, relation_type);
CREATE INDEX idx_tree_1 ON tree (parent);
CREATE INDEX idx_tree_2 ON tree (child);
CREATE INDEX idx_tree_3 ON tree (relation_type); 
CREATE INDEX idx_tree_4 ON tree (parent, child, relation_type);
CREATE INDEX idx_tree_5 ON tree (parent, relation_type);
CREATE INDEX idx_tree_6 ON tree (child, relation_type);
CREATE INDEX idx_contentlet_1 ON contentlet (inode, live);
CREATE INDEX idx_contentlet_2 ON contentlet (inode, working);

CREATE INDEX idx_contentlet_3 ON contentlet (inode);


CREATE INDEX idx_identifier ON identifier (inode);
CREATE INDEX idx_permisision_4 ON permission (permission_type);


CREATE INDEX idx_permission_reference_2 ON permission_reference (reference_id);
CREATE INDEX idx_permission_reference_3 ON permission_reference (reference_id,permission_type);
CREATE INDEX idx_permission_reference_4 ON permission_reference (asset_id,permission_type);
CREATE INDEX idx_permission_reference_5 ON permission_reference (asset_id,reference_id,permission_type);
CREATE INDEX idx_permission_reference_6 ON permission_reference (permission_type);

CREATE UNIQUE INDEX idx_field_velocity_structure ON field (velocity_var_name,structure_inode); 

alter table tree add index (parent), add constraint FK36739EC4AB08AA foreign key (parent) references inode (inode);
alter table tree add index (child), add constraint FK36739E5A3F51C foreign key (child) references inode (inode);

alter table chain_state add constraint fk_state_chain foreign key (chain_id) references chain(id);
alter table chain_state add constraint fk_state_code foreign key (link_code_id) references chain_link_code(id);
alter table chain_state_parameter add constraint fk_parameter_state foreign key (chain_state_id) references chain_state(id);

alter table permission add constraint permission_inode_fk foreign key (inode_id) references inode(inode);
alter table permission add constraint permission_role_fk foreign key (roleid) references cms_role(id);

alter table permission_reference add constraint permission_asset_id_fk foreign key (asset_id) references inode(inode);
alter table permission_reference add constraint permission_reference_id_fk foreign key (reference_id) references inode(inode);

alter table contentlet add constraint FK_structure_inode foreign key (structure_inode) references structure(inode);

ALTER TABLE structure MODIFY fixed tinyint(1) DEFAULT '0' NOT NULL;

ALTER TABLE field MODIFY fixed tinyint(1) DEFAULT '0' NOT NULL;
ALTER TABLE field MODIFY read_only tinyint(1) DEFAULT '1' NOT NULL;

ALTER TABLE campaign MODIFY active tinyint(1) DEFAULT '0' NOT NULL;

insert into User_ (userId, companyId, createDate, password_, passwordEncrypted, passwordReset, firstName, middleName, lastName, male, birthday, emailAddress, skinId, dottedSkins, roundedSkins, greeting, layoutIds, loginDate, failedLoginAttempts, agreedToTermsOfUse, active_) values ('dotcms.org.default', 'default', now(), 'password', '0', '0', '', '', '', '1', '1970-01-01', 'default@dotcms.org', '01', '0', '0', 'Welcome!', '', now(), 0, '0', '1');

create index addres_userid_index on address(userid);
create index tag_user_id_index on tag(user_id);
create index tag_inode_tagname on tag_inode(tagname);
create index tag_inode_inode on tag_inode(inode);
CREATE TABLE `dist_journal` (
  `id` BIGINT  NOT NULL AUTO_INCREMENT,
  `object_to_index` VARCHAR(1024)  NOT NULL,
  `serverid` VARCHAR(64)  NOT NULL,
  `journal_type` INTEGER  NOT NULL,
  `time_entered` DATETIME  NOT NULL,
  PRIMARY KEY (`id`)
);
ALTER TABLE dist_journal ADD UNIQUE (object_to_index(255), serverid,journal_type);

create table plugin_property (
   plugin_id varchar(255) not null,
   propkey varchar(255) not null,
   original_value varchar(255) not null,
   current_value varchar(255) not null
);
alter table plugin_property add constraint fk_plugin_plugin_property foreign key (plugin_id) references plugin(id);

CREATE TABLE `dist_process` (`id` BIGINT  NOT NULL AUTO_INCREMENT,`object_to_index` VARCHAR(1024)  NOT NULL,`serverid` VARCHAR(64)  NOT NULL,`journal_type` INTEGER  NOT NULL,`time_entered` DATETIME  NOT NULL, PRIMARY KEY (`id`));
CREATE INDEX dist_process_index USING BTREE on dist_process (object_to_index (255), serverid,journal_type);

CREATE TABLE `dist_reindex_journal` (`id` BIGINT  NOT NULL AUTO_INCREMENT,`inode_to_index` VARCHAR(100)  NOT NULL,`ident_to_index` VARCHAR(100)  NOT NULL,`serverid` VARCHAR(64)  NOT NULL,`priority` INTEGER  NOT NULL,`time_entered` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, index_val varchar(325), dist_action integer NOT NULL DEFAULT 1, PRIMARY KEY (`id`));

CREATE INDEX dist_reindex_index1 USING BTREE on dist_reindex_journal (inode_to_index (100));
CREATE INDEX dist_reindex_index2 USING BTREE on dist_reindex_journal (dist_action);
CREATE INDEX dist_reindex_index3 USING BTREE on dist_reindex_journal (serverid);
CREATE INDEX dist_reindex_index USING BTREE on dist_reindex_journal (serverid,dist_action);

CREATE TABLE `quartz_log` (`id` BIGINT  NOT NULL AUTO_INCREMENT,`JOB_NAME` VARCHAR(255)  NOT NULL,`serverid` VARCHAR(64) ,`time_started` DATETIME  NOT NULL, PRIMARY KEY (`id`));


ALTER TABLE cms_role ADD UNIQUE (role_key);

alter table cms_role add constraint fkcms_role_parent foreign key (parent) references cms_role (id) ON DELETE CASCADE;
			

ALTER TABLE cms_layout ADD UNIQUE (layout_name);
ALTER TABLE portlet ADD UNIQUE (portletid);
ALTER TABLE cms_layouts_portlets ADD UNIQUE (portlet_id, layout_id);
alter table cms_layouts_portlets add constraint fkcms_layouts_portlets foreign key (layout_id) references cms_layout(id);

ALTER TABLE users_cms_roles ADD UNIQUE (role_id, user_id);
alter table users_cms_roles add constraint fkusers_cms_roles1 foreign key (role_id) references cms_role (id);
alter table users_cms_roles add constraint fkusers_cms_roles2 foreign key (user_id) references user_ (userid);
				
ALTER TABLE layouts_cms_roles ADD UNIQUE (role_id, layout_id);
alter table layouts_cms_roles add constraint fklayouts_cms_roles1 foreign key (role_id) references cms_role (id);
alter table layouts_cms_roles add constraint fklayouts_cms_roles2 foreign key (layout_id) references cms_layout (id);

alter table contentlet add constraint fk_folder foreign key (folder) references folder(inode);


create table dist_reindex_lock (dummy int);
create table dist_lock (dummy int);

create table import_audit (
	id bigint not null,
	start_date timestamp,
	userid varchar(255), 
	filename varchar(512),
	status int,
	last_inode varchar(100),
	records_to_import bigint,
	serverid varchar(255), 
	primary key (id)
	);

alter table category modify column category_velocity_var_name varchar(255) not null;
