create table ABContact (
	contactId varchar2(100) not null primary key,
	userId varchar2(100) not null,
	firstName varchar2(100) null,
	middleName varchar2(100) null,
	lastName varchar2(100) null,
	nickName varchar2(100) null,
	emailAddress varchar2(100) null,
	homeStreet varchar2(100) null,
	homeCity varchar2(100) null,
	homeState varchar2(100) null,
	homeZip varchar2(100) null,
	homeCountry varchar2(100) null,
	homePhone varchar2(100) null,
	homeFax varchar2(100) null,
	homeCell varchar2(100) null,
	homePager varchar2(100) null,
	homeTollFree varchar2(100) null,
	homeEmailAddress varchar2(100) null,
	businessCompany varchar2(100) null,
	businessStreet varchar2(100) null,
	businessCity varchar2(100) null,
	businessState varchar2(100) null,
	businessZip varchar2(100) null,
	businessCountry varchar2(100) null,
	businessPhone varchar2(100) null,
	businessFax varchar2(100) null,
	businessCell varchar2(100) null,
	businessPager varchar2(100) null,
	businessTollFree varchar2(100) null,
	businessEmailAddress varchar2(100) null,
	employeeNumber varchar2(100) null,
	jobTitle varchar2(100) null,
	jobClass varchar2(100) null,
	hoursOfOperation varchar2(4000) null,
	birthday date null,
	timeZoneId varchar2(100) null,
	instantMessenger varchar2(100) null,
	website varchar2(100) null,
	comments varchar2(4000) null
);

create table ABContacts_ABLists (
	contactId varchar2(100) not null,
	listId varchar2(100) not null
);

create table ABList (
	listId varchar2(100) not null primary key,
	userId varchar2(100) not null,
	name varchar2(100) null
);

create table Address (
	addressId varchar2(100) not null primary key,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	userName varchar2(100) null,
	createDate date null,
	modifiedDate date null,
	className varchar2(100) null,
	classPK varchar2(100) null,
	description varchar2(100) null,
	street1 varchar2(100) null,
	street2 varchar2(100) null,
	city varchar2(100) null,
	state varchar2(100) null,
	zip varchar2(100) null,
	country varchar2(100) null,
	phone varchar2(100) null,
	fax varchar2(100) null,
	cell varchar2(100) null,
	priority number(30,0)
);

create table AdminConfig (
	configId varchar2(100) not null primary key,
	companyId varchar2(100) not null,
	type_ varchar2(100) null,
	name varchar2(100) null,
	config long varchar null
);

create table BJEntries_BJTopics (
	entryId varchar2(100) not null,
	topicId varchar2(100) not null
);

create table BJEntries_BJVerses (
	entryId varchar2(100) not null,
	verseId varchar2(100) not null
);

create table BJEntry (
	entryId varchar2(100) not null primary key,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	createDate date null,
	modifiedDate date null,
	name varchar2(100) null,
	content long varchar null,
	versesInput varchar2(4000) null
);

create table BJTopic (
	topicId varchar2(100) not null primary key,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	createDate date null,
	modifiedDate date null,
	name varchar2(100) null,
	description long varchar null
);

create table BJVerse (
	verseId varchar2(100) not null primary key,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	name varchar2(100) null
);

create table BlogsCategory (
	categoryId varchar2(100) not null primary key,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	createDate date null,
	modifiedDate date null,
	name varchar2(100) null
);

create table BlogsComments (
	commentsId varchar2(100) not null primary key,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	userName varchar2(100) null,
	createDate date null,
	modifiedDate date null,
	entryId varchar2(100) null,
	content long varchar null
);

create table BlogsEntry (
	entryId varchar2(100) not null primary key,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	createDate date null,
	modifiedDate date null,
	categoryId varchar2(100) null,
	title varchar2(100) null,
	content long varchar null,
	displayDate date null,
	sharing number(1, 0),
	commentable number(1, 0),
	propsCount number(30,0),
	commentsCount number(30,0)
);

create table BlogsLink (
	linkId varchar2(100) not null primary key,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	createDate date null,
	modifiedDate date null,
	name varchar2(100) null,
	url varchar2(100) null
);

create table BlogsProps (
	propsId varchar2(100) not null primary key,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	userName varchar2(100) null,
	createDate date null,
	modifiedDate date null,
	entryId varchar2(100) null,
	quantity number(30,0)
);

create table BlogsReferer (
	entryId varchar2(100) not null,
	url varchar2(100) not null,
	type_ varchar2(100) not null,
	quantity number(30,0),
	primary key (entryId, url, type_)
);

create table BlogsUser (
	userId varchar2(100) not null primary key,
	companyId varchar2(100) not null,
	entryId varchar2(100) not null,
	lastPostDate date null
);

create table BookmarksEntry (
	entryId varchar2(100) not null primary key,
	userId varchar2(100) not null,
	createDate date null,
	modifiedDate date null,
	folderId varchar2(100) null,
	name varchar2(100) null,
	url varchar2(100) null,
	comments varchar2(4000) null,
	visits number(30,0)
);

create table BookmarksFolder (
	folderId varchar2(100) not null primary key,
	userId varchar2(100) not null,
	createDate date null,
	modifiedDate date null,
	parentFolderId varchar2(100) null,
	name varchar2(100) null
);

create table CalEvent (
	eventId varchar2(100) not null primary key,
	groupId varchar2(100) not null,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	userName varchar2(100) null,
	createDate date null,
	modifiedDate date null,
	title varchar2(100) null,
	description varchar2(4000) null,
	startDate date null,
	endDate date null,
	durationHour number(30,0),
	durationMinute number(30,0),
	allDay number(1, 0),
	timeZoneSensitive number(1, 0),
	type_ varchar2(100) null,
	location varchar2(100) null,
	street varchar2(100) null,
	city varchar2(100) null,
	state varchar2(100) null,
	zip varchar2(100) null,
	phone varchar2(100) null,
	repeating number(1, 0),
	recurrence long varchar null,
	remindBy varchar2(100) null,
	firstReminder number(30,0),
	secondReminder number(30,0)
);

create table CalTask (
	taskId varchar2(100) not null primary key,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	createDate date null,
	modifiedDate date null,
	title varchar2(100) null,
	description varchar2(4000) null,
	noDueDate number(1, 0),
	dueDate date null,
	priority number(30,0),
	status number(30,0)
);

create table Company (
	companyId varchar2(100) not null primary key,
	key_ long varchar null,
	portalURL varchar2(100) not null,
	homeURL varchar2(100) not null,
	mx varchar2(100) not null,
	name varchar2(100) not null,
	shortName varchar2(100) not null,
	type_ varchar2(100) null,
	size_ varchar2(100) null,
	street varchar2(100) null,
	city varchar2(100) null,
	state varchar2(100) null,
	zip varchar2(100) null,
	phone varchar2(100) null,
	fax varchar2(100) null,
	emailAddress varchar2(100) null,
	authType varchar2(100) null,
	autoLogin number(1, 0),
	strangers number(1, 0)
);

create table Counter (
	name varchar2(100) not null primary key,
	currentId number(30,0)
);

create table CyrusUser (
	userId varchar2(100) not null primary key,
	password_ varchar2(100) not null
);

create table CyrusVirtual (
	emailAddress varchar2(100) not null primary key,
	userId varchar2(100) not null
);

create table DLFileProfile (
	companyId varchar2(100) not null,
	repositoryId varchar2(100) not null,
	fileName varchar2(100) not null,
	userId varchar2(100) not null,
	userName varchar2(100) null,
	versionUserId varchar2(100) not null,
	versionUserName varchar2(100) null,
	createDate date null,
	modifiedDate date null,
	readRoles varchar2(100) null,
	writeRoles varchar2(100) null,
	description long varchar null,
	version number(30,20),
	size_ number(30,0),
	primary key (companyId, repositoryId, fileName)
);

create table DLFileRank (
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	repositoryId varchar2(100) not null,
	fileName varchar2(100) not null,
	createDate date null,
	primary key (companyId, userId, repositoryId, fileName)
);

create table DLFileVersion (
	companyId varchar2(100) not null,
	repositoryId varchar2(100) not null,
	fileName varchar2(100) not null,
	version number(30,20) not null,
	userId varchar2(100) not null,
	userName varchar2(100) null,
	createDate date null,
	size_ number(30,0),
	primary key (companyId, repositoryId, fileName, version)
);

create table DLRepository (
	repositoryId varchar2(100) not null primary key,
	groupId varchar2(100) not null,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	userName varchar2(100) null,
	createDate date null,
	modifiedDate date null,
	readRoles varchar2(100) null,
	writeRoles varchar2(100) null,
	name varchar2(100) null,
	description varchar2(4000) null,
	lastPostDate date null
);

create table IGFolder (
	folderId varchar2(100) not null primary key,
	groupId varchar2(100) not null,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	createDate date null,
	modifiedDate date null,
	parentFolderId varchar2(100) null,
	name varchar2(100) null
);

create table IGImage (
	imageId varchar2(100) not null,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	createDate date null,
	modifiedDate date null,
	folderId varchar2(100) null,
	description long varchar null,
	height number(30,0),
	width number(30,0),
	size_ number(30,0),
	primary key (imageId, companyId)
);

create table Image (
	imageId varchar2(200) not null primary key,
	text_ long varchar not null
);

create table JournalArticle (
	articleId varchar2(100) not null,
	version number(30,20) not null,
	portletId varchar2(100) not null,
	groupId varchar2(100) not null,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	userName varchar2(100) null,
	createDate date null,
	modifiedDate date null,
	title varchar2(100) null,
	content long varchar null,
	type_ varchar2(100) null,
	structureId varchar2(100) null,
	templateId varchar2(100) null,
	displayDate date null,
	expirationDate date null,
	approved number(1, 0),
	approvedByUserId varchar2(100) null,
	approvedByUserName varchar2(100) null,
	primary key (articleId, version)
);

create table JournalStructure (
	structureId varchar2(100) not null primary key,
	portletId varchar2(100) not null,
	groupId varchar2(100) not null,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	userName varchar2(100) null,
	createDate date null,
	modifiedDate date null,
	name varchar2(100) null,
	description varchar2(4000) null,
	xsd long varchar null
);

create table JournalTemplate (
	templateId varchar2(100) not null primary key,
	portletId varchar2(100) not null,
	groupId varchar2(100) not null,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	userName varchar2(100) null,
	createDate date null,
	modifiedDate date null,
	structureId varchar2(100) null,
	name varchar2(100) null,
	description varchar2(4000) null,
	xsl long varchar null,
	smallImage number(1, 0),
	smallImageURL varchar2(100) null
);

create table Layer (
	layerId varchar2(100) not null,
	skinId varchar2(100) not null,
	href varchar2(100) null,
	hrefHover varchar2(100) null,
	background varchar2(100) null,
	foreground varchar2(100) null,
	negAlert varchar2(100) null,
	posAlert varchar2(100) null,
	primary key (layerId, skinId)
);

create table MailReceipt (
	receiptId varchar2(100) not null primary key,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	createDate date null,
	modifiedDate date null,
	recipientName varchar2(100) null,
	recipientAddress varchar2(100) null,
	subject varchar2(100) null,
	sentDate date null,
	readCount number(30,0),
	firstReadDate date null,
	lastReadDate date null
);

create table MBMessage (
	messageId varchar2(100) not null,
	topicId varchar2(100) not null,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	userName varchar2(100) null,
	createDate date null,
	modifiedDate date null,
	threadId varchar2(100) null,
	parentMessageId varchar2(100) null,
	subject varchar2(100) null,
	body long varchar null,
	attachments number(1, 0),
	anonymous number(1, 0),
	primary key (messageId, topicId)
);

create table MBMessageFlag (
	topicId varchar2(100) not null,
	messageId varchar2(100) not null,
	userId varchar2(100) not null,
	flag varchar2(100) null,
	primary key (topicId, messageId, userId)
);

create table MBThread (
	threadId varchar2(100) not null primary key,
	rootMessageId varchar2(100) null,
	topicId varchar2(100) null,
	messageCount number(30,0),
	lastPostDate date null
);

create table MBTopic (
	topicId varchar2(100) not null primary key,
	portletId varchar2(100) not null,
	groupId varchar2(100) not null,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	userName varchar2(100) null,
	createDate date null,
	modifiedDate date null,
	readRoles varchar2(100) null,
	writeRoles varchar2(100) null,
	name varchar2(100) null,
	description long varchar null,
	lastPostDate date null
);

create table NetworkAddress (
	addressId varchar2(100) not null primary key,
	userId varchar2(100) not null,
	createDate date null,
	modifiedDate date null,
	name varchar2(100) null,
	url varchar2(100) null,
	comments varchar2(4000) null,
	content long varchar null,
	status number(30,0),
	lastUpdated date null,
	notifyBy varchar2(100) null,
	interval_ number(30,0),
	active_ number(1, 0)
);

create table Note (
	noteId varchar2(100) not null primary key,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	userName varchar2(100) null,
	createDate date null,
	modifiedDate date null,
	className varchar2(100) null,
	classPK varchar2(100) null,
	content long varchar null
);

create table PasswordTracker (
	passwordTrackerId varchar2(100) not null primary key,
	userId varchar2(100) not null,
	createDate date not null,
	password_ varchar2(100) not null
);

create table PollsChoice (
	choiceId varchar2(100) not null,
	questionId varchar2(100) not null,
	description varchar2(4000) null,
	primary key (choiceId, questionId)
);

create table PollsDisplay (
	layoutId varchar2(100) not null,
	userId varchar2(100) not null,
	portletId varchar2(100) not null,
	questionId varchar2(100) not null,
	primary key (layoutId, userId, portletId)
);

create table PollsQuestion (
	questionId varchar2(100) not null primary key,
	portletId varchar2(100) not null,
	groupId varchar2(100) not null,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	userName varchar2(100) null,
	createDate date null,
	modifiedDate date null,
	title varchar2(100) null,
	description varchar2(4000) null,
	expirationDate date null,
	lastVoteDate date null
);

create table PollsVote (
	questionId varchar2(100) not null,
	userId varchar2(100) not null,
	choiceId varchar2(100) not null,
	voteDate date null,
	primary key (questionId, userId)
);

create table Portlet (
	portletId varchar2(100) not null,
	groupId varchar2(100) not null,
	companyId varchar2(100) not null,
	defaultPreferences nclob null,
	narrow number(1, 0),
	roles varchar2(4000) null,
	active_ number(1, 0),
	primary key (portletId, groupId, companyId)
);

create table PortletPreferences (
	portletId varchar2(100) not null,
	userId varchar2(100) not null,
	layoutId varchar2(100) not null,
	preferences long varchar null,
	primary key (portletId, userId, layoutId)
);

create table ProjFirm (
	firmId varchar2(100) not null primary key,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	userName varchar2(100) null,
	createDate date null,
	modifiedDate date null,
	name varchar2(100) null,
	description varchar2(4000) null,
	url varchar2(100) null
);

create table ProjProject (
	projectId varchar2(100) not null primary key,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	userName varchar2(100) null,
	createDate date null,
	modifiedDate date null,
	firmId varchar2(100) null,
	code varchar2(100) null,
	name varchar2(100) null,
	description varchar2(4000) null
);

create table ProjTask (
	taskId varchar2(100) not null primary key,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	userName varchar2(100) null,
	createDate date null,
	modifiedDate date null,
	projectId varchar2(100) null,
	name varchar2(100) null,
	description varchar2(4000) null,
	comments long varchar null,
	estimatedDuration number(30,0),
	estimatedEndDate date null,
	actualDuration number(30,0),
	actualEndDate date null,
	status number(30,0)
);

create table ProjTime (
	timeId varchar2(100) not null primary key,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	userName varchar2(100) null,
	createDate date null,
	modifiedDate date null,
	projectId varchar2(100) null,
	taskId varchar2(100) null,
	description varchar2(4000) null,
	startDate date null,
	endDate date null
);

create table Release_ (
	releaseId varchar2(100) not null primary key,
	createDate date null,
	modifiedDate date null,
	buildNumber number(30,0) null,
	buildDate date null
);

create table Skin (
	skinId varchar2(100) not null primary key,
	name varchar2(100) null,
	imageId varchar2(100) null,
	alphaLayerId varchar2(100) null,
	alphaSkinId varchar2(100) null,
	betaLayerId varchar2(100) null,
	betaSkinId varchar2(100) null,
	gammaLayerId varchar2(100) null,
	gammaSkinId varchar2(100) null,
	bgLayerId varchar2(100) null,
	bgSkinId varchar2(100) null
);

create table ShoppingCart (
	cartId varchar2(100) not null primary key,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	createDate date null,
	modifiedDate date null,
	itemIds varchar2(4000) null,
	couponIds varchar2(4000) null,
	altShipping number(30,0)
);

create table ShoppingCategory (
	categoryId varchar2(100) not null primary key,
	companyId varchar2(100) not null,
	createDate date null,
	modifiedDate date null,
	parentCategoryId varchar2(100) null,
	name varchar2(100) null
);

create table ShoppingCoupon (
	couponId varchar2(100) not null primary key,
	companyId varchar2(100) not null,
	createDate date null,
	modifiedDate date null,
	name varchar2(100) null,
	description varchar2(4000) null,
	startDate date null,
	endDate date null,
	active_ number(1, 0),
	limitCategories varchar2(4000) null,
	limitSkus varchar2(4000) null,
	minOrder number(30,20),
	discount number(30,20),
	discountType varchar2(100) null
);

create table ShoppingItem (
	itemId varchar2(100) not null primary key,
	companyId varchar2(100) not null,
	createDate date null,
	modifiedDate date null,
	categoryId varchar2(100) null,
	sku varchar2(100) null,
	name varchar2(100) null,
	description varchar2(4000) null,
	properties varchar2(4000) null,
	supplierUserId varchar2(100) null,
	fields_ number(1, 0),
	fieldsQuantities varchar2(4000) null,
	minQuantity number(30,0),
	maxQuantity number(30,0),
	price number(30,20),
	discount number(30,20),
	taxable number(1, 0),
	shipping number(30,20),
	useShippingFormula number(1, 0),
	requiresShipping number(1, 0),
	stockQuantity number(30,0),
	featured_ number(1, 0),
	sale_ number(1, 0),
	smallImage number(1, 0),
	smallImageURL varchar2(100) null,
	mediumImage number(1, 0),
	mediumImageURL varchar2(100) null,
	largeImage number(1, 0),
	largeImageURL varchar2(100) null
);

create table ShoppingItemField (
	itemFieldId varchar2(100) not null primary key,
	itemId varchar2(100) null,
	name varchar2(100) null,
	values_ varchar2(4000) null,
	description varchar2(4000) null
);

create table ShoppingItemPrice (
	itemPriceId varchar2(100) not null primary key,
	itemId varchar2(100) null,
	minQuantity number(30,0),
	maxQuantity number(30,0),
	price number(30,20),
	discount number(30,20),
	taxable number(1, 0),
	shipping number(30,20),
	useShippingFormula number(1, 0),
	status number(30,0)
);

create table ShoppingOrder (
	orderId varchar2(100) not null primary key,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	createDate date null,
	modifiedDate date null,
	tax number(30,20),
	shipping number(30,20),
	altShipping varchar2(100),
	requiresShipping number(1, 0),
	couponIds varchar2(4000) null,
	couponDiscount number(30,20),
	billingFirstName varchar2(100) null,
	billingLastName varchar2(100) null,
	billingEmailAddress varchar2(100) null,
	billingCompany varchar2(100) null,
	billingStreet varchar2(100) null,
	billingCity varchar2(100) null,
	billingState varchar2(100) null,
	billingZip varchar2(100) null,
	billingCountry varchar2(100) null,
	billingPhone varchar2(100) null,
	shipToBilling number(1, 0),
	shippingFirstName varchar2(100) null,
	shippingLastName varchar2(100) null,
	shippingEmailAddress varchar2(100) null,
	shippingCompany varchar2(100) null,
	shippingStreet varchar2(100) null,
	shippingCity varchar2(100) null,
	shippingState varchar2(100) null,
	shippingZip varchar2(100) null,
	shippingCountry varchar2(100) null,
	shippingPhone varchar2(100) null,
	ccName varchar2(100) null,
	ccType varchar2(100) null,
	ccNumber varchar2(100) null,
	ccExpMonth number(30,0),
	ccExpYear number(30,0),
	ccVerNumber varchar2(100) null,
	comments long varchar null,
	ppTxnId varchar2(100) null,
	ppPaymentStatus varchar2(100) null,
	ppPaymentGross number(30,20),
	ppReceiverEmail varchar2(100) null,
	ppPayerEmail varchar2(100) null,
	sendOrderEmail number(1, 0),
	sendShippingEmail number(1, 0)
);

create table ShoppingOrderItem (
	orderId varchar2(100) not null,
	itemId varchar2(100) not null,
	sku varchar2(100) null,
	name varchar2(100) null,
	description varchar2(4000) null,
	properties varchar2(4000) null,
	supplierUserId varchar2(100) null,
	price number(30,20),
	quantity number(30,0),
	shippedDate date null,
	primary key (orderId, itemId)
);

create table User_ (
	userId varchar2(100) not null primary key,
	companyId varchar2(100) not null,
	createDate date null,
	password_ varchar2(100) null,
	passwordEncrypted number(1, 0),
	passwordExpirationDate date null,
	passwordReset number(1, 0),
	firstName varchar2(100) null,
	middleName varchar2(100) null,
	lastName varchar2(100) null,
	nickName varchar2(100) null,
	male number(1, 0),
	birthday date null,
	emailAddress varchar2(100) null,
	smsId varchar2(100) null,
	aimId varchar2(100) null,
	icqId varchar2(100) null,
	msnId varchar2(100) null,
	ymId varchar2(100) null,
	favoriteActivity varchar2(100) null,
	favoriteBibleVerse varchar2(100) null,
	favoriteFood varchar2(100) null,
	favoriteMovie varchar2(100) null,
	favoriteMusic varchar2(100) null,
	languageId varchar2(100) null,
	timeZoneId varchar2(100) null,
	skinId varchar2(100) null,
	dottedSkins number(1, 0),
	roundedSkins number(1, 0),
	greeting varchar2(100) null,
	resolution varchar2(100) null,
	refreshRate varchar2(100) null,
	layoutIds varchar2(100) null,
	comments varchar2(4000) null,
	loginDate date null,
	loginIP varchar2(100) null,
	lastLoginDate date null,
	lastLoginIP varchar2(100) null,
	failedLoginAttempts number(30,0),
	agreedToTermsOfUse number(1, 0),
	active_ number(1, 0)
);

create table Users_ProjProjects (
	userId varchar2(100) not null,
	projectId varchar2(100) not null
);

create table Users_ProjTasks (
	userId varchar2(100) not null,
	taskId varchar2(100) not null
);

create table UserTracker (
	userTrackerId varchar2(100) not null primary key,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	modifiedDate date null,
	remoteAddr varchar2(100) null,
	remoteHost varchar2(100) null,
	userAgent varchar2(100) null
);

create table UserTrackerPath (
	userTrackerPathId varchar2(100) not null primary key,
	userTrackerId varchar2(100) not null,
	path varchar2(4000) not null,
	pathDate date not null
);

create table WikiDisplay (
	layoutId varchar2(100) not null,
	userId varchar2(100) not null,
	portletId varchar2(100) not null,
	nodeId varchar2(100) not null,
	showBorders number(1, 0),
	primary key (layoutId, userId, portletId)
);

create table WikiNode (
	nodeId varchar2(100) not null primary key,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	userName varchar2(100) null,
	createDate date null,
	modifiedDate date null,
	readRoles varchar2(100) null,
	writeRoles varchar2(100) null,
	name varchar2(100) null,
	description varchar2(4000) null,
	sharing number(1, 0),
	lastPostDate date null
);

create table WikiPage (
	nodeId varchar2(100) not null,
	title varchar2(100) not null,
	version number(30,20) not null,
	companyId varchar2(100) not null,
	userId varchar2(100) not null,
	userName varchar2(100) null,
	createDate date null,
	content long varchar null,
	format varchar2(100) null,
	head number(1, 0),
	primary key (nodeId, title, version)
);

--
-- Global
--

insert into Counter values ('com.liferay.portal.model.Address', 10);
insert into Counter values ('com.liferay.portal.model.Group', 20);
insert into Counter values ('com.liferay.portal.model.Role', 100);
insert into Counter values ('com.liferay.portal.model.User.liferay.com', 10);
insert into Counter values ('com.liferay.portlet.imagegallery.model.IGFolder', 20);
insert into Counter values ('com.liferay.portlet.imagegallery.model.IGImage.liferay.com', 42);
insert into Counter values ('com.liferay.portlet.polls.model.PollsQuestion', 10);
insert into Counter values ('com.liferay.portlet.shopping.model.ShoppingCategory', 20);
insert into Counter values ('com.liferay.portlet.shopping.ejb.ShoppingItem', 40);
insert into Counter values ('com.liferay.portlet.wiki.model.WikiNode', 10);

--
-- Liferay, LLC
--

insert into Company (companyId, portalURL, homeURL, mx, name, shortName, type_, size_, emailAddress, authType, autoLogin, strangers) values ('liferay.com', 'localhost', 'localhost', 'liferay.com', 'Liferay, LLC', 'Liferay', 'biz', '', 'test@liferay.com', 'emailAddress', '1', '1');
update Company set street = '1220 Brea Canyon Rd.', city = 'Diamond Bar', state = 'CA', zip = '91789' where companyId = 'liferay.com';

insert into IGFolder (folderId, groupId, companyId, userId, createDate, modifiedDate, parentFolderId, name) values ('11','3','liferay.com','liferay.com.1',sysdate,sysdate,'-1','COMMON');
insert into IGFolder (folderId, groupId, companyId, userId, createDate, modifiedDate, parentFolderId, name) values ('12','3','liferay.com','liferay.com.1',sysdate,sysdate,'11','HEADER');
insert into IGFolder (folderId, groupId, companyId, userId, createDate, modifiedDate, parentFolderId, name) values ('13','3','liferay.com','liferay.com.1',sysdate,sysdate,'-1','HOME');
insert into IGFolder (folderId, groupId, companyId, userId, createDate, modifiedDate, parentFolderId, name) values ('14','3','liferay.com','liferay.com.1',sysdate,sysdate,'-1','COMPANY');
insert into IGFolder (folderId, groupId, companyId, userId, createDate, modifiedDate, parentFolderId, name) values ('15','3','liferay.com','liferay.com.1',sysdate,sysdate,'-1','PRODUCTS');
insert into IGFolder (folderId, groupId, companyId, userId, createDate, modifiedDate, parentFolderId, name) values ('16','3','liferay.com','liferay.com.1',sysdate,sysdate,'-1','SERVICES');
insert into IGFolder (folderId, groupId, companyId, userId, createDate, modifiedDate, parentFolderId, name) values ('17','3','liferay.com','liferay.com.1',sysdate,sysdate,'-1','DOCUMENTATION');
insert into IGFolder (folderId, groupId, companyId, userId, createDate, modifiedDate, parentFolderId, name) values ('18','3','liferay.com','liferay.com.1',sysdate,sysdate,'-1','NEWS');
insert into IGFolder (folderId, groupId, companyId, userId, createDate, modifiedDate, parentFolderId, name) values ('19','3','liferay.com','liferay.com.1',sysdate,sysdate,'-1','DOWNLOADS');

insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('1','liferay.com','liferay.com.1',sysdate,sysdate,'12','',49,199,4102);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('2','liferay.com','liferay.com.1',sysdate,sysdate,'12','',9,56,283);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('3','liferay.com','liferay.com.1',sysdate,sysdate,'12','',9,56,283);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('4','liferay.com','liferay.com.1',sysdate,sysdate,'12','',9,57,283);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('5','liferay.com','liferay.com.1',sysdate,sysdate,'12','',9,57,283);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('6','liferay.com','liferay.com.1',sysdate,sysdate,'12','',9,49,264);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('7','liferay.com','liferay.com.1',sysdate,sysdate,'12','',9,49,264);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('8','liferay.com','liferay.com.1',sysdate,sysdate,'12','',9,91,404);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('9','liferay.com','liferay.com.1',sysdate,sysdate,'12','',9,91,404);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('10','liferay.com','liferay.com.1',sysdate,sysdate,'12','',9,31,199);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('11','liferay.com','liferay.com.1',sysdate,sysdate,'12','',9,31,199);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('12','liferay.com','liferay.com.1',sysdate,sysdate,'12','',9,70,344);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('13','liferay.com','liferay.com.1',sysdate,sysdate,'12','',9,70,344);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('14','liferay.com','liferay.com.1',sysdate,sysdate,'11','',1,1,49);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('15','liferay.com','liferay.com.1',sysdate,sysdate,'11','',14,8,516);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('16','liferay.com','liferay.com.1',sysdate,sysdate,'11','',10,10,75);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('17','liferay.com','liferay.com.1',sysdate,sysdate,'11','',8,8,64);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('18','liferay.com','liferay.com.1',sysdate,sysdate,'11','',9,13,206);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('19','liferay.com','liferay.com.1',sysdate,sysdate,'11','',262,1,61);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('20','liferay.com','liferay.com.1',sysdate,sysdate,'11','',1,262,834);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('21','liferay.com','liferay.com.1',sysdate,sysdate,'13','',15,80,533);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('22','liferay.com','liferay.com.1',sysdate,sysdate,'13','',15,62,442);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('23','liferay.com','liferay.com.1',sysdate,sysdate,'13','',94,127,6388);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('24','liferay.com','liferay.com.1',sysdate,sysdate,'13','',94,127,4866);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('25','liferay.com','liferay.com.1',sysdate,sysdate,'13','',10,70,426);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('26','liferay.com','liferay.com.1',sysdate,sysdate,'13','',25,90,1755);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('27','liferay.com','liferay.com.1',sysdate,sysdate,'13','',11,37,293);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('28','liferay.com','liferay.com.1',sysdate,sysdate,'13','',11,64,441);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('29','liferay.com','liferay.com.1',sysdate,sysdate,'13','',14,14,138);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('30','liferay.com','liferay.com.1',sysdate,sysdate,'13','',14,105,442);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('31','liferay.com','liferay.com.1',sysdate,sysdate,'14','company.jpg',100,550,51917);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('35','liferay.com','liferay.com.1',sysdate,sysdate,'16','services.jpg',100,550,33075);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('33','liferay.com','liferay.com.1',sysdate,sysdate,'15','products.jpg',100,550,36698);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('34','liferay.com','liferay.com.1',sysdate,sysdate,'15','products_title.gif',22,106,652);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('32','liferay.com','liferay.com.1',sysdate,sysdate,'14','company_title.gif',22,106,658);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('36','liferay.com','liferay.com.1',sysdate,sysdate,'16','services_title.gif',22,84,598);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('37','liferay.com','liferay.com.1',sysdate,sysdate,'17','documentation.jpg',100,550,33688);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('38','liferay.com','liferay.com.1',sysdate,sysdate,'17','documentation_title.gif',22,162,932);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('39','liferay.com','liferay.com.1',sysdate,sysdate,'18','news.jpg',100,550,27641);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('40','liferay.com','liferay.com.1',sysdate,sysdate,'18','news_title.gif',22,55,463);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('41','liferay.com','liferay.com.1',sysdate,sysdate,'19','downloads.jpg',100,550,33579);
insert into IGImage (imageId, companyId, userId, createDate, modifiedDate, folderId, description, height, width, size_) values ('42','liferay.com','liferay.com.1',sysdate,sysdate,'19','downloads_title.gif',22,124,786);

insert into ShoppingCategory (categoryId, companyId, createDate, modifiedDate, parentCategoryId, name) values ('1', 'liferay.com', sysdate, sysdate, '-1', 'Books');
insert into ShoppingCategory (categoryId, companyId, createDate, modifiedDate, parentCategoryId, name) values ('2', 'liferay.com', sysdate, sysdate, '1', 'Art');
insert into ShoppingCategory (categoryId, companyId, createDate, modifiedDate, parentCategoryId, name) values ('3', 'liferay.com', sysdate, sysdate, '1', 'Christian');
insert into ShoppingCategory (categoryId, companyId, createDate, modifiedDate, parentCategoryId, name) values ('4', 'liferay.com', sysdate, sysdate, '1', 'Computer Science');
insert into ShoppingCategory (categoryId, companyId, createDate, modifiedDate, parentCategoryId, name) values ('5', 'liferay.com', sysdate, sysdate, '1', 'Economics');
insert into ShoppingCategory (categoryId, companyId, createDate, modifiedDate, parentCategoryId, name) values ('6', 'liferay.com', sysdate, sysdate, '1', 'Physics');


insert into PollsDisplay (layoutId, userId, portletId, questionId) values ('1.1', 'group.1', '59', '1');
insert into PollsChoice (choiceId, questionId, description) values ('a', '1', 'Chocolate');
insert into PollsChoice (choiceId, questionId, description) values ('b', '1', 'Strawberry');
insert into PollsChoice (choiceId, questionId, description) values ('c', '1', 'Vanilla');
insert into PollsQuestion (questionId, portletId, groupId, companyId, userId, userName, createDate, modifiedDate, title, description) values ('1', '25', '-1', 'liferay.com', 'liferay.com.1', 'John Wayne', sysdate, sysdate, 'What is your favorite ice cream flavor?', 'What is your favorite ice cream flavor?');

insert into WikiDisplay (layoutId, userId, portletId, nodeId, showBorders) values ('1.1', 'group.1', '54', '1', '1');
insert into WikiNode (nodeId, companyId, userId, userName, createDate, modifiedDate, readRoles, writeRoles, name, description, sharing, lastPostDate) values ('1', 'liferay.com', 'liferay.com.1', 'John Wayne', sysdate, sysdate, 'User,' ,'User,', 'Welcome', '', '1', sysdate);
insert into WikiPage (nodeId, title, version, companyId, userId, userName, createDate, content, format, head) values ('1', 'FrontPage', 1.0, 'liferay.com', 'liferay.com.1', 'John Wayne', sysdate, '<font class="bg" size="2">Welcome! Thank you for your interest in Liferay Enterprise Portal.<br><br>Your login is <b>test@liferay.com</b> and your password is <b>test</b>. The test user has the Administrator role.<br><br>To use the <b>Mail</b> portlet, make sure there is a mail server running on <i>localhost</i> accessible through the IMAP protocol.<br><br>The mail server must have an account with <b>liferay.com.1</b> as the user and <b>test</b> as the password.<br><br><hr><br>Is Liferay useful for your company? Tell us about it by email at <b>staff@liferay.com</b>.<br><br>We hope you enjoy our product!</font>', 'html', '1');

--
-- Default User
--

insert into User_ (userId, companyId, createDate, password_, passwordEncrypted, passwordReset, firstName, middleName, lastName, male, birthday, emailAddress, skinId, dottedSkins, roundedSkins, greeting, layoutIds, loginDate, failedLoginAttempts, agreedToTermsOfUse, active_) values ('liferay.com.default', 'default', sysdate, 'password', '0', '0', '', '', '', '1', to_date('1970-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS'), 'default@liferay.com', '01', '0', '0', 'Welcome!', '', sysdate, 0, '0', '1');

--
-- Test User
--

insert into User_ (userId, companyId, createDate, password_, passwordEncrypted, passwordReset, firstName, middleName, lastName, nickName, male, birthday, emailAddress, skinId, dottedSkins, roundedSkins, greeting, layoutIds, loginDate, failedLoginAttempts, agreedToTermsOfUse, active_) values ('liferay.com.1', 'liferay.com', sysdate, 'test', '0', '0', 'John', '', 'Wayne', 'Duke', '1', to_date('1970-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS'), 'test@liferay.com', '01', '0', '1', 'Welcome John Wayne!', '1,', sysdate, 0, '1', '1');
CREATE TABLE qrtz_job_details
  (
    JOB_NAME  VARCHAR2(80) NOT NULL,
    JOB_GROUP VARCHAR2(80) NOT NULL,
    DESCRIPTION VARCHAR2(120) NULL,
    JOB_CLASS_NAME   VARCHAR2(128) NOT NULL, 
    IS_DURABLE VARCHAR2(1) NOT NULL,
    IS_VOLATILE VARCHAR2(1) NOT NULL,
    IS_STATEFUL VARCHAR2(1) NOT NULL,
    REQUESTS_RECOVERY VARCHAR2(1) NOT NULL,
    JOB_DATA BLOB NULL,
    PRIMARY KEY (JOB_NAME,JOB_GROUP)
);
CREATE TABLE qrtz_job_listeners
  (
    JOB_NAME  VARCHAR2(80) NOT NULL, 
    JOB_GROUP VARCHAR2(80) NOT NULL,
    JOB_LISTENER VARCHAR2(80) NOT NULL,
    PRIMARY KEY (JOB_NAME,JOB_GROUP,JOB_LISTENER),
    FOREIGN KEY (JOB_NAME,JOB_GROUP) 
	REFERENCES QRTZ_JOB_DETAILS(JOB_NAME,JOB_GROUP)
);
CREATE TABLE qrtz_triggers
  (
    TRIGGER_NAME VARCHAR2(80) NOT NULL,
    TRIGGER_GROUP VARCHAR2(80) NOT NULL,
    JOB_NAME  VARCHAR2(80) NOT NULL, 
    JOB_GROUP VARCHAR2(80) NOT NULL,
    IS_VOLATILE VARCHAR2(1) NOT NULL,
    DESCRIPTION VARCHAR2(120) NULL,
    NEXT_FIRE_TIME NUMBER(13) NULL,
    PREV_FIRE_TIME NUMBER(13) NULL,
    PRIORITY NUMBER(13) NULL,
    TRIGGER_STATE VARCHAR2(16) NOT NULL,
    TRIGGER_TYPE VARCHAR2(8) NOT NULL,
    START_TIME NUMBER(13) NOT NULL,
    END_TIME NUMBER(13) NULL,
    CALENDAR_NAME VARCHAR2(80) NULL,
    MISFIRE_INSTR NUMBER(2) NULL,
    JOB_DATA BLOB NULL,
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP),
    FOREIGN KEY (JOB_NAME,JOB_GROUP) 
	REFERENCES QRTZ_JOB_DETAILS(JOB_NAME,JOB_GROUP) 
);
CREATE TABLE qrtz_simple_triggers
  (
    TRIGGER_NAME VARCHAR2(80) NOT NULL,
    TRIGGER_GROUP VARCHAR2(80) NOT NULL,
    REPEAT_COUNT NUMBER(7) NOT NULL,
    REPEAT_INTERVAL NUMBER(12) NOT NULL,
    TIMES_TRIGGERED NUMBER(7) NOT NULL,
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP),
    FOREIGN KEY (TRIGGER_NAME,TRIGGER_GROUP) 
	REFERENCES QRTZ_TRIGGERS(TRIGGER_NAME,TRIGGER_GROUP)
);
CREATE TABLE qrtz_cron_triggers
  (
    TRIGGER_NAME VARCHAR2(80) NOT NULL,
    TRIGGER_GROUP VARCHAR2(80) NOT NULL,
    CRON_EXPRESSION VARCHAR2(80) NOT NULL,
    TIME_ZONE_ID VARCHAR2(80),
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP),
    FOREIGN KEY (TRIGGER_NAME,TRIGGER_GROUP) 
	REFERENCES QRTZ_TRIGGERS(TRIGGER_NAME,TRIGGER_GROUP)
);
CREATE TABLE qrtz_blob_triggers
  (
    TRIGGER_NAME VARCHAR2(80) NOT NULL,
    TRIGGER_GROUP VARCHAR2(80) NOT NULL,
    BLOB_DATA BLOB NULL,
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP),
    FOREIGN KEY (TRIGGER_NAME,TRIGGER_GROUP) 
        REFERENCES QRTZ_TRIGGERS(TRIGGER_NAME,TRIGGER_GROUP)
);
CREATE TABLE qrtz_trigger_listeners
  (
    TRIGGER_NAME  VARCHAR2(80) NOT NULL, 
    TRIGGER_GROUP VARCHAR2(80) NOT NULL,
    TRIGGER_LISTENER VARCHAR2(80) NOT NULL,
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP,TRIGGER_LISTENER),
    FOREIGN KEY (TRIGGER_NAME,TRIGGER_GROUP) 
	REFERENCES QRTZ_TRIGGERS(TRIGGER_NAME,TRIGGER_GROUP)
);
CREATE TABLE qrtz_calendars
  (
    CALENDAR_NAME  VARCHAR2(80) NOT NULL, 
    CALENDAR BLOB NOT NULL,
    PRIMARY KEY (CALENDAR_NAME)
);
CREATE TABLE qrtz_paused_trigger_grps
  (
    TRIGGER_GROUP  VARCHAR2(80) NOT NULL, 
    PRIMARY KEY (TRIGGER_GROUP)
);
CREATE TABLE qrtz_fired_triggers 
  (
    ENTRY_ID VARCHAR2(95) NOT NULL,
    TRIGGER_NAME VARCHAR2(80) NOT NULL,
    TRIGGER_GROUP VARCHAR2(80) NOT NULL,
    IS_VOLATILE VARCHAR2(1) NOT NULL,
    INSTANCE_NAME VARCHAR2(80) NOT NULL,
    FIRED_TIME NUMBER(13) NOT NULL,
    PRIORITY NUMBER(13) NOT NULL,
    STATE VARCHAR2(16) NOT NULL,
    JOB_NAME VARCHAR2(80) NULL,
    JOB_GROUP VARCHAR2(80) NULL,
    IS_STATEFUL VARCHAR2(1) NULL,
    REQUESTS_RECOVERY VARCHAR2(1) NULL,
    PRIMARY KEY (ENTRY_ID)
);
CREATE TABLE qrtz_scheduler_state 
  (
    INSTANCE_NAME VARCHAR2(80) NOT NULL,
    LAST_CHECKIN_TIME NUMBER(13) NOT NULL,
    CHECKIN_INTERVAL NUMBER(13) NOT NULL,
    PRIMARY KEY (INSTANCE_NAME)
);
CREATE TABLE qrtz_locks
  (
    LOCK_NAME  VARCHAR2(40) NOT NULL, 
    PRIMARY KEY (LOCK_NAME)
);
INSERT INTO qrtz_locks values('TRIGGER_ACCESS');
INSERT INTO qrtz_locks values('JOB_ACCESS');
INSERT INTO qrtz_locks values('CALENDAR_ACCESS');
INSERT INTO qrtz_locks values('STATE_ACCESS');
INSERT INTO qrtz_locks values('MISFIRE_ACCESS');
create index idx_qrtz_j_req_recovery on qrtz_job_details(REQUESTS_RECOVERY);
create index idx_qrtz_t_next_fire_time on qrtz_triggers(NEXT_FIRE_TIME);
create index idx_qrtz_t_state on qrtz_triggers(TRIGGER_STATE);
create index idx_qrtz_t_nft_st on qrtz_triggers(NEXT_FIRE_TIME,TRIGGER_STATE);
create index idx_qrtz_t_volatile on qrtz_triggers(IS_VOLATILE);
create index idx_qrtz_ft_trig_name on qrtz_fired_triggers(TRIGGER_NAME);
create index idx_qrtz_ft_trig_group on qrtz_fired_triggers(TRIGGER_GROUP);
create index idx_qrtz_ft_trig_nm_gp on qrtz_fired_triggers(TRIGGER_NAME,TRIGGER_GROUP);
create index idx_qrtz_ft_trig_volatile on qrtz_fired_triggers(IS_VOLATILE);
create index idx_qrtz_ft_trig_inst_name on qrtz_fired_triggers(INSTANCE_NAME);
create index idx_qrtz_ft_job_name on qrtz_fired_triggers(JOB_NAME);
create index idx_qrtz_ft_job_group on qrtz_fired_triggers(JOB_GROUP);
create index idx_qrtz_ft_job_stateful on qrtz_fired_triggers(IS_STATEFUL);
create index idx_qrtz_ft_job_req_recovery on qrtz_fired_triggers(REQUESTS_RECOVERY);


CREATE TABLE qrtz_excl_job_details
  (
    JOB_NAME  VARCHAR2(80) NOT NULL,
    JOB_GROUP VARCHAR2(80) NOT NULL,
    DESCRIPTION VARCHAR2(120) NULL,
    JOB_CLASS_NAME   VARCHAR2(128) NOT NULL, 
    IS_DURABLE VARCHAR2(1) NOT NULL,
    IS_VOLATILE VARCHAR2(1) NOT NULL,
    IS_STATEFUL VARCHAR2(1) NOT NULL,
    REQUESTS_RECOVERY VARCHAR2(1) NOT NULL,
    JOB_DATA BLOB NULL,
    PRIMARY KEY (JOB_NAME,JOB_GROUP)
);
CREATE TABLE qrtz_excl_job_listeners
  (
    JOB_NAME  VARCHAR2(80) NOT NULL, 
    JOB_GROUP VARCHAR2(80) NOT NULL,
    JOB_LISTENER VARCHAR2(80) NOT NULL,
    PRIMARY KEY (JOB_NAME,JOB_GROUP,JOB_LISTENER),
    FOREIGN KEY (JOB_NAME,JOB_GROUP) 
	REFERENCES QRTZ_EXCL_JOB_DETAILS(JOB_NAME,JOB_GROUP)
);
CREATE TABLE qrtz_excl_triggers
  (
    TRIGGER_NAME VARCHAR2(80) NOT NULL,
    TRIGGER_GROUP VARCHAR2(80) NOT NULL,
    JOB_NAME  VARCHAR2(80) NOT NULL, 
    JOB_GROUP VARCHAR2(80) NOT NULL,
    IS_VOLATILE VARCHAR2(1) NOT NULL,
    DESCRIPTION VARCHAR2(120) NULL,
    NEXT_FIRE_TIME NUMBER(13) NULL,
    PREV_FIRE_TIME NUMBER(13) NULL,
    PRIORITY NUMBER(13) NULL,
    TRIGGER_STATE VARCHAR2(16) NOT NULL,
    TRIGGER_TYPE VARCHAR2(8) NOT NULL,
    START_TIME NUMBER(13) NOT NULL,
    END_TIME NUMBER(13) NULL,
    CALENDAR_NAME VARCHAR2(80) NULL,
    MISFIRE_INSTR NUMBER(2) NULL,
    JOB_DATA BLOB NULL,
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP),
    FOREIGN KEY (JOB_NAME,JOB_GROUP) 
	REFERENCES QRTZ_EXCL_JOB_DETAILS(JOB_NAME,JOB_GROUP) 
);
CREATE TABLE qrtz_excl_simple_triggers
  (
    TRIGGER_NAME VARCHAR2(80) NOT NULL,
    TRIGGER_GROUP VARCHAR2(80) NOT NULL,
    REPEAT_COUNT NUMBER(7) NOT NULL,
    REPEAT_INTERVAL NUMBER(12) NOT NULL,
    TIMES_TRIGGERED NUMBER(7) NOT NULL,
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP),
    FOREIGN KEY (TRIGGER_NAME,TRIGGER_GROUP) 
	REFERENCES QRTZ_EXCL_TRIGGERS(TRIGGER_NAME,TRIGGER_GROUP)
);
CREATE TABLE qrtz_excl_cron_triggers
  (
    TRIGGER_NAME VARCHAR2(80) NOT NULL,
    TRIGGER_GROUP VARCHAR2(80) NOT NULL,
    CRON_EXPRESSION VARCHAR2(80) NOT NULL,
    TIME_ZONE_ID VARCHAR2(80),
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP),
    FOREIGN KEY (TRIGGER_NAME,TRIGGER_GROUP) 
	REFERENCES QRTZ_EXCL_TRIGGERS(TRIGGER_NAME,TRIGGER_GROUP)
);
CREATE TABLE qrtz_excl_blob_triggers
  (
    TRIGGER_NAME VARCHAR2(80) NOT NULL,
    TRIGGER_GROUP VARCHAR2(80) NOT NULL,
    BLOB_DATA BLOB NULL,
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP),
    FOREIGN KEY (TRIGGER_NAME,TRIGGER_GROUP) 
        REFERENCES QRTZ_EXCL_TRIGGERS(TRIGGER_NAME,TRIGGER_GROUP)
);
CREATE TABLE qrtz_excl_trigger_listeners
  (
    TRIGGER_NAME  VARCHAR2(80) NOT NULL, 
    TRIGGER_GROUP VARCHAR2(80) NOT NULL,
    TRIGGER_LISTENER VARCHAR2(80) NOT NULL,
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP,TRIGGER_LISTENER),
    FOREIGN KEY (TRIGGER_NAME,TRIGGER_GROUP) 
	REFERENCES QRTZ_EXCL_TRIGGERS(TRIGGER_NAME,TRIGGER_GROUP)
);
CREATE TABLE qrtz_excl_calendars
  (
    CALENDAR_NAME  VARCHAR2(80) NOT NULL, 
    CALENDAR BLOB NOT NULL,
    PRIMARY KEY (CALENDAR_NAME)
);
CREATE TABLE qrtz_excl_paused_trigger_grps
  (
    TRIGGER_GROUP  VARCHAR2(80) NOT NULL, 
    PRIMARY KEY (TRIGGER_GROUP)
);
CREATE TABLE qrtz_excl_fired_triggers 
  (
    ENTRY_ID VARCHAR2(95) NOT NULL,
    TRIGGER_NAME VARCHAR2(80) NOT NULL,
    TRIGGER_GROUP VARCHAR2(80) NOT NULL,
    IS_VOLATILE VARCHAR2(1) NOT NULL,
    INSTANCE_NAME VARCHAR2(80) NOT NULL,
    FIRED_TIME NUMBER(13) NOT NULL,
    PRIORITY NUMBER(13) NOT NULL,
    STATE VARCHAR2(16) NOT NULL,
    JOB_NAME VARCHAR2(80) NULL,
    JOB_GROUP VARCHAR2(80) NULL,
    IS_STATEFUL VARCHAR2(1) NULL,
    REQUESTS_RECOVERY VARCHAR2(1) NULL,
    PRIMARY KEY (ENTRY_ID)
);
CREATE TABLE qrtz_excl_scheduler_state 
  (
    INSTANCE_NAME VARCHAR2(80) NOT NULL,
    LAST_CHECKIN_TIME NUMBER(13) NOT NULL,
    CHECKIN_INTERVAL NUMBER(13) NOT NULL,
    PRIMARY KEY (INSTANCE_NAME)
);
CREATE TABLE qrtz_excl_locks
  (
    LOCK_NAME  VARCHAR2(40) NOT NULL, 
    PRIMARY KEY (LOCK_NAME)
);
INSERT INTO qrtz_excl_locks values('TRIGGER_ACCESS');
INSERT INTO qrtz_excl_locks values('JOB_ACCESS');
INSERT INTO qrtz_excl_locks values('CALENDAR_ACCESS');
INSERT INTO qrtz_excl_locks values('STATE_ACCESS');
INSERT INTO qrtz_excl_locks values('MISFIRE_ACCESS');
create index idx_qrtz_excl_j_req_recovery on qrtz_excl_job_details(REQUESTS_RECOVERY);
create index idx_qrtz_excl_t_next_fire_time on qrtz_excl_triggers(NEXT_FIRE_TIME);
create index idx_qrtz_excl_t_state on qrtz_excl_triggers(TRIGGER_STATE);
create index idx_qrtz_excl_t_nft_st on qrtz_excl_triggers(NEXT_FIRE_TIME,TRIGGER_STATE);
create index idx_qrtz_excl_t_volatile on qrtz_excl_triggers(IS_VOLATILE);
create index idx_qrtz_excl_ft_trig_name on qrtz_excl_fired_triggers(TRIGGER_NAME);
create index idx_qrtz_excl_ft_trig_group on qrtz_excl_fired_triggers(TRIGGER_GROUP);
create index idx_qrtz_excl_ft_trig_nm_gp on qrtz_excl_fired_triggers(TRIGGER_NAME,TRIGGER_GROUP);
create index idx_qrtz_excl_ft_trig_volatile on qrtz_excl_fired_triggers(IS_VOLATILE);
create index idx_qrtz_excl_fttriginstname on qrtz_excl_fired_triggers(INSTANCE_NAME);
create index idx_qrtz_excl_ft_jobname on qrtz_excl_fired_triggers(JOB_NAME);
create index idx_qrtz_excl_ft_jobgroup on qrtz_excl_fired_triggers(JOB_GROUP);
create index idx_qrtz_excl_ft_jobstateful on qrtz_excl_fired_triggers(IS_STATEFUL);
create index idx_qrtzexclftjobreqrec on qrtz_excl_fired_triggers(REQUESTS_RECOVERY);
create table calendar_reminder (
   user_id varchar2(255) not null,
   event_id varchar2(100) not null,
   send_date date not null,
   primary key (user_id, event_id, send_date)
);
create table ecom_product_price (
   inode varchar2(100) not null,
   product_format_inode varchar2(100) not null,
   min_qty number(10,0),
   max_qty number(10,0),
   retail_price float not null,
   partner_price float not null,
   primary key (inode)
);
create table tag (
   tagname varchar2(255) not null,
   user_id varchar2(255),
   primary key (tagname)
);
create table entity (
   inode varchar2(100) not null,
   entity_name varchar2(255),
   primary key (inode)
);
create table user_comments (
   inode varchar2(100) not null,
   user_id varchar2(255),
   cdate date,
   comment_user_id varchar2(100),
   type varchar2(255),
   method varchar2(255),
   subject varchar2(255),
   ucomment nclob,
   communication_id varchar2(100),
   primary key (inode)
);
create table permission_reference (
   id number(19,0) not null,
   asset_id varchar2(100),
   reference_id varchar2(100),
   permission_type varchar2(100),
   primary key (id),
   unique (asset_id)
);
create table fixes_audit (
   id varchar2(255) not null,
   table_name varchar2(255),
   action varchar2(255),
   records_altered number(10,0),
   datetime date,
   primary key (id)
);
create table trackback (
   id number(19,0) not null,
   asset_identifier varchar2(100),
   title varchar2(255),
   excerpt varchar2(255),
   url varchar2(255),
   blog_name varchar2(255),
   track_date date not null,
   primary key (id)
);
create table plugin (
   id varchar2(255) not null,
   plugin_name varchar2(255) not null,
   plugin_version varchar2(255) not null,
   author varchar2(255) not null,
   first_deployed_date date not null,
   last_deployed_date date not null,
   primary key (id)
);
create table recipient (
   inode varchar2(100) not null,
   name varchar2(255),
   lastname varchar2(255),
   email varchar2(255),
   sent date,
   opened date,
   last_result number(10,0),
   last_message varchar2(255),
   user_id varchar2(100),
   primary key (inode)
);
create table mailing_list (
   inode varchar2(100) not null,
   title varchar2(255),
   public_list number(1,0),
   user_id varchar2(255),
   primary key (inode)
);
create table web_form (
   web_form_id varchar2(100) not null,
   form_type varchar2(255),
   submit_date date,
   prefix varchar2(255),
   first_name varchar2(255),
   middle_initial varchar2(255),
   middle_name varchar2(255),
   full_name varchar2(255),
   organization varchar2(255),
   title varchar2(255),
   last_name varchar2(255),
   address varchar2(255),
   address1 varchar2(255),
   address2 varchar2(255),
   city varchar2(255),
   state varchar2(255),
   zip varchar2(255),
   country varchar2(255),
   phone varchar2(255),
   email varchar2(255),
   custom_fields nclob,
   user_inode varchar2(100),
   categories varchar2(255),
   primary key (web_form_id)
);
create table virtual_link (
   inode varchar2(100) not null,
   title varchar2(255),
   url varchar2(255),
   uri varchar2(255),
   active number(1,0),
   primary key (inode)
);
create table tree (
   child varchar2(100) not null,
   parent varchar2(100) not null,
   relation_type varchar2(64) not null,
   tree_order number(10,0),
   primary key (child, parent, relation_type)
);
create table event (
   inode varchar2(100) not null,
   title varchar2(255),
   subtitle varchar2(255),
   start_date date,
   end_date date,
   location varchar2(255),
   address1 varchar2(255),
   address2 varchar2(255),
   address3 varchar2(255),
   city varchar2(255),
   state varchar2(255),
   zip varchar2(32),
   country varchar2(64),
   email varchar2(64),
   phone varchar2(64),
   fax varchar2(64),
   url varchar2(255),
   registration number(1,0),
   include_file varchar2(255),
   show_public number(1,0),
   contact_name varchar2(255),
   contact_company varchar2(255),
   contact_phone varchar2(255),
   contact_email varchar2(255),
   contact_fax varchar2(255),
   directions nclob,
   description nclob,
   email_response nclob,
   web_address varchar2(255),
   user_id varchar2(255),
   featured number(1,0),
   setup_date date,
   break_date date,
   approval_status number(10,0),
   comments_equipment nclob,
   received_adm_approval number(1,0),
   time_tbd number(1,0),
   primary key (inode)
);
create table users_cms_roles (
   id varchar2(255) not null,
   user_id varchar2(100) not null,
   role_id varchar2(100) not null,
   primary key (id)
);
create table web_event (
   inode varchar2(100) not null,
   title varchar2(255),
   subtitle varchar2(255),
   summary varchar2(1000),
   description varchar2(255),
   terms_conditions varchar2(255),
   comments varchar2(255),
   partners_only number(1,0),
   show_on_web number(1,0),
   sort_order number(10,0),
   event_image_1 varchar2(100),
   event_image_2 varchar2(100),
   event_image_3 varchar2(100),
   event_image_4 varchar2(100),
   is_institute number(1,0),
   primary key (inode)
);
create table ecom_product (
   inode varchar2(100) not null,
   title varchar2(255) not null,
   short_description nclob,
   long_description nclob,
   req_shipping number(1,0),
   featured number(1,0),
   sort_order number(10,0),
   comments nclob,
   showonweb number(1,0),
   primary key (inode)
);
create table template (
   inode varchar2(100) not null,
   live number(1,0),
   working number(1,0),
   deleted number(1,0),
   locked number(1,0),
   show_on_menu number(1,0),
   title varchar2(255),
   mod_date date,
   mod_user varchar2(100),
   sort_order number(10,0),
   friendly_name varchar2(255),
   body nclob,
   header nclob,
   footer nclob,
   image varchar2(100),
   primary key (inode)
);
create table ecom_order_item (
   inode varchar2(100) not null,
   order_inode varchar2(100),
   product_inode varchar2(100),
   item_qty number(10,0),
   item_price float,
   primary key (inode)
);
create table structure (
   inode varchar2(100) not null,
   name varchar2(255),
   description varchar2(255),
   default_structure number(1,0),
   review_interval varchar2(255),
   reviewer_role varchar2(255),
   page_detail varchar2(100),
   structuretype number(10,0),
   system number(1,0),
   fixed number(1,0) not null,
   velocity_var_name varchar2(255),
   url_map_pattern varchar2(512),
   primary key (inode)
);
create table ecom_discount_code (
   inode varchar2(100) not null,
   discount_type number(10,0),
   start_date date,
   end_date date,
   code_id varchar2(50),
   code_description varchar2(100),
   free_shipping number(1,0),
   no_bulk_disc number(1,0),
   discount_amount float,
   min_order number(10,0),
   primary key (inode)
);
create table cms_role (
   id varchar2(100) not null,
   role_name varchar2(255) not null,
   description nclob,
   role_key varchar2(255),
   db_fqn varchar2(1000) not null,
   parent varchar2(100) not null,
   edit_permissions number(1,0),
   edit_users number(1,0),
   edit_layouts number(1,0),
   locked number(1,0),
   system number(1,0),
   primary key (id)
);
create table web_event_registration (
   inode varchar2(100) not null,
   event_inode varchar2(100),
   event_location_inode varchar2(100),
   user_inode varchar2(100),
   registration_status number(10,0),
   date_posted date,
   last_mod_date date,
   total_paid float,
   total_due float,
   total_registration float,
   payment_type number(10,0),
   billing_address_1 varchar2(255),
   billing_address_2 varchar2(255),
   billing_city varchar2(255),
   billing_state varchar2(50),
   billing_zip varchar2(50),
   billing_country varchar2(50),
   billing_contact_name varchar2(255),
   billing_contact_phone varchar2(50),
   billing_contact_email varchar2(255),
   card_name varchar2(255),
   card_type varchar2(50),
   card_number varchar2(50),
   card_exp_month varchar2(50),
   card_exp_year varchar2(50),
   card_verification_value varchar2(10),
   check_number varchar2(50),
   check_bank_name varchar2(255),
   po_number varchar2(50),
   invoice_number varchar2(50),
   badge_printed number(1,0),
   how_did_you_hear varchar2(255),
   ceo_name varchar2(255),
   modified_qb number(1,0),
   reminder_email_sent number(1,0),
   post_email_sent number(1,0),
   primary key (inode)
);
create table permission (
   id number(19,0) not null,
   permission_type varchar2(500),
   inode_id varchar2(100),
   roleid varchar2(100),
   permission number(10,0),
   primary key (id),
   unique (permission_type, inode_id, roleid)
);
create table recurance (
   inode varchar2(100) not null,
   recurrance_occurs varchar2(255),
   recurrance_interval number(10,0),
   recurrance_starting date,
   recurrance_ending date,
   recurrance_days_of_week varchar2(255),
   recurrance_day_of_month number(10,0),
   primary key (inode)
);
	create table contentlet (inode varchar2(100) not null,
	live number(1,0),
	working number(1,0),
	deleted number(1,0),
	locked number(1,0),
	show_on_menu number(1,0),
	title varchar2(255),
	mod_date date,
	mod_user varchar2(100),
	sort_order number(10,0),
	friendly_name varchar2(255),
	language_id number(19,0),
	structure_inode varchar2(100),
	last_review date,
	next_review date,
	review_interval varchar2(255),
	disabled_wysiwyg varchar2(255),
	folder varchar2(100),
	date1 date,
	date2 date,
	date3 date,
	date4 date,
	date5 date,
	date6 date,
	date7 date,
	date8 date,
	date9 date,
	date10 date,
	date11 date,
	date12 date,
	date13 date,
	date14 date,
	date15 date,
	date16 date,
	date17 date,
	date18 date,
	date19 date,
	date20 date,
	date21 date,
	date22 date,
	date23 date,
	date24 date,
	date25 date,
	text1 varchar2(255),
	text2 varchar2(255),
	text3 varchar2(255),
	text4 varchar2(255),
	text5 varchar2(255),
	text6 varchar2(255),
	text7 varchar2(255),
	text8 varchar2(255),
	text9 varchar2(255),
	text10 varchar2(255),
	text11 varchar2(255),
	text12 varchar2(255),
	text13 varchar2(255),
	text14 varchar2(255),
	text15 varchar2(255),
	text16 varchar2(255),
	text17 varchar2(255),
	text18 varchar2(255),
	text19 varchar2(255),
	text20 varchar2(255),
	text21 varchar2(255),
	text22 varchar2(255),
	text23 varchar2(255),
	text24 varchar2(255),
	text25 varchar2(255),
	text_area1 nclob,
	text_area2 nclob,
	text_area3 nclob,
	text_area4 nclob,
	text_area5 nclob,
	text_area6 nclob,
	text_area7 nclob,
	text_area8 nclob,
	text_area9 nclob,
	text_area10 nclob,
	text_area11 nclob,
	text_area12 nclob,
	text_area13 nclob,
	text_area14 nclob,
	text_area15 nclob,
	text_area16 nclob,
	text_area17 nclob,
	text_area18 nclob,
	text_area19 nclob,
	text_area20 nclob,
	text_area21 nclob,
	text_area22 nclob,
	text_area23 nclob,
	text_area24 nclob,
	text_area25 nclob,
	integer1 number(19,0),
	integer2 number(19,0),
	integer3 number(19,0),
	integer4 number(19,0),
	integer5 number(19,0),
	integer6 number(19,0),
	integer7 number(19,0),
	integer8 number(19,0),
	integer9 number(19,0),
	integer10 number(19,0),
	integer11 number(19,0),
	integer12 number(19,0),
	integer13 number(19,0),
	integer14 number(19,0),
	integer15 number(19,0),
	integer16 number(19,0),
	integer17 number(19,0),
	integer18 number(19,0),
	integer19 number(19,0),
	integer20 number(19,0),
	integer21 number(19,0),
	integer22 number(19,0),
	integer23 number(19,0),
	integer24 number(19,0),
	integer25 number(19,0),
	"float1" float,
	"float2" float,
	"float3" float,
	"float4" float,
	"float5" float,
	"float6" float,
	"float7" float,
	"float8" float,
	"float9" float,
	"float10" float,
	"float11" float,
	"float12" float,
	"float13" float,
	"float14" float,
	"float15" float,
	"float16" float,
	"float17" float,
	"float18" float,
	"float19" float,
	"float20" float,
	"float21" float,
	"float22" float,
	"float23" float,
	"float24" float,
	"float25" float,
	bool1 number(1,0),
	bool2 number(1,0),
	bool3 number(1,0),
	bool4 number(1,0),
	bool5 number(1,0),
	bool6 number(1,0),
	bool7 number(1,0),
	bool8 number(1,0),
	bool9 number(1,0),
	bool10 number(1,0),
	bool11 number(1,0),
	bool12 number(1,0),
	bool13 number(1,0),
	bool14 number(1,0),
	bool15 number(1,0),
	bool16 number(1,0),
	bool17 number(1,0),
	bool18 number(1,0),
	bool19 number(1,0),
	bool20 number(1,0),
	bool21 number(1,0),
	bool22 number(1,0),
	bool23 number(1,0),
	bool24 number(1,0),
	bool25 number(1,0),
	primary key (inode));
create table cms_layouts_portlets (
   id varchar2(255) not null,
   layout_id varchar2(100) not null,
   portlet_id varchar2(100) not null,
   portlet_order number(10,0),
   primary key (id)
);
create table workflow_comment (
   inode varchar2(100) not null,
   creation_date date,
   posted_by varchar2(255),
   wf_comment nclob,
   primary key (inode)
);
create table report_asset (
   inode varchar2(100) not null,
   report_name varchar2(255) not null,
   report_description varchar2(1000) not null,
   requires_input number(1,0),
   ds varchar2(100) not null,
   web_form_report number(1,0),
   primary key (inode)
);
create table category (
   inode varchar2(100) not null,
   category_name varchar2(255),
   category_key varchar2(255),
   sort_order number(10,0),
   active number(1,0),
   keywords nclob,
   category_velocity_var_name varchar2(255),
   primary key (inode)
);
create table htmlpage (
   inode varchar2(100) not null,
   live number(1,0),
   working number(1,0),
   deleted number(1,0),
   locked number(1,0),
   show_on_menu number(1,0),
   title varchar2(255),
   mod_date date,
   mod_user varchar2(100),
   sort_order number(10,0),
   friendly_name varchar2(255),
   metadata nclob,
   start_date date,
   end_date date,
   page_url varchar2(255),
   https_required number(1,0),
   redirect varchar2(255),
   primary key (inode)
);
create table chain_link_code (
   id number(19,0) not null,
   class_name varchar2(255) unique,
   code nclob not null,
   last_mod_date date not null,
   language varchar2(255) not null,
   primary key (id)
);
create table language (
   id number(19,0) not null,
   language_code varchar2(5),
   country_code varchar2(255),
   language varchar2(255),
   country varchar2(255),
   primary key (id)
);
create table user_preferences (
   id number(19,0) not null,
   user_id varchar2(100) not null,
   preference varchar2(255),
   pref_value nclob,
   primary key (id)
);
create table users_to_delete (
   id number(19,0) not null,
   user_id varchar2(255),
   primary key (id)
);
create table identifier (
   inode varchar2(100) not null,
   uri varchar2(255),
   host_inode varchar2(255),
   primary key (inode),
   unique (uri, host_inode)
);
create table clickstream (
   clickstream_id number(19,0) not null,
   cookie_id varchar2(255),
   user_id varchar2(255),
   start_date date,
   end_date date,
   referer varchar2(255),
   remote_address varchar2(255),
   remote_hostname varchar2(255),
   user_agent varchar2(255),
   bot number(1,0),
   host_id varchar2(50),
   last_page_id varchar2(50),
   first_page_id varchar2(50),
   operating_system varchar2(50),
   browser_name varchar2(50),
   browser_version varchar2(50),
   mobile_device number(1,0),
   number_of_requests number(10,0),
   primary key (clickstream_id)
);
create table web_event_location (
   inode varchar2(100) not null,
   web_event_inode varchar2(100),
   city varchar2(255),
   state varchar2(50),
   start_date date,
   end_date date,
   show_on_web number(1,0),
   web_reg_active number(1,0),
   hotel_name varchar2(255),
   hotel_link number(19,0),
   past_event_link number(19,0),
   partner_price float,
   non_partner_price float,
   short_description varchar2(255),
   text_email varchar2(1000),
   almost_at_capacity number(1,0),
   full_capacity number(1,0),
   default_contract_partner_price number(1,0),
   primary key (inode)
);
create table multi_tree (
   child varchar2(100) not null,
   parent1 varchar2(100) not null,
   parent2 varchar2(100) not null,
   relation_type varchar2(64),
   tree_order number(10,0),
   primary key (child, parent1, parent2)
);
create table tag_inode (
   inode varchar2(100) not null,
   tagname varchar2(255) not null,
   primary key (inode, tagname)
);
create table workflow_task (
   inode varchar2(100) not null,
   creation_date date,
   mod_date date,
   due_date date,
   created_by varchar2(255),
   assigned_to varchar2(255),
   belongs_to varchar2(255),
   title varchar2(255),
   description nclob,
   status varchar2(255),
   webasset varchar2(255),
   primary key (inode)
);
create table click (
   inode varchar2(100) not null,
   link varchar2(255),
   click_count number(10,0),
   primary key (inode)
);
create table event_registration (
   inode varchar2(100) not null,
   registration_date date,
   full_name varchar2(255),
   number_attending number(10,0),
   comments nclob,
   email varchar2(255),
   primary key (inode)
);
create table challenge_question (
   cquestionid number(19,0) not null,
   cqtext varchar2(255),
   primary key (cquestionid)
);
create table file_asset (
   inode varchar2(100) not null,
   file_name varchar2(255),
   file_size number(10,0),
   width number(10,0),
   height number(10,0),
   mime_type varchar2(255),
   author varchar2(255),
   publish_date date,
   live number(1,0),
   working number(1,0),
   deleted number(1,0),
   locked number(1,0),
   show_on_menu number(1,0),
   title varchar2(255),
   friendly_name varchar2(255),
   mod_date date,
   mod_user varchar2(255),
   sort_order number(10,0),
   primary key (inode)
);
create table layouts_cms_roles (
   id varchar2(255) not null,
   layout_id varchar2(100) not null,
   role_id varchar2(100) not null,
   primary key (id)
);
create table organization (
   inode varchar2(100) not null,
   title varchar2(255),
   ceo_name varchar2(255),
   partner_url varchar2(255),
   partner_key varchar2(255),
   partner_logo varchar2(100),
   street1 varchar2(255),
   street2 varchar2(255),
   city varchar2(255),
   state varchar2(255),
   zip varchar2(100),
   phone varchar2(100),
   fax varchar2(100),
   country varchar2(255),
   is_system number(1,0),
   parent_organization varchar2(100),
   primary key (inode)
);
create table facility (
   inode varchar2(100) not null,
   facility_name varchar2(255) not null,
   facility_description varchar2(255),
   sort_order number(10,0),
   active number(1,0),
   primary key (inode)
);
create table clickstream_request (
   clickstream_request_id number(19,0) not null,
   clickstream_id number(19,0),
   server_name varchar2(255),
   protocol varchar2(255),
   server_port number(10,0),
   request_uri varchar2(255),
   request_order number(10,0),
   query_string nclob,
   language_id number(19,0),
   timestampper date,
   host_id varchar2(255),
   associated_identifier varchar2(50),
   primary key (clickstream_request_id)
);
create table chain_state (
   id number(19,0) not null,
   chain_id number(19,0) not null,
   link_code_id number(19,0) not null,
   state_order number(19,0) not null,
   primary key (id)
);
create table content_rating (
   id number(19,0) not null,
   rating float,
   user_id varchar2(255),
   session_id varchar2(255),
   identifier varchar2(100),
   rating_date date,
   user_ip varchar2(255),
   long_live_cookie_id varchar2(255),
   primary key (id)
);
create table campaign (
   inode varchar2(100) not null,
   title varchar2(255),
   from_email varchar2(255),
   from_name varchar2(255),
   subject varchar2(255),
   message nclob,
   user_id varchar2(255),
   start_date date,
   completed_date date,
   active number(1,0),
   locked number(1,0),
   sends_per_hour varchar2(15),
   sendemail number(1,0),
   communicationinode varchar2(100),
   userfilterinode varchar2(100),
   sendto varchar2(15),
   isrecurrent number(1,0),
   wassent number(1,0),
   expiration_date date,
   parent_campaign varchar2(100),
   primary key (inode)
);
create table banner (
   inode varchar2(100) not null,
   title varchar2(255),
   caption nclob,
   new_window number(1,0),
   link varchar2(255),
   start_date date,
   end_date date,
   body varchar2(255),
   active number(1,0),
   nmbr_views number(10,0),
   nmbr_clicks number(10,0),
   image varchar2(100),
   path varchar2(500),
   placement varchar2(255),
   primary key (inode)
);
create table containers (
   inode varchar2(100) not null,
   code nclob,
   pre_loop nclob,
   post_loop nclob,
   live number(1,0),
   working number(1,0),
   deleted number(1,0),
   locked number(1,0),
   show_on_menu number(1,0),
   title varchar2(255),
   mod_date date,
   mod_user varchar2(100),
   sort_order number(10,0),
   friendly_name varchar2(255),
   max_contentlets number(10,0),
   use_div number(1,0),
   staticify number(1,0),
   sort_contentlets_by varchar2(255),
   lucene_query nclob,
   notes varchar2(255),
   primary key (inode)
);
create table ecom_order (
   inode varchar2(100) not null,
   user_inode varchar2(100),
   order_status number(10,0),
   payment_status number(10,0),
   date_posted date,
   last_mod_date date,
   billing_address1 varchar2(255),
   billing_address2 varchar2(255),
   billing_city varchar2(100),
   billing_state varchar2(50),
   billing_zip varchar2(50),
   billing_country varchar2(50),
   billing_phone varchar2(50),
   billing_fax varchar2(50),
   billing_first_name varchar2(100),
   billing_last_name varchar2(100),
   billing_contact_name varchar2(100),
   billing_contact_phone varchar2(50),
   billing_contact_email varchar2(100),
   shipping_address1 varchar2(255),
   shipping_address2 varchar2(255),
   shipping_city varchar2(50),
   shipping_state varchar2(50),
   shipping_zip varchar2(50),
   shipping_country varchar2(50),
   shipping_phone varchar2(50),
   shipping_fax varchar2(50),
   payment_type varchar2(10),
   name_on_card varchar2(100),
   card_type varchar2(50),
   card_number varchar2(50),
   card_exp_month number(10,0),
   card_exp_year number(10,0),
   card_verification_value varchar2(50),
   order_sub_total float,
   order_shipping float,
   order_ship_type number(10,0),
   order_tax float,
   order_discount float,
   tax_exempt_number varchar2(50),
   discount_codes varchar2(50),
   order_total float,
   order_total_paid float,
   order_total_due float,
   invoice_number varchar2(50),
   invoice_date date,
   check_number varchar2(50),
   check_bank_name varchar2(100),
   po_number varchar2(50),
   tracking_number varchar2(255),
   modified_qb number(1,0),
   modified_fh number(1,0),
   backend_user varchar2(100),
   shipping_label varchar2(50),
   primary key (inode)
);
create table web_event_attendee (
   inode varchar2(100) not null,
   event_registration_inode varchar2(100),
   first_name varchar2(255),
   last_name varchar2(255),
   badge_name varchar2(255),
   email varchar2(255),
   title varchar2(255),
   registration_price float,
   primary key (inode)
);
create table communication (
   inode varchar2(100) not null,
   title varchar2(255),
   trackback_link_inode varchar2(100),
   communication_type varchar2(255),
   from_name varchar2(255),
   from_email varchar2(255),
   email_subject varchar2(255),
   html_page_inode varchar2(100),
   text_message nclob,
   mod_date date,
   modified_by varchar2(255),
   ext_comm_id varchar2(255),
   primary key (inode)
);
create table workflow_history (
   inode varchar2(100) not null,
   creation_date date,
   made_by varchar2(255),
   change_desc nclob,
   primary key (inode)
);
create table host_variable (
   id varchar2(255) not null,
   host_id varchar2(255),
   variable_name varchar2(255),
   variable_key varchar2(255),
   variable_value varchar2(255),
   user_id varchar2(255),
   last_mod_date date,
   primary key (id)
);
create table links (
   inode varchar2(100) not null,
   live number(1,0),
   working number(1,0),
   deleted number(1,0),
   locked number(1,0),
   show_on_menu number(1,0),
   title varchar2(255),
   mod_date date,
   mod_user varchar2(100),
   sort_order number(10,0),
   friendly_name varchar2(255),
   protocal varchar2(100),
   url varchar2(255),
   target varchar2(100),
   internal_link_identifier varchar2(100),
   link_type varchar2(255),
   link_code nclob,
   primary key (inode)
);
create table event_recurrence (
   inode varchar2(100) not null,
   occurs varchar2(255),
   rec_interval number(10,0),
   rec_starting date,
   ending date,
   days_of_week varchar2(255),
   day_of_month number(10,0),
   primary key (inode)
);
create table user_proxy (
   inode varchar2(100) not null,
   user_id varchar2(255),
   prefix varchar2(255),
   suffix varchar2(255),
   title varchar2(255),
   school varchar2(255),
   how_heard varchar2(255),
   company varchar2(255),
   long_lived_cookie varchar2(255),
   website varchar2(255),
   graduation_year number(10,0),
   organization varchar2(255),
   mail_subscription number(1,0),
   var1 varchar2(255),
   var2 varchar2(255),
   var3 varchar2(255),
   var4 varchar2(255),
   var5 varchar2(255),
   var6 varchar2(255),
   var7 varchar2(255),
   var8 varchar2(255),
   var9 varchar2(255),
   var10 varchar2(255),
   var11 varchar2(255),
   var12 varchar2(255),
   var13 varchar2(255),
   var14 varchar2(255),
   var15 varchar2(255),
   var16 varchar2(255),
   var17 varchar2(255),
   var18 varchar2(255),
   var19 varchar2(255),
   var20 varchar2(255),
   var21 varchar2(255),
   var22 varchar2(255),
   var23 varchar2(255),
   var24 varchar2(255),
   var25 varchar2(255),
   last_result number(10,0),
   last_message varchar2(255),
   no_click_tracking number(1,0),
   cquestionid varchar2(255),
   cqanswer varchar2(255),
   chapter_officer varchar2(255),
   primary key (inode),
   unique (user_id)
);
create table chain_state_parameter (
   id number(19,0) not null,
   chain_state_id number(19,0) not null,
   name varchar2(255) not null,
   value varchar2(255) not null,
   primary key (id)
);
create table folder (
   inode varchar2(100) not null,
   name varchar2(255),
   path varchar2(255) not null,
   title varchar2(255) not null,
   show_on_menu number(1,0),
   sort_order number(10,0),
   host_inode varchar2(100),
   files_masks varchar2(255),
   primary key (inode)
);
create table relationship (
   inode varchar2(100) not null,
   parent_structure_inode varchar2(255),
   child_structure_inode varchar2(255),
   parent_relation_name varchar2(255),
   child_relation_name varchar2(255),
   relation_type_value varchar2(255),
   cardinality number(10,0),
   parent_required number(1,0),
   child_required number(1,0),
   fixed number(1,0),
   primary key (inode)
);
create table field (
   inode varchar2(100) not null,
   structure_inode varchar2(255),
   field_name varchar2(255),
   field_type varchar2(255),
   field_relation_type varchar2(255),
   field_contentlet varchar2(255),
   required number(1,0),
   indexed number(1,0),
   listed number(1,0),
   velocity_var_name varchar2(255),
   sort_order number(10,0),
   field_values nclob,
   regex_check varchar2(255),
   hint varchar2(255),
   default_value varchar2(255),
   fixed number(1,0),
   read_only number(1,0),
   searchable number(1,0),
   unique_ number(1,0),
   primary key (inode)
);
create table cms_layout (
   id varchar2(100) not null,
   layout_name varchar2(255) not null,
   description varchar2(255),
   tab_order number(10,0),
   primary key (id)
);
create table ecom_product_format (
   inode varchar2(100) not null,
   product_inode varchar2(100) not null,
   format_name varchar2(255) not null,
   item_num varchar2(50),
   format varchar2(100) not null,
   inventory_quantity number(10,0),
   reorder_trigger number(10,0),
   weight float,
   width number(10,0),
   height number(10,0),
   depth number(10,0),
   primary key (inode)
);
create table report_parameter (
   inode varchar2(100) not null,
   report_inode varchar2(100),
   parameter_description varchar2(1000),
   parameter_name varchar2(255),
   class_type varchar2(250),
   default_value varchar2(4000),
   primary key (inode),
   unique (report_inode, parameter_name)
);
create table chain (
   id number(19,0) not null,
   key_name varchar2(255) unique,
   name varchar2(255) not null,
   success_value varchar2(255) not null,
   failure_value varchar2(255) not null,
   primary key (id)
);
create table inode (
   inode varchar2(100) not null,
   owner varchar2(255),
   idate date,
   type varchar2(64),
   identifier varchar2(100),
   primary key (inode)
);
create table user_filter (
   inode varchar2(100) not null,
   title varchar2(255),
   firstname varchar2(100),
   middlename varchar2(100),
   lastname varchar2(100),
   emailaddress varchar2(100),
   birthdaytypesearch varchar2(100),
   birthday date,
   birthdayfrom date,
   birthdayto date,
   lastlogintypesearch varchar2(100),
   lastloginsince varchar2(100),
   loginfrom date,
   loginto date,
   createdtypesearch varchar2(100),
   createdsince varchar2(100),
   createdfrom date,
   createdto date,
   lastvisittypesearch varchar2(100),
   lastvisitsince varchar2(100),
   lastvisitfrom date,
   lastvisitto date,
   city varchar2(100),
   state varchar2(100),
   country varchar2(100),
   zip varchar2(100),
   cell varchar2(100),
   phone varchar2(100),
   fax varchar2(100),
   active_ varchar2(255),
   tagname varchar2(255),
   var1 varchar2(255),
   var2 varchar2(255),
   var3 varchar2(255),
   var4 varchar2(255),
   var5 varchar2(255),
   var6 varchar2(255),
   var7 varchar2(255),
   var8 varchar2(255),
   var9 varchar2(255),
   var10 varchar2(255),
   var11 varchar2(255),
   var12 varchar2(255),
   var13 varchar2(255),
   var14 varchar2(255),
   var15 varchar2(255),
   var16 varchar2(255),
   var17 varchar2(255),
   var18 varchar2(255),
   var19 varchar2(255),
   var20 varchar2(255),
   var21 varchar2(255),
   var22 varchar2(255),
   var23 varchar2(255),
   var24 varchar2(255),
   var25 varchar2(255),
   categories varchar2(255),
   primary key (inode)
);
alter table ecom_product_price add constraint fkf3aa85f65fb51eb foreign key (inode) references inode;
create index idx_entity_1 on entity (entity_name);
alter table entity add constraint fkb29de3e35fb51eb foreign key (inode) references inode;
create index idx_user_comments_1 on user_comments (user_id);
alter table user_comments add constraint fkdf1b37e85fb51eb foreign key (inode) references inode;
create index idx_trackback_2 on trackback (url);
create index idx_trackback_1 on trackback (asset_identifier);
create index idx_communication_user_id on recipient (user_id);
create index idx_recipiets_1 on recipient (email);
create index idx_recipiets_2 on recipient (sent);
alter table recipient add constraint fk30e172195fb51eb foreign key (inode) references inode;
create index idx_mailinglist_1 on mailing_list (user_id);
alter table mailing_list add constraint fk7bc2cd925fb51eb foreign key (inode) references inode;
create index idx_user_webform_1 on web_form (form_type);
create index idx_virtual_link_1 on virtual_link (url);
alter table virtual_link add constraint fkd844f8ae5fb51eb foreign key (inode) references inode;
create index idx_event_2 on event (end_date);
create index idx_event_1 on event (start_date);
alter table event add constraint fk5c6729a5fb51eb foreign key (inode) references inode;
create index ix_web_event on web_event (title);
create index ix_web_event_1 on web_event (sort_order);
alter table web_event add constraint fkcfabd1ef5fb51eb foreign key (inode) references inode;
alter table ecom_product add constraint fk24a022ac5fb51eb foreign key (inode) references inode;
alter table template add constraint fkb13acc7a5fb51eb foreign key (inode) references inode;
create index ix_ecom_order_item on ecom_order_item (order_inode);
alter table ecom_order_item add constraint fkebb882875fb51eb foreign key (inode) references inode;
alter table structure add constraint fk89d2d735fb51eb foreign key (inode) references inode;
create index uk_discount_code_id on ecom_discount_code (code_id);
alter table ecom_discount_code add constraint fk994566285fb51eb foreign key (inode) references inode;
create index ix_web_event_registration_3 on web_event_registration (date_posted);
create index ix_web_event_registration_2 on web_event_registration (user_inode);
create index ix_web_event_registration_1 on web_event_registration (event_location_inode);
create index ix_web_event_registration on web_event_registration (event_inode);
alter table web_event_registration add constraint fk60025d095fb51eb foreign key (inode) references inode;
create index idx_permission_2 on permission (permission_type, inode_id);
create index idx_permission_3 on permission (roleid);
alter table recurance add constraint fk457445fc5fb51eb foreign key (inode) references inode;
alter table contentlet add constraint fkfc4ef025fb51eb foreign key (inode) references inode;
alter table workflow_comment add constraint fk94993ddf5fb51eb foreign key (inode) references inode;
alter table report_asset add constraint fk3765ec255fb51eb foreign key (inode) references inode;
create index idx_category_1 on category (category_name);
create index idx_category_2 on category (category_key);
alter table category add constraint fk302bcfe5fb51eb foreign key (inode) references inode;
alter table htmlpage add constraint fkebf39cba5fb51eb foreign key (inode) references inode;
create index idx_preference_1 on user_preferences (preference);
alter table identifier add constraint fk9f88aca95fb51eb foreign key (inode) references inode;
create index idx_user_clickstream11 on clickstream (host_id);
create index idx_user_clickstream12 on clickstream (last_page_id);
create index idx_user_clickstream15 on clickstream (browser_name);
create index idx_user_clickstream_2 on clickstream (user_id);
create index idx_user_clickstream16 on clickstream (browser_version);
create index idx_user_clickstream_1 on clickstream (cookie_id);
create index idx_user_clickstream13 on clickstream (first_page_id);
create index idx_user_clickstream14 on clickstream (operating_system);
create index ix_web_event_location_1 on web_event_location (state);
create index ix_web_event_location on web_event_location (city);
create index ix_web_event_location_3 on web_event_location (end_date);
create index ix_web_event_location_2 on web_event_location (start_date);
alter table web_event_location add constraint fk1d54bc055fb51eb foreign key (inode) references inode;
create index idx_multitree_1 on multi_tree (relation_type);
create index idx_workflow_4 on workflow_task (webasset);
create index idx_workflow_5 on workflow_task (created_by);
create index idx_workflow_2 on workflow_task (belongs_to);
create index idx_workflow_3 on workflow_task (status);
create index idx_workflow_1 on workflow_task (assigned_to);
alter table workflow_task add constraint fk441116055fb51eb foreign key (inode) references inode;
create index idx_click_1 on click (link);
alter table click add constraint fk5a5c5885fb51eb foreign key (inode) references inode;
alter table event_registration add constraint fke1516a3e5fb51eb foreign key (inode) references inode;
create index idx_file_1 on file_asset (mod_user);
alter table file_asset add constraint fk7ed2366d5fb51eb foreign key (inode) references inode;
alter table organization add constraint fk4644ed335fb51eb foreign key (inode) references inode;
alter table facility add constraint fk1dde6ea35fb51eb foreign key (inode) references inode;
create index idx_user_clickstream_request_2 on clickstream_request (request_uri);
create index idx_user_clickstream_request_1 on clickstream_request (clickstream_id);
create index idx_user_clickstream_request_3 on clickstream_request (associated_identifier);
create index idx_campaign_4 on campaign (expiration_date);
create index idx_campaign_3 on campaign (completed_date);
create index idx_campaign_2 on campaign (start_date);
create index idx_campaign_1 on campaign (user_id);
alter table campaign add constraint fkf7a901105fb51eb foreign key (inode) references inode;
alter table banner add constraint fkacc57f2c5fb51eb foreign key (inode) references inode;
alter table containers add constraint fk8a844125fb51eb foreign key (inode) references inode;
alter table ecom_order add constraint fkf088284b5fb51eb foreign key (inode) references inode;
create index ix_web_event_attendee on web_event_attendee (event_registration_inode);
create index ix_web_event_attendee_1 on web_event_attendee (first_name);
create index ix_web_event_attendee_2 on web_event_attendee (last_name);
alter table web_event_attendee add constraint fkcc5ee90a5fb51eb foreign key (inode) references inode;
alter table communication add constraint fkc24acfd65fb51eb foreign key (inode) references inode;
alter table workflow_history add constraint fk933334145fb51eb foreign key (inode) references inode;
alter table links add constraint fk6234fb95fb51eb foreign key (inode) references inode;
alter table event_recurrence add constraint fk29da39f55fb51eb foreign key (inode) references inode;
alter table user_proxy add constraint fk7327d4fa5fb51eb foreign key (inode) references inode;
create index idx_folder_1 on folder (name);
alter table folder add constraint fkb45d1c6e5fb51eb foreign key (inode) references inode;
create index idx_relationship_1 on relationship (parent_structure_inode);
create index idx_relationship_2 on relationship (child_structure_inode);
alter table relationship add constraint fkf06476385fb51eb foreign key (inode) references inode;
create index idx_field_1 on field (structure_inode);
alter table field add constraint fk5cea0fa5fb51eb foreign key (inode) references inode;
alter table ecom_product_format add constraint fk706fb8ea5fb51eb foreign key (inode) references inode;
alter table report_parameter add constraint fk22da125e5fb51eb foreign key (inode) references inode;
create index idx_index_2 on inode (identifier);
create index idx_index_1 on inode (type);
alter table user_filter add constraint fke042126c5fb51eb foreign key (inode) references inode;
create sequence user_preferences_seq;
create sequence chain_state_seq;
create sequence trackback_sequence;
create sequence language_seq;
create sequence permission_reference_seq;
create sequence chain_link_code_seq;
create sequence clickstream_seq;
create sequence content_rating_sequence;
create sequence chain_seq;
create sequence clickstream_request_seq;
create sequence user_to_delete_seq;
create sequence chain_state_parameter_seq;
create sequence permission_seq;
--oracle
CREATE INDEX idx_tree_1 ON tree (parent);
CREATE INDEX idx_tree_2 ON tree (child);
CREATE INDEX idx_tree_3 ON tree (relation_type);
CREATE INDEX idx_tree_4 ON tree (parent, child, relation_type);
CREATE INDEX idx_tree_5 ON tree (parent, relation_type);
CREATE INDEX idx_tree_6 ON tree (child, relation_type);
CREATE INDEX idx_contentlet_1 ON contentlet (inode, live);
CREATE INDEX idx_contentlet_2 ON contentlet (inode, working);



CREATE INDEX idx_permisision_4 ON permission (permission_type);


CREATE INDEX idx_permission_reference_2 ON permission_reference (reference_id);
CREATE INDEX idx_permission_reference_3 ON permission_reference (reference_id,permission_type);
CREATE INDEX idx_permission_reference_4 ON permission_reference (asset_id,permission_type);
CREATE INDEX idx_permission_reference_5 ON permission_reference (asset_id,reference_id,permission_type);
CREATE INDEX idx_permission_reference_6 ON permission_reference (permission_type);

CREATE UNIQUE INDEX idx_field_velocity_structure ON field (velocity_var_name,structure_inode); 

alter table tree add constraint FK36739EC4AB08AA foreign key (parent) references inode;
alter table tree add constraint FK36739E5A3F51C foreign key (child) references inode;

alter table chain_state add constraint fk_state_chain foreign key (chain_id) references chain(id);
alter table chain_state add constraint fk_state_code foreign key (link_code_id) references chain_link_code(id);
alter table chain_state_parameter add constraint fk_parameter_state foreign key (chain_state_id) references chain_state(id);

alter table permission add constraint permission_inode_fk foreign key (inode_id) references inode(inode);
alter table permission add constraint permission_role_fk foreign key (roleid) references cms_role(id);

alter table permission_reference add constraint permission_asset_id_fk foreign key (asset_id) references inode(inode);
alter table permission_reference add constraint permission_reference_id_fk foreign key (reference_id) references inode(inode);

alter table contentlet add constraint FK_structure_inode foreign key (structure_inode) references structure(inode);

ALTER TABLE structure MODIFY fixed DEFAULT 0;

ALTER TABLE field MODIFY fixed DEFAULT 0;
ALTER TABLE field MODIFY read_only DEFAULT 0;

ALTER TABLE campaign MODIFY active DEFAULT 0;

insert into User_ (userId, companyId, createDate, password_, passwordEncrypted, passwordReset, firstName, middleName, lastName, male, birthday, emailAddress, skinId, dottedSkins, roundedSkins, greeting, layoutIds, loginDate, failedLoginAttempts, agreedToTermsOfUse, active_) values ('dotcms.org.default', 'default', sysdate, 'password', '0', '0', '', '', '', '1', to_date('1970-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS'), 'default@dotcms.org', '01', '0', '0', 'Welcome!', '', sysdate, 0, '0', '1');

create index addres_userid_index on address(userid);
create index tag_user_id_index on tag(user_id);
create index tag_inode_tagname on tag_inode(tagname);
create index tag_inode_inode on tag_inode(inode);
CREATE TABLE "DIST_JOURNAL" ( "ID" INTEGER NOT NULL ,
"OBJECT_TO_INDEX" VARCHAR2(255), "SERVERID" VARCHAR2(64),
"JOURNAL_TYPE" INTEGER, "TIME_ENTERED" TIMESTAMP, PRIMARY KEY ("ID")
VALIDATE , UNIQUE ("OBJECT_TO_INDEX", "SERVERID", "JOURNAL_TYPE")
VALIDATE );
CREATE SEQUENCE dist_journal_id_seq
START WITH 1
INCREMENT BY 1;
create trigger DIST_JOURNAL_trg
before insert on DIST_JOURNAL
for each row
when (new.id is null)
begin
    select dist_journal_id_seq.nextval into :new.id from dual;
end;
/

CREATE TABLE dist_process ( ID INTEGER NOT NULL , OBJECT_TO_INDEX VARCHAR2(255), SERVERID VARCHAR2(64), JOURNAL_TYPE INTEGER, TIME_ENTERED TIMESTAMP, PRIMARY KEY (ID) VALIDATE ); 
CREATE SEQUENCE dist_process_id_seq START WITH 1 INCREMENT BY 1;
create trigger dist_process_trg
before insert on dist_process 
for each row 
when (new.id is null) 
begin 
select dist_process_id_seq.nextval into :new.id from dual;
end;
/

CREATE INDEX dist_process_index on dist_process (object_to_index, serverid,journal_type);


CREATE TABLE dist_reindex_journal ( ID INTEGER NOT NULL , INODE_TO_INDEX varchar2(100),IDENT_TO_INDEX varchar2(100), SERVERID VARCHAR2(64), priority INTEGER, TIME_ENTERED TIMESTAMP DEFAULT CURRENT_TIMESTAMP, index_val varchar2(325) ,dist_action INTEGER DEFAULT 1 NOT NULL, PRIMARY KEY (ID) VALIDATE);
		
CREATE INDEX dist_reindex_index1 on dist_reindex_journal (inode_to_index);
CREATE INDEX dist_reindex_index2 on dist_reindex_journal (dist_action);
CREATE INDEX dist_reindex_index3 on dist_reindex_journal (serverid);
CREATE INDEX dist_reindex_index on dist_reindex_journal (serverid,dist_action);

CREATE SEQUENCE dist_reindex_id_seq START WITH 1 INCREMENT BY 1;
		
create trigger dist_reindex_journal_trg
		before insert on dist_reindex_journal
		for each row
		when (new.id is null)
		begin
		select dist_reindex_id_seq.nextval into :new.id from dual;
		end;
/
		

CREATE TABLE quartz_log ( ID INTEGER NOT NULL , JOB_NAME VARCHAR2(255), SERVERID VARCHAR2(64),  TIME_STARTED TIMESTAMP, PRIMARY KEY (ID) VALIDATE ); 

create table plugin_property (
   plugin_id varchar2(255) not null,
   propkey varchar2(255) not null,
   original_value varchar2(255) not null,
   current_value varchar2(255) not null,
   primary key (plugin_id, propkey)
);

alter table plugin_property add constraint fk_plugin_plugin_property foreign key (plugin_id) references plugin(id);

CREATE SEQUENCE quartz_log_id_seq START WITH 1 INCREMENT BY 1;
create trigger quartz_log_trg
before insert on quartz_log 
for each row 
when (new.id is null) 
begin 
select quartz_log_id_seq.nextval into :new.id from dual;
end;
/

CREATE OR REPLACE TRIGGER check_identifier_host_inode
BEFORE INSERT OR UPDATE ON identifier
FOR EACH ROW
DECLARE
BEGIN
    dbms_output.put_line('uri: ' || SUBSTR(:new.uri,0,7));
    dbms_output.put_line('host_inode: ' || :new.host_inode);
    IF SUBSTR(:new.uri,0,7) <> 'content' AND (:new.host_inode is NULL OR :new.host_inode = '') THEN
    	RAISE_APPLICATION_ERROR(-20000, 'Cannot insert/update a null or empty host inode for this kind of identifier');
    END IF;
END;
/

ALTER TABLE cms_role ADD CONSTRAINT cms_role2_unique UNIQUE (role_key);
ALTER TABLE cms_role ADD CONSTRAINT cms_role3_unique UNIQUE (db_fqn);
alter table cms_role add constraint fkcms_role_parent foreign key (parent) references cms_role;

ALTER TABLE cms_layout ADD CONSTRAINT cms_layout_unique_1 UNIQUE (layout_name);

ALTER TABLE portlet ADD CONSTRAINT portlet_unique_1 UNIQUE (portletid);
ALTER TABLE cms_layouts_portlets ADD CONSTRAINT cms_layouts_portlets_unq_1 UNIQUE (portlet_id, layout_id);
alter table cms_layouts_portlets add constraint fkcms_layouts_portlets foreign key (layout_id) references cms_layout;

ALTER TABLE users_cms_roles ADD CONSTRAINT users_cms_roles1_unique UNIQUE (role_id, user_id);
alter table users_cms_roles add constraint fkusers_cms_roles1 foreign key (role_id) references cms_role;
alter table users_cms_roles add constraint fkusers_cms_roles2 foreign key (user_id) references user_;
		
ALTER TABLE layouts_cms_roles ADD CONSTRAINT layouts_cms_roles1_unique UNIQUE (role_id, layout_id);		
alter table layouts_cms_roles add constraint fklayouts_cms_roles1 foreign key (role_id) references cms_role;
alter table layouts_cms_roles add constraint fklayouts_cms_roles2 foreign key (layout_id) references cms_layout;

alter table contentlet add constraint fk_folder foreign key (folder) references folder(inode);


create table import_audit ( 
	id integer not null,
	start_date timestamp,
	userid varchar(255), 
	filename varchar(512), 
	status integer,
	last_inode varchar(100), 
	records_to_import integer,
	serverid varchar(255),
	primary key (id)
	);

alter table category modify (category_velocity_var_name varchar2(255) not null);
