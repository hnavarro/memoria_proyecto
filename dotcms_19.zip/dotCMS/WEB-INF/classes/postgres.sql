
create table ABContact (
	contactId varchar(100) not null primary key,
	userId varchar(100) not null,
	firstName varchar(100) null,
	middleName varchar(100) null,
	lastName varchar(100) null,
	nickName varchar(100) null,
	emailAddress varchar(100) null,
	homeStreet varchar(100) null,
	homeCity varchar(100) null,
	homeState varchar(100) null,
	homeZip varchar(100) null,
	homeCountry varchar(100) null,
	homePhone varchar(100) null,
	homeFax varchar(100) null,
	homeCell varchar(100) null,
	homePager varchar(100) null,
	homeTollFree varchar(100) null,
	homeEmailAddress varchar(100) null,
	businessCompany varchar(100) null,
	businessStreet varchar(100) null,
	businessCity varchar(100) null,
	businessState varchar(100) null,
	businessZip varchar(100) null,
	businessCountry varchar(100) null,
	businessPhone varchar(100) null,
	businessFax varchar(100) null,
	businessCell varchar(100) null,
	businessPager varchar(100) null,
	businessTollFree varchar(100) null,
	businessEmailAddress varchar(100) null,
	employeeNumber varchar(100) null,
	jobTitle varchar(100) null,
	jobClass varchar(100) null,
	hoursOfOperation text null,
	birthday timestamp null,
	timeZoneId varchar(100) null,
	instantMessenger varchar(100) null,
	website varchar(100) null,
	comments text null
);

create table ABContacts_ABLists (
	contactId varchar(100) not null,
	listId varchar(100) not null
);

create table ABList (
	listId varchar(100) not null primary key,
	userId varchar(100) not null,
	name varchar(100) null
);

create table Address (
	addressId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate timestamp null,
	modifiedDate timestamp null,
	className varchar(100) null,
	classPK varchar(100) null,
	description varchar(100) null,
	street1 varchar(100) null,
	street2 varchar(100) null,
	city varchar(100) null,
	state varchar(100) null,
	zip varchar(100) null,
	country varchar(100) null,
	phone varchar(100) null,
	fax varchar(100) null,
	cell varchar(100) null,
	priority integer
);

create table AdminConfig (
	configId varchar(100) not null primary key,
	companyId varchar(100) not null,
	type_ varchar(100) null,
	name varchar(100) null,
	config text null
);

create table BJEntries_BJTopics (
	entryId varchar(100) not null,
	topicId varchar(100) not null
);

create table BJEntries_BJVerses (
	entryId varchar(100) not null,
	verseId varchar(100) not null
);

create table BJEntry (
	entryId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate timestamp null,
	modifiedDate timestamp null,
	name varchar(100) null,
	content text null,
	versesInput text null
);

create table BJTopic (
	topicId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate timestamp null,
	modifiedDate timestamp null,
	name varchar(100) null,
	description text null
);

create table BJVerse (
	verseId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	name varchar(100) null
);

create table BlogsCategory (
	categoryId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate timestamp null,
	modifiedDate timestamp null,
	name varchar(100) null
);

create table BlogsComments (
	commentsId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate timestamp null,
	modifiedDate timestamp null,
	entryId varchar(100) null,
	content text null
);

create table BlogsEntry (
	entryId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate timestamp null,
	modifiedDate timestamp null,
	categoryId varchar(100) null,
	title varchar(100) null,
	content text null,
	displayDate timestamp null,
	sharing bool,
	commentable bool,
	propsCount integer,
	commentsCount integer
);

create table BlogsLink (
	linkId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate timestamp null,
	modifiedDate timestamp null,
	name varchar(100) null,
	url varchar(100) null
);

create table BlogsProps (
	propsId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate timestamp null,
	modifiedDate timestamp null,
	entryId varchar(100) null,
	quantity integer
);

create table BlogsReferer (
	entryId varchar(100) not null,
	url varchar(100) not null,
	type_ varchar(100) not null,
	quantity integer,
	primary key (entryId, url, type_)
);

create table BlogsUser (
	userId varchar(100) not null primary key,
	companyId varchar(100) not null,
	entryId varchar(100) not null,
	lastPostDate timestamp null
);

create table BookmarksEntry (
	entryId varchar(100) not null primary key,
	userId varchar(100) not null,
	createDate timestamp null,
	modifiedDate timestamp null,
	folderId varchar(100) null,
	name varchar(100) null,
	url varchar(100) null,
	comments text null,
	visits integer
);

create table BookmarksFolder (
	folderId varchar(100) not null primary key,
	userId varchar(100) not null,
	createDate timestamp null,
	modifiedDate timestamp null,
	parentFolderId varchar(100) null,
	name varchar(100) null
);

create table CalEvent (
	eventId varchar(100) not null primary key,
	groupId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate timestamp null,
	modifiedDate timestamp null,
	title varchar(100) null,
	description text null,
	startDate timestamp null,
	endDate timestamp null,
	durationHour integer,
	durationMinute integer,
	allDay bool,
	timeZoneSensitive bool,
	type_ varchar(100) null,
	location varchar(100) null,
	street varchar(100) null,
	city varchar(100) null,
	state varchar(100) null,
	zip varchar(100) null,
	phone varchar(100) null,
	repeating bool,
	recurrence text null,
	remindBy varchar(100) null,
	firstReminder integer,
	secondReminder integer
);

create table CalTask (
	taskId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate timestamp null,
	modifiedDate timestamp null,
	title varchar(100) null,
	description text null,
	noDueDate bool,
	dueDate timestamp null,
	priority integer,
	status integer
);

create table Company (
	companyId varchar(100) not null primary key,
	key_ text null,
	portalURL varchar(100) not null,
	homeURL varchar(100) not null,
	mx varchar(100) not null,
	name varchar(100) not null,
	shortName varchar(100) not null,
	type_ varchar(100) null,
	size_ varchar(100) null,
	street varchar(100) null,
	city varchar(100) null,
	state varchar(100) null,
	zip varchar(100) null,
	phone varchar(100) null,
	fax varchar(100) null,
	emailAddress varchar(100) null,
	authType varchar(100) null,
	autoLogin bool,
	strangers bool
);

create table Counter (
	name varchar(100) not null primary key,
	currentId integer
);

create table CyrusUser (
	userId varchar(100) not null primary key,
	password_ varchar(100) not null
);

create table CyrusVirtual (
	emailAddress varchar(100) not null primary key,
	userId varchar(100) not null
);

create table DLFileProfile (
	companyId varchar(100) not null,
	repositoryId varchar(100) not null,
	fileName varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	versionUserId varchar(100) not null,
	versionUserName varchar(100) null,
	createDate timestamp null,
	modifiedDate timestamp null,
	readRoles varchar(100) null,
	writeRoles varchar(100) null,
	description text null,
	version double precision,
	size_ integer,
	primary key (companyId, repositoryId, fileName)
);

create table DLFileRank (
	companyId varchar(100) not null,
	userId varchar(100) not null,
	repositoryId varchar(100) not null,
	fileName varchar(100) not null,
	createDate timestamp null,
	primary key (companyId, userId, repositoryId, fileName)
);

create table DLFileVersion (
	companyId varchar(100) not null,
	repositoryId varchar(100) not null,
	fileName varchar(100) not null,
	version double precision not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate timestamp null,
	size_ integer,
	primary key (companyId, repositoryId, fileName, version)
);

create table DLRepository (
	repositoryId varchar(100) not null primary key,
	groupId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate timestamp null,
	modifiedDate timestamp null,
	readRoles varchar(100) null,
	writeRoles varchar(100) null,
	name varchar(100) null,
	description text null,
	lastPostDate timestamp null
);

create table IGFolder (
	folderId varchar(100) not null primary key,
	groupId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate timestamp null,
	modifiedDate timestamp null,
	parentFolderId varchar(100) null,
	name varchar(100) null
);

create table IGImage (
	imageId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate timestamp null,
	modifiedDate timestamp null,
	folderId varchar(100) null,
	description text null,
	height integer,
	width integer,
	size_ integer,
	primary key (imageId, companyId)
);

create table Image (
	imageId varchar(200) not null primary key,
	text_ text not null
);

create table JournalArticle (
	articleId varchar(100) not null,
	version double precision not null,
	portletId varchar(100) not null,
	groupId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate timestamp null,
	modifiedDate timestamp null,
	title varchar(100) null,
	content text null,
	type_ varchar(100) null,
	structureId varchar(100) null,
	templateId varchar(100) null,
	displayDate timestamp null,
	expirationDate timestamp null,
	approved bool,
	approvedByUserId varchar(100) null,
	approvedByUserName varchar(100) null,
	primary key (articleId, version)
);

create table JournalStructure (
	structureId varchar(100) not null primary key,
	portletId varchar(100) not null,
	groupId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate timestamp null,
	modifiedDate timestamp null,
	name varchar(100) null,
	description text null,
	xsd text null
);

create table JournalTemplate (
	templateId varchar(100) not null primary key,
	portletId varchar(100) not null,
	groupId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate timestamp null,
	modifiedDate timestamp null,
	structureId varchar(100) null,
	name varchar(100) null,
	description text null,
	xsl text null,
	smallImage bool,
	smallImageURL varchar(100) null
);

create table Layer (
	layerId varchar(100) not null,
	skinId varchar(100) not null,
	href varchar(100) null,
	hrefHover varchar(100) null,
	background varchar(100) null,
	foreground varchar(100) null,
	negAlert varchar(100) null,
	posAlert varchar(100) null,
	primary key (layerId, skinId)
);

create table MailReceipt (
	receiptId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate timestamp null,
	modifiedDate timestamp null,
	recipientName varchar(100) null,
	recipientAddress varchar(100) null,
	subject varchar(100) null,
	sentDate timestamp null,
	readCount integer,
	firstReadDate timestamp null,
	lastReadDate timestamp null
);

create table MBMessage (
	messageId varchar(100) not null,
	topicId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate timestamp null,
	modifiedDate timestamp null,
	threadId varchar(100) null,
	parentMessageId varchar(100) null,
	subject varchar(100) null,
	body text null,
	attachments bool,
	anonymous bool,
	primary key (messageId, topicId)
);

create table MBMessageFlag (
	topicId varchar(100) not null,
	messageId varchar(100) not null,
	userId varchar(100) not null,
	flag varchar(100) null,
	primary key (topicId, messageId, userId)
);

create table MBThread (
	threadId varchar(100) not null primary key,
	rootMessageId varchar(100) null,
	topicId varchar(100) null,
	messageCount integer,
	lastPostDate timestamp null
);

create table MBTopic (
	topicId varchar(100) not null primary key,
	portletId varchar(100) not null,
	groupId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate timestamp null,
	modifiedDate timestamp null,
	readRoles varchar(100) null,
	writeRoles varchar(100) null,
	name varchar(100) null,
	description text null,
	lastPostDate timestamp null
);

create table NetworkAddress (
	addressId varchar(100) not null primary key,
	userId varchar(100) not null,
	createDate timestamp null,
	modifiedDate timestamp null,
	name varchar(100) null,
	url varchar(100) null,
	comments text null,
	content text null,
	status integer,
	lastUpdated timestamp null,
	notifyBy varchar(100) null,
	interval_ integer,
	active_ bool
);

create table Note (
	noteId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate timestamp null,
	modifiedDate timestamp null,
	className varchar(100) null,
	classPK varchar(100) null,
	content text null
);

create table PasswordTracker (
	passwordTrackerId varchar(100) not null primary key,
	userId varchar(100) not null,
	createDate timestamp not null,
	password_ varchar(100) not null
);

create table PollsChoice (
	choiceId varchar(100) not null,
	questionId varchar(100) not null,
	description text null,
	primary key (choiceId, questionId)
);

create table PollsDisplay (
	layoutId varchar(100) not null,
	userId varchar(100) not null,
	portletId varchar(100) not null,
	questionId varchar(100) not null,
	primary key (layoutId, userId, portletId)
);

create table PollsQuestion (
	questionId varchar(100) not null primary key,
	portletId varchar(100) not null,
	groupId varchar(100) not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate timestamp null,
	modifiedDate timestamp null,
	title varchar(100) null,
	description text null,
	expirationDate timestamp null,
	lastVoteDate timestamp null
);

create table PollsVote (
	questionId varchar(100) not null,
	userId varchar(100) not null,
	choiceId varchar(100) not null,
	voteDate timestamp null,
	primary key (questionId, userId)
);

create table Portlet (
	portletId varchar(100) not null,
	groupId varchar(100) not null,
	companyId varchar(100) not null,
	defaultPreferences text null,
	narrow bool,
	roles text null,
	active_ bool,
	primary key (portletId, groupId, companyId)
);

create table PortletPreferences (
	portletId varchar(100) not null,
	userId varchar(100) not null,
	layoutId varchar(100) not null,
	preferences text null,
	primary key (portletId, userId, layoutId)
);

create table ProjFirm (
	firmId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate timestamp null,
	modifiedDate timestamp null,
	name varchar(100) null,
	description text null,
	url varchar(100) null
);

create table ProjProject (
	projectId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate timestamp null,
	modifiedDate timestamp null,
	firmId varchar(100) null,
	code varchar(100) null,
	name varchar(100) null,
	description text null
);

create table ProjTask (
	taskId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate timestamp null,
	modifiedDate timestamp null,
	projectId varchar(100) null,
	name varchar(100) null,
	description text null,
	comments text null,
	estimatedDuration integer,
	estimatedEndDate timestamp null,
	actualDuration integer,
	actualEndDate timestamp null,
	status integer
);

create table ProjTime (
	timeId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate timestamp null,
	modifiedDate timestamp null,
	projectId varchar(100) null,
	taskId varchar(100) null,
	description text null,
	startDate timestamp null,
	endDate timestamp null
);

create table Release_ (
	releaseId varchar(100) not null primary key,
	createDate timestamp null,
	modifiedDate timestamp null,
	buildNumber integer null,
	buildDate timestamp null
);

create table Skin (
	skinId varchar(100) not null primary key,
	name varchar(100) null,
	imageId varchar(100) null,
	alphaLayerId varchar(100) null,
	alphaSkinId varchar(100) null,
	betaLayerId varchar(100) null,
	betaSkinId varchar(100) null,
	gammaLayerId varchar(100) null,
	gammaSkinId varchar(100) null,
	bgLayerId varchar(100) null,
	bgSkinId varchar(100) null
);

create table ShoppingCart (
	cartId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate timestamp null,
	modifiedDate timestamp null,
	itemIds text null,
	couponIds text null,
	altShipping integer
);

create table ShoppingCategory (
	categoryId varchar(100) not null primary key,
	companyId varchar(100) not null,
	createDate timestamp null,
	modifiedDate timestamp null,
	parentCategoryId varchar(100) null,
	name varchar(100) null
);

create table ShoppingCoupon (
	couponId varchar(100) not null primary key,
	companyId varchar(100) not null,
	createDate timestamp null,
	modifiedDate timestamp null,
	name varchar(100) null,
	description text null,
	startDate timestamp null,
	endDate timestamp null,
	active_ bool,
	limitCategories text null,
	limitSkus text null,
	minOrder double precision,
	discount double precision,
	discountType varchar(100) null
);

create table ShoppingItem (
	itemId varchar(100) not null primary key,
	companyId varchar(100) not null,
	createDate timestamp null,
	modifiedDate timestamp null,
	categoryId varchar(100) null,
	sku varchar(100) null,
	name varchar(100) null,
	description text null,
	properties text null,
	supplierUserId varchar(100) null,
	fields_ bool,
	fieldsQuantities text null,
	minQuantity integer,
	maxQuantity integer,
	price double precision,
	discount double precision,
	taxable bool,
	shipping double precision,
	useShippingFormula bool,
	requiresShipping bool,
	stockQuantity integer,
	featured_ bool,
	sale_ bool,
	smallImage bool,
	smallImageURL varchar(100) null,
	mediumImage bool,
	mediumImageURL varchar(100) null,
	largeImage bool,
	largeImageURL varchar(100) null
);

create table ShoppingItemField (
	itemFieldId varchar(100) not null primary key,
	itemId varchar(100) null,
	name varchar(100) null,
	values_ text null,
	description text null
);

create table ShoppingItemPrice (
	itemPriceId varchar(100) not null primary key,
	itemId varchar(100) null,
	minQuantity integer,
	maxQuantity integer,
	price double precision,
	discount double precision,
	taxable bool,
	shipping double precision,
	useShippingFormula bool,
	status integer
);

create table ShoppingOrder (
	orderId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	createDate timestamp null,
	modifiedDate timestamp null,
	tax double precision,
	shipping double precision,
	altShipping varchar(100),
	requiresShipping bool,
	couponIds text null,
	couponDiscount double precision,
	billingFirstName varchar(100) null,
	billingLastName varchar(100) null,
	billingEmailAddress varchar(100) null,
	billingCompany varchar(100) null,
	billingStreet varchar(100) null,
	billingCity varchar(100) null,
	billingState varchar(100) null,
	billingZip varchar(100) null,
	billingCountry varchar(100) null,
	billingPhone varchar(100) null,
	shipToBilling bool,
	shippingFirstName varchar(100) null,
	shippingLastName varchar(100) null,
	shippingEmailAddress varchar(100) null,
	shippingCompany varchar(100) null,
	shippingStreet varchar(100) null,
	shippingCity varchar(100) null,
	shippingState varchar(100) null,
	shippingZip varchar(100) null,
	shippingCountry varchar(100) null,
	shippingPhone varchar(100) null,
	ccName varchar(100) null,
	ccType varchar(100) null,
	ccNumber varchar(100) null,
	ccExpMonth integer,
	ccExpYear integer,
	ccVerNumber varchar(100) null,
	comments text null,
	ppTxnId varchar(100) null,
	ppPaymentStatus varchar(100) null,
	ppPaymentGross double precision,
	ppReceiverEmail varchar(100) null,
	ppPayerEmail varchar(100) null,
	sendOrderEmail bool,
	sendShippingEmail bool
);

create table ShoppingOrderItem (
	orderId varchar(100) not null,
	itemId varchar(100) not null,
	sku varchar(100) null,
	name varchar(100) null,
	description text null,
	properties text null,
	supplierUserId varchar(100) null,
	price double precision,
	quantity integer,
	shippedDate timestamp null,
	primary key (orderId, itemId)
);

create table User_ (
	userId varchar(100) not null primary key,
	companyId varchar(100) not null,
	createDate timestamp null,
	password_ varchar(100) null,
	passwordEncrypted bool,
	passwordExpirationDate timestamp null,
	passwordReset bool,
	firstName varchar(100) null,
	middleName varchar(100) null,
	lastName varchar(100) null,
	nickName varchar(100) null,
	male bool,
	birthday timestamp null,
	emailAddress varchar(100) null,
	smsId varchar(100) null,
	aimId varchar(100) null,
	icqId varchar(100) null,
	msnId varchar(100) null,
	ymId varchar(100) null,
	favoriteActivity varchar(100) null,
	favoriteBibleVerse varchar(100) null,
	favoriteFood varchar(100) null,
	favoriteMovie varchar(100) null,
	favoriteMusic varchar(100) null,
	languageId varchar(100) null,
	timeZoneId varchar(100) null,
	skinId varchar(100) null,
	dottedSkins bool,
	roundedSkins bool,
	greeting varchar(100) null,
	resolution varchar(100) null,
	refreshRate varchar(100) null,
	layoutIds varchar(100) null,
	comments text null,
	loginDate timestamp null,
	loginIP varchar(100) null,
	lastLoginDate timestamp null,
	lastLoginIP varchar(100) null,
	failedLoginAttempts integer,
	agreedToTermsOfUse bool,
	active_ bool
);

create table Users_ProjProjects (
	userId varchar(100) not null,
	projectId varchar(100) not null
);

create table Users_ProjTasks (
	userId varchar(100) not null,
	taskId varchar(100) not null
);

create table UserTracker (
	userTrackerId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	modifiedDate timestamp null,
	remoteAddr varchar(100) null,
	remoteHost varchar(100) null,
	userAgent varchar(100) null
);

create table UserTrackerPath (
	userTrackerPathId varchar(100) not null primary key,
	userTrackerId varchar(100) not null,
	path text not null,
	pathDate timestamp not null
);

create table WikiDisplay (
	layoutId varchar(100) not null,
	userId varchar(100) not null,
	portletId varchar(100) not null,
	nodeId varchar(100) not null,
	showBorders bool,
	primary key (layoutId, userId, portletId)
);

create table WikiNode (
	nodeId varchar(100) not null primary key,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate timestamp null,
	modifiedDate timestamp null,
	readRoles varchar(100) null,
	writeRoles varchar(100) null,
	name varchar(100) null,
	description text null,
	sharing bool,
	lastPostDate timestamp null
);

create table WikiPage (
	nodeId varchar(100) not null,
	title varchar(100) not null,
	version double precision not null,
	companyId varchar(100) not null,
	userId varchar(100) not null,
	userName varchar(100) null,
	createDate timestamp null,
	content text null,
	format varchar(100) null,
	head bool,
	primary key (nodeId, title, version)
);

--
-- Global
--

insert into Counter values ('com.liferay.portal.model.Address', 10);
insert into Counter values ('com.liferay.portal.model.Group', 20);
insert into Counter values ('com.liferay.portal.model.Role', 100);
insert into Counter values ('com.liferay.portal.model.User.liferay.com', 10);
insert into Counter values ('com.liferay.portlet.imagegallery.model.IGFolder', 20);
insert into Counter values ('com.liferay.portlet.imagegallery.model.IGImage.liferay.com', 42);
insert into Counter values ('com.liferay.portlet.polls.model.PollsQuestion', 10);
insert into Counter values ('com.liferay.portlet.shopping.model.ShoppingCategory', 20);
insert into Counter values ('com.liferay.portlet.shopping.ejb.ShoppingItem', 40);
insert into Counter values ('com.liferay.portlet.wiki.model.WikiNode', 10);

--
-- Liferay, LLC
--

insert into Company (companyId, portalURL, homeURL, mx, name, shortName, type_, size_, emailAddress, authType, autoLogin, strangers) values ('liferay.com', 'localhost', 'localhost', 'liferay.com', 'Liferay, LLC', 'Liferay', 'biz', '', 'test@liferay.com', 'emailAddress', 't', 't');
update Company set street = '1220 Brea Canyon Rd.', city = 'Diamond Bar', state = 'CA', zip = '91789' where companyId = 'liferay.com';

insert into PollsDisplay (layoutId, userId, portletId, questionId) values ('1.1', 'group.1', '59', '1');
insert into PollsChoice (choiceId, questionId, description) values ('a', '1', 'Chocolate');
insert into PollsChoice (choiceId, questionId, description) values ('b', '1', 'Strawberry');
insert into PollsChoice (choiceId, questionId, description) values ('c', '1', 'Vanilla');
insert into PollsQuestion (questionId, portletId, groupId, companyId, userId, userName, createDate, modifiedDate, title, description) values ('1', '25', '-1', 'liferay.com', 'liferay.com.1', 'John Wayne', current_timestamp, current_timestamp, 'What is your favorite ice cream flavor?', 'What is your favorite ice cream flavor?');

insert into WikiDisplay (layoutId, userId, portletId, nodeId, showBorders) values ('1.1', 'group.1', '54', '1', 't');
insert into WikiNode (nodeId, companyId, userId, userName, createDate, modifiedDate, readRoles, writeRoles, name, description, sharing, lastPostDate) values ('1', 'liferay.com', 'liferay.com.1', 'John Wayne', current_timestamp, current_timestamp, 'User,' ,'User,', 'Welcome', '', 't', current_timestamp);
insert into WikiPage (nodeId, title, version, companyId, userId, userName, createDate, content, format, head) values ('1', 'FrontPage', 1.0, 'liferay.com', 'liferay.com.1', 'John Wayne', current_timestamp, '<font class="bg" size="2">Welcome! Thank you for your interest in Liferay Enterprise Portal.<br><br>Your login is <b>test@liferay.com</b> and your password is <b>test</b>. The test user has the Administrator role.<br><br>To use the <b>Mail</b> portlet, make sure there is a mail server running on <i>localhost</i> accessible through the IMAP protocol.<br><br>The mail server must have an account with <b>liferay.com.1</b> as the user and <b>test</b> as the password.<br><br><hr><br>Is Liferay useful for your company? Tell us about it by email at <b>staff@liferay.com</b>.<br><br>We hope you enjoy our product!</font>', 'html', 't');

--
-- Default User
--

insert into User_ (userId, companyId, createDate, password_, passwordEncrypted, passwordReset, firstName, middleName, lastName, male, birthday, emailAddress, skinId, dottedSkins, roundedSkins, greeting, layoutIds, loginDate, failedLoginAttempts, agreedToTermsOfUse, active_) values ('liferay.com.default', 'default', current_timestamp, 'password', 'f', 'f', '', '', '', 't', '01/01/1970', 'default@liferay.com', '01', 'f', 'f', 'Welcome!', '', current_timestamp, 0, 'f', 't');
--
-- Test User
--

insert into User_ (userId, companyId, createDate, password_, passwordEncrypted, passwordReset, firstName, middleName, lastName, nickName, male, birthday, emailAddress, skinId, dottedSkins, roundedSkins, greeting, layoutIds, loginDate, failedLoginAttempts, agreedToTermsOfUse, active_) values ('liferay.com.1', 'liferay.com', current_timestamp, 'test', 'f', 'f', 'John', '', 'Wayne', 'Duke', 't', '01/01/1970', 'test@liferay.com', '01', 'f', 't', 'Welcome John Wayne!', '1,', current_timestamp, 0, 't', 't');
CREATE TABLE qrtz_job_details
  (
    JOB_NAME  VARCHAR(80) NOT NULL,
    JOB_GROUP VARCHAR(80) NOT NULL,
    DESCRIPTION VARCHAR(120) NULL,
    JOB_CLASS_NAME   VARCHAR(128) NOT NULL, 
    IS_DURABLE BOOL NOT NULL,
    IS_VOLATILE BOOL NOT NULL,
    IS_STATEFUL BOOL NOT NULL,
    REQUESTS_RECOVERY BOOL NOT NULL,
    JOB_DATA BYTEA NULL,
    PRIMARY KEY (JOB_NAME,JOB_GROUP)
);

CREATE TABLE qrtz_job_listeners
  (
    JOB_NAME  VARCHAR(80) NOT NULL, 
    JOB_GROUP VARCHAR(80) NOT NULL,
    JOB_LISTENER VARCHAR(80) NOT NULL,
    PRIMARY KEY (JOB_NAME,JOB_GROUP,JOB_LISTENER),
    FOREIGN KEY (JOB_NAME,JOB_GROUP) 
	REFERENCES QRTZ_JOB_DETAILS(JOB_NAME,JOB_GROUP) 
);

CREATE TABLE qrtz_triggers
  (
    TRIGGER_NAME VARCHAR(80) NOT NULL,
    TRIGGER_GROUP VARCHAR(80) NOT NULL,
    JOB_NAME  VARCHAR(80) NOT NULL, 
    JOB_GROUP VARCHAR(80) NOT NULL,
    IS_VOLATILE BOOL NOT NULL,
    DESCRIPTION VARCHAR(120) NULL,
    NEXT_FIRE_TIME BIGINT NULL,
    PREV_FIRE_TIME BIGINT NULL,
    PRIORITY INTEGER NULL,
    TRIGGER_STATE VARCHAR(16) NOT NULL,
    TRIGGER_TYPE VARCHAR(8) NOT NULL,
    START_TIME BIGINT NOT NULL,
    END_TIME BIGINT NULL,
    CALENDAR_NAME VARCHAR(80) NULL,
    MISFIRE_INSTR SMALLINT NULL,
    JOB_DATA BYTEA NULL,
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP),
    FOREIGN KEY (JOB_NAME,JOB_GROUP) 
	REFERENCES QRTZ_JOB_DETAILS(JOB_NAME,JOB_GROUP) 
);

CREATE TABLE qrtz_simple_triggers
  (
    TRIGGER_NAME VARCHAR(80) NOT NULL,
    TRIGGER_GROUP VARCHAR(80) NOT NULL,
    REPEAT_COUNT BIGINT NOT NULL,
    REPEAT_INTERVAL BIGINT NOT NULL,
    TIMES_TRIGGERED BIGINT NOT NULL,
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP),
    FOREIGN KEY (TRIGGER_NAME,TRIGGER_GROUP) 
	REFERENCES QRTZ_TRIGGERS(TRIGGER_NAME,TRIGGER_GROUP)
);

CREATE TABLE qrtz_cron_triggers
  (
    TRIGGER_NAME VARCHAR(80) NOT NULL,
    TRIGGER_GROUP VARCHAR(80) NOT NULL,
    CRON_EXPRESSION VARCHAR(80) NOT NULL,
    TIME_ZONE_ID VARCHAR(80),
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP),
    FOREIGN KEY (TRIGGER_NAME,TRIGGER_GROUP) 
	REFERENCES QRTZ_TRIGGERS(TRIGGER_NAME,TRIGGER_GROUP)
);

CREATE TABLE qrtz_blob_triggers
  (
    TRIGGER_NAME VARCHAR(80) NOT NULL,
    TRIGGER_GROUP VARCHAR(80) NOT NULL,
    BLOB_DATA BYTEA NULL,
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP),
    FOREIGN KEY (TRIGGER_NAME,TRIGGER_GROUP) 
        REFERENCES QRTZ_TRIGGERS(TRIGGER_NAME,TRIGGER_GROUP)
);

CREATE TABLE qrtz_trigger_listeners
  (
    TRIGGER_NAME  VARCHAR(80) NOT NULL, 
    TRIGGER_GROUP VARCHAR(80) NOT NULL,
    TRIGGER_LISTENER VARCHAR(80) NOT NULL,
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP,TRIGGER_LISTENER),
    FOREIGN KEY (TRIGGER_NAME,TRIGGER_GROUP) 
	REFERENCES QRTZ_TRIGGERS(TRIGGER_NAME,TRIGGER_GROUP)
);


CREATE TABLE qrtz_calendars
  (
    CALENDAR_NAME  VARCHAR(80) NOT NULL, 
    CALENDAR BYTEA NOT NULL,
    PRIMARY KEY (CALENDAR_NAME)
);


CREATE TABLE qrtz_paused_trigger_grps
  (
    TRIGGER_GROUP  VARCHAR(80) NOT NULL, 
    PRIMARY KEY (TRIGGER_GROUP)
);

CREATE TABLE qrtz_fired_triggers 
  (
    ENTRY_ID VARCHAR(95) NOT NULL,
    TRIGGER_NAME VARCHAR(80) NOT NULL,
    TRIGGER_GROUP VARCHAR(80) NOT NULL,
    IS_VOLATILE BOOL NOT NULL,
    INSTANCE_NAME VARCHAR(80) NOT NULL,
    FIRED_TIME BIGINT NOT NULL,
    PRIORITY INTEGER NOT NULL,
    STATE VARCHAR(16) NOT NULL,
    JOB_NAME VARCHAR(80) NULL,
    JOB_GROUP VARCHAR(80) NULL,
    IS_STATEFUL BOOL NULL,
    REQUESTS_RECOVERY BOOL NULL,
    PRIMARY KEY (ENTRY_ID)
);

CREATE TABLE qrtz_scheduler_state 
  (
    INSTANCE_NAME VARCHAR(80) NOT NULL,
    LAST_CHECKIN_TIME BIGINT NOT NULL,
    CHECKIN_INTERVAL BIGINT NOT NULL,
    PRIMARY KEY (INSTANCE_NAME)
);

CREATE TABLE qrtz_locks
  (
    LOCK_NAME  VARCHAR(40) NOT NULL, 
    PRIMARY KEY (LOCK_NAME)
);


INSERT INTO qrtz_locks values('TRIGGER_ACCESS');
INSERT INTO qrtz_locks values('JOB_ACCESS');
INSERT INTO qrtz_locks values('CALENDAR_ACCESS');
INSERT INTO qrtz_locks values('STATE_ACCESS');
INSERT INTO qrtz_locks values('MISFIRE_ACCESS');


CREATE TABLE QRTZ_EXCL_job_details
  (
    JOB_NAME  VARCHAR(80) NOT NULL,
    JOB_GROUP VARCHAR(80) NOT NULL,
    DESCRIPTION VARCHAR(120) NULL,
    JOB_CLASS_NAME   VARCHAR(128) NOT NULL, 
    IS_DURABLE BOOL NOT NULL,
    IS_VOLATILE BOOL NOT NULL,
    IS_STATEFUL BOOL NOT NULL,
    REQUESTS_RECOVERY BOOL NOT NULL,
    JOB_DATA BYTEA NULL,
    PRIMARY KEY (JOB_NAME,JOB_GROUP)
);

CREATE TABLE QRTZ_EXCL_job_listeners
  (
    JOB_NAME  VARCHAR(80) NOT NULL, 
    JOB_GROUP VARCHAR(80) NOT NULL,
    JOB_LISTENER VARCHAR(80) NOT NULL,
    PRIMARY KEY (JOB_NAME,JOB_GROUP,JOB_LISTENER),
    FOREIGN KEY (JOB_NAME,JOB_GROUP) 
	REFERENCES QRTZ_EXCL_JOB_DETAILS(JOB_NAME,JOB_GROUP) 
);

CREATE TABLE QRTZ_EXCL_triggers
  (
    TRIGGER_NAME VARCHAR(80) NOT NULL,
    TRIGGER_GROUP VARCHAR(80) NOT NULL,
    JOB_NAME  VARCHAR(80) NOT NULL, 
    JOB_GROUP VARCHAR(80) NOT NULL,
    IS_VOLATILE BOOL NOT NULL,
    DESCRIPTION VARCHAR(120) NULL,
    NEXT_FIRE_TIME BIGINT NULL,
    PREV_FIRE_TIME BIGINT NULL,
    PRIORITY INTEGER NULL,
    TRIGGER_STATE VARCHAR(16) NOT NULL,
    TRIGGER_TYPE VARCHAR(8) NOT NULL,
    START_TIME BIGINT NOT NULL,
    END_TIME BIGINT NULL,
    CALENDAR_NAME VARCHAR(80) NULL,
    MISFIRE_INSTR SMALLINT NULL,
    JOB_DATA BYTEA NULL,
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP),
    FOREIGN KEY (JOB_NAME,JOB_GROUP) 
	REFERENCES QRTZ_EXCL_JOB_DETAILS(JOB_NAME,JOB_GROUP) 
);

CREATE TABLE QRTZ_EXCL_simple_triggers
  (
    TRIGGER_NAME VARCHAR(80) NOT NULL,
    TRIGGER_GROUP VARCHAR(80) NOT NULL,
    REPEAT_COUNT BIGINT NOT NULL,
    REPEAT_INTERVAL BIGINT NOT NULL,
    TIMES_TRIGGERED BIGINT NOT NULL,
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP),
    FOREIGN KEY (TRIGGER_NAME,TRIGGER_GROUP) 
	REFERENCES QRTZ_EXCL_TRIGGERS(TRIGGER_NAME,TRIGGER_GROUP)
);

CREATE TABLE QRTZ_EXCL_cron_triggers
  (
    TRIGGER_NAME VARCHAR(80) NOT NULL,
    TRIGGER_GROUP VARCHAR(80) NOT NULL,
    CRON_EXPRESSION VARCHAR(80) NOT NULL,
    TIME_ZONE_ID VARCHAR(80),
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP),
    FOREIGN KEY (TRIGGER_NAME,TRIGGER_GROUP) 
	REFERENCES QRTZ_EXCL_TRIGGERS(TRIGGER_NAME,TRIGGER_GROUP)
);

CREATE TABLE QRTZ_EXCL_blob_triggers
  (
    TRIGGER_NAME VARCHAR(80) NOT NULL,
    TRIGGER_GROUP VARCHAR(80) NOT NULL,
    BLOB_DATA BYTEA NULL,
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP),
    FOREIGN KEY (TRIGGER_NAME,TRIGGER_GROUP) 
        REFERENCES QRTZ_EXCL_TRIGGERS(TRIGGER_NAME,TRIGGER_GROUP)
);

CREATE TABLE QRTZ_EXCL_trigger_listeners
  (
    TRIGGER_NAME  VARCHAR(80) NOT NULL, 
    TRIGGER_GROUP VARCHAR(80) NOT NULL,
    TRIGGER_LISTENER VARCHAR(80) NOT NULL,
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP,TRIGGER_LISTENER),
    FOREIGN KEY (TRIGGER_NAME,TRIGGER_GROUP) 
	REFERENCES QRTZ_EXCL_TRIGGERS(TRIGGER_NAME,TRIGGER_GROUP)
);

CREATE TABLE QRTZ_EXCL_calendars
  (
    CALENDAR_NAME  VARCHAR(80) NOT NULL, 
    CALENDAR BYTEA NOT NULL,
    PRIMARY KEY (CALENDAR_NAME)
);

CREATE TABLE QRTZ_EXCL_paused_trigger_grps
  (
    TRIGGER_GROUP  VARCHAR(80) NOT NULL, 
    PRIMARY KEY (TRIGGER_GROUP)
);

CREATE TABLE QRTZ_EXCL_fired_triggers 
  (
    ENTRY_ID VARCHAR(95) NOT NULL,
    TRIGGER_NAME VARCHAR(80) NOT NULL,
    TRIGGER_GROUP VARCHAR(80) NOT NULL,
    IS_VOLATILE BOOL NOT NULL,
    INSTANCE_NAME VARCHAR(80) NOT NULL,
    FIRED_TIME BIGINT NOT NULL,
    PRIORITY INTEGER NOT NULL,
    STATE VARCHAR(16) NOT NULL,
    JOB_NAME VARCHAR(80) NULL,
    JOB_GROUP VARCHAR(80) NULL,
    IS_STATEFUL BOOL NULL,
    REQUESTS_RECOVERY BOOL NULL,
    PRIMARY KEY (ENTRY_ID)
);

CREATE TABLE QRTZ_EXCL_scheduler_state 
  (
    INSTANCE_NAME VARCHAR(80) NOT NULL,
    LAST_CHECKIN_TIME BIGINT NOT NULL,
    CHECKIN_INTERVAL BIGINT NOT NULL,
    PRIMARY KEY (INSTANCE_NAME)
);

CREATE TABLE QRTZ_EXCL_locks
  (
    LOCK_NAME  VARCHAR(40) NOT NULL, 
    PRIMARY KEY (LOCK_NAME)
);

INSERT INTO QRTZ_EXCL_locks values('TRIGGER_ACCESS');
INSERT INTO QRTZ_EXCL_locks values('JOB_ACCESS');
INSERT INTO QRTZ_EXCL_locks values('CALENDAR_ACCESS');
INSERT INTO QRTZ_EXCL_locks values('STATE_ACCESS');
INSERT INTO QRTZ_EXCL_locks values('MISFIRE_ACCESS');
create table calendar_reminder (
   user_id varchar(255) not null,
   event_id varchar(100) not null,
   send_date timestamp not null,
   primary key (user_id, event_id, send_date)
);
create table ecom_product_price (
   inode varchar(100) not null,
   product_format_inode varchar(100) not null,
   min_qty int4,
   max_qty int4,
   retail_price float4 not null,
   partner_price float4 not null,
   primary key (inode)
);
create table tag (
   tagname varchar(255) not null,
   user_id varchar(255),
   primary key (tagname)
);
create table entity (
   inode varchar(100) not null,
   entity_name varchar(255),
   primary key (inode)
);
create table user_comments (
   inode varchar(100) not null,
   user_id varchar(255),
   cdate timestamp,
   comment_user_id varchar(100),
   type varchar(255),
   method varchar(255),
   subject varchar(255),
   ucomment text,
   communication_id varchar(100),
   primary key (inode)
);
create table permission_reference (
   id int8 not null,
   asset_id varchar(100),
   reference_id varchar(100),
   permission_type varchar(100),
   primary key (id),
   unique (asset_id)
);
create table fixes_audit (
   id varchar(255) not null,
   table_name varchar(255),
   action varchar(255),
   records_altered int4,
   datetime date,
   primary key (id)
);
create table trackback (
   id int8 not null,
   asset_identifier varchar(100),
   title varchar(255),
   excerpt varchar(255),
   url varchar(255),
   blog_name varchar(255),
   track_date timestamp not null,
   primary key (id)
);
create table plugin (
   id varchar(255) not null,
   plugin_name varchar(255) not null,
   plugin_version varchar(255) not null,
   author varchar(255) not null,
   first_deployed_date date not null,
   last_deployed_date date not null,
   primary key (id)
);
create table recipient (
   inode varchar(100) not null,
   name varchar(255),
   lastname varchar(255),
   email varchar(255),
   sent timestamp,
   opened timestamp,
   last_result int4,
   last_message varchar(255),
   user_id varchar(100),
   primary key (inode)
);
create table mailing_list (
   inode varchar(100) not null,
   title varchar(255),
   public_list bool,
   user_id varchar(255),
   primary key (inode)
);
create table web_form (
   web_form_id varchar(100) not null,
   form_type varchar(255),
   submit_date timestamp,
   prefix varchar(255),
   first_name varchar(255),
   middle_initial varchar(255),
   middle_name varchar(255),
   full_name varchar(255),
   organization varchar(255),
   title varchar(255),
   last_name varchar(255),
   address varchar(255),
   address1 varchar(255),
   address2 varchar(255),
   city varchar(255),
   state varchar(255),
   zip varchar(255),
   country varchar(255),
   phone varchar(255),
   email varchar(255),
   custom_fields text,
   user_inode varchar(100),
   categories varchar(255),
   primary key (web_form_id)
);
create table virtual_link (
   inode varchar(100) not null,
   title varchar(255),
   url varchar(255),
   uri varchar(255),
   active bool,
   primary key (inode)
);
create table tree (
   child varchar(100) not null,
   parent varchar(100) not null,
   relation_type varchar(64) not null,
   tree_order int4,
   primary key (child, parent, relation_type)
);
create table event (
   inode varchar(100) not null,
   title varchar(255),
   subtitle varchar(255),
   start_date timestamp,
   end_date timestamp,
   location varchar(255),
   address1 varchar(255),
   address2 varchar(255),
   address3 varchar(255),
   city varchar(255),
   state varchar(255),
   zip varchar(32),
   country varchar(64),
   email varchar(64),
   phone varchar(64),
   fax varchar(64),
   url varchar(255),
   registration bool,
   include_file varchar(255),
   show_public bool,
   contact_name varchar(255),
   contact_company varchar(255),
   contact_phone varchar(255),
   contact_email varchar(255),
   contact_fax varchar(255),
   directions text,
   description text,
   email_response text,
   web_address varchar(255),
   user_id varchar(255),
   featured bool,
   setup_date timestamp,
   break_date timestamp,
   approval_status int4,
   comments_equipment text,
   received_adm_approval bool,
   time_tbd bool,
   primary key (inode)
);
create table users_cms_roles (
   id varchar(255) not null,
   user_id varchar(100) not null,
   role_id varchar(100) not null,
   primary key (id)
);
create table web_event (
   inode varchar(100) not null,
   title varchar(255),
   subtitle varchar(255),
   summary varchar(1000),
   description varchar(255),
   terms_conditions varchar(255),
   comments varchar(255),
   partners_only bool,
   show_on_web bool,
   sort_order int4,
   event_image_1 varchar(100),
   event_image_2 varchar(100),
   event_image_3 varchar(100),
   event_image_4 varchar(100),
   is_institute bool,
   primary key (inode)
);
create table ecom_product (
   inode varchar(100) not null,
   title varchar(255) not null,
   short_description text,
   long_description text,
   req_shipping bool,
   featured bool,
   sort_order int4,
   comments text,
   showonweb bool,
   primary key (inode)
);
create table template (
   inode varchar(100) not null,
   live bool,
   working bool,
   deleted bool,
   locked bool,
   show_on_menu bool,
   title varchar(255),
   mod_date timestamp,
   mod_user varchar(100),
   sort_order int4,
   friendly_name varchar(255),
   body text,
   header text,
   footer text,
   image varchar(100),
   primary key (inode)
);
create table ecom_order_item (
   inode varchar(100) not null,
   order_inode varchar(100),
   product_inode varchar(100),
   item_qty int4,
   item_price float4,
   primary key (inode)
);
create table structure (
   inode varchar(100) not null,
   name varchar(255),
   description varchar(255),
   default_structure bool,
   review_interval varchar(255),
   reviewer_role varchar(255),
   page_detail varchar(100),
   structuretype int4,
   system bool,
   fixed bool not null,
   velocity_var_name varchar(255),
   url_map_pattern varchar(512),
   primary key (inode)
);
create table ecom_discount_code (
   inode varchar(100) not null,
   discount_type int4,
   start_date timestamp,
   end_date timestamp,
   code_id varchar(50),
   code_description varchar(100),
   free_shipping bool,
   no_bulk_disc bool,
   discount_amount float4,
   min_order int4,
   primary key (inode)
);
create table cms_role (
   id varchar(100) not null,
   role_name varchar(255) not null,
   description text,
   role_key varchar(255),
   db_fqn varchar(1000) not null,
   parent varchar(100) not null,
   edit_permissions bool,
   edit_users bool,
   edit_layouts bool,
   locked bool,
   system bool,
   primary key (id)
);
create table web_event_registration (
   inode varchar(100) not null,
   event_inode varchar(100),
   event_location_inode varchar(100),
   user_inode varchar(100),
   registration_status int4,
   date_posted timestamp,
   last_mod_date timestamp,
   total_paid float4,
   total_due float4,
   total_registration float4,
   payment_type int4,
   billing_address_1 varchar(255),
   billing_address_2 varchar(255),
   billing_city varchar(255),
   billing_state varchar(50),
   billing_zip varchar(50),
   billing_country varchar(50),
   billing_contact_name varchar(255),
   billing_contact_phone varchar(50),
   billing_contact_email varchar(255),
   card_name varchar(255),
   card_type varchar(50),
   card_number varchar(50),
   card_exp_month varchar(50),
   card_exp_year varchar(50),
   card_verification_value varchar(10),
   check_number varchar(50),
   check_bank_name varchar(255),
   po_number varchar(50),
   invoice_number varchar(50),
   badge_printed bool,
   how_did_you_hear varchar(255),
   ceo_name varchar(255),
   modified_qb bool,
   reminder_email_sent bool,
   post_email_sent bool,
   primary key (inode)
);
create table permission (
   id int8 not null,
   permission_type varchar(500),
   inode_id varchar(100),
   roleid varchar(100),
   permission int4,
   primary key (id),
   unique (permission_type, inode_id, roleid)
);
create table recurance (
   inode varchar(100) not null,
   recurrance_occurs varchar(255),
   recurrance_interval int4,
   recurrance_starting timestamp,
   recurrance_ending timestamp,
   recurrance_days_of_week varchar(255),
   recurrance_day_of_month int4,
   primary key (inode)
);
	create table contentlet (inode varchar(100) not null,
	live bool,
	working bool,
	deleted bool,
	locked bool,
	show_on_menu bool,
	title varchar(255),
	mod_date timestamp,
	mod_user varchar(100),
	sort_order int4,
	friendly_name varchar(255),
	language_id int8,
	structure_inode varchar(100),
	last_review timestamp,
	next_review timestamp,
	review_interval varchar(255),
	disabled_wysiwyg varchar(255),
	folder varchar(100),
	date1 timestamp,
	date2 timestamp,
	date3 timestamp,
	date4 timestamp,
	date5 timestamp,
	date6 timestamp,
	date7 timestamp,
	date8 timestamp,
	date9 timestamp,
	date10 timestamp,
	date11 timestamp,
	date12 timestamp,
	date13 timestamp,
	date14 timestamp,
	date15 timestamp,
	date16 timestamp,
	date17 timestamp,
	date18 timestamp,
	date19 timestamp,
	date20 timestamp,
	date21 timestamp,
	date22 timestamp,
	date23 timestamp,
	date24 timestamp,
	date25 timestamp,
	text1 varchar(255),
	text2 varchar(255),
	text3 varchar(255),
	text4 varchar(255),
	text5 varchar(255),
	text6 varchar(255),
	text7 varchar(255),
	text8 varchar(255),
	text9 varchar(255),
	text10 varchar(255),
	text11 varchar(255),
	text12 varchar(255),
	text13 varchar(255),
	text14 varchar(255),
	text15 varchar(255),
	text16 varchar(255),
	text17 varchar(255),
	text18 varchar(255),
	text19 varchar(255),
	text20 varchar(255),
	text21 varchar(255),
	text22 varchar(255),
	text23 varchar(255),
	text24 varchar(255),
	text25 varchar(255),
	text_area1 text,
	text_area2 text,
	text_area3 text,
	text_area4 text,
	text_area5 text,
	text_area6 text,
	text_area7 text,
	text_area8 text,
	text_area9 text,
	text_area10 text,
	text_area11 text,
	text_area12 text,
	text_area13 text,
	text_area14 text,
	text_area15 text,
	text_area16 text,
	text_area17 text,
	text_area18 text,
	text_area19 text,
	text_area20 text,
	text_area21 text,
	text_area22 text,
	text_area23 text,
	text_area24 text,
	text_area25 text,
	integer1 int8,
	integer2 int8,
	integer3 int8,
	integer4 int8,
	integer5 int8,
	integer6 int8,
	integer7 int8,
	integer8 int8,
	integer9 int8,
	integer10 int8,
	integer11 int8,
	integer12 int8,
	integer13 int8,
	integer14 int8,
	integer15 int8,
	integer16 int8,
	integer17 int8,
	integer18 int8,
	integer19 int8,
	integer20 int8,
	integer21 int8,
	integer22 int8,
	integer23 int8,
	integer24 int8,
	integer25 int8,
	"float1" float4,
	"float2" float4,
	"float3" float4,
	"float4" float4,
	"float5" float4,
	"float6" float4,
	"float7" float4,
	"float8" float4,
	"float9" float4,
	"float10" float4,
	"float11" float4,
	"float12" float4,
	"float13" float4,
	"float14" float4,
	"float15" float4,
	"float16" float4,
	"float17" float4,
	"float18" float4,
	"float19" float4,
	"float20" float4,
	"float21" float4,
	"float22" float4,
	"float23" float4,
	"float24" float4,
	"float25" float4,
	bool1 bool,
	bool2 bool,
	bool3 bool,
	bool4 bool,
	bool5 bool,
	bool6 bool,
	bool7 bool,
	bool8 bool,
	bool9 bool,
	bool10 bool,
	bool11 bool,
	bool12 bool,
	bool13 bool,
	bool14 bool,
	bool15 bool,
	bool16 bool,
	bool17 bool,
	bool18 bool,
	bool19 bool,
	bool20 bool,
	bool21 bool,
	bool22 bool,
	bool23 bool,
	bool24 bool,
	bool25 bool,
	primary key (inode));
create table cms_layouts_portlets (
   id varchar(255) not null,
   layout_id varchar(100) not null,
   portlet_id varchar(100) not null,
   portlet_order int4,
   primary key (id)
);
create table workflow_comment (
   inode varchar(100) not null,
   creation_date timestamp,
   posted_by varchar(255),
   wf_comment text,
   primary key (inode)
);
create table report_asset (
   inode varchar(100) not null,
   report_name varchar(255) not null,
   report_description varchar(1000) not null,
   requires_input bool,
   ds varchar(100) not null,
   web_form_report bool,
   primary key (inode)
);
create table category (
   inode varchar(100) not null,
   category_name varchar(255),
   category_key varchar(255),
   sort_order int4,
   active bool,
   keywords text,
   category_velocity_var_name varchar(255),
   primary key (inode)
);
create table htmlpage (
   inode varchar(100) not null,
   live bool,
   working bool,
   deleted bool,
   locked bool,
   show_on_menu bool,
   title varchar(255),
   mod_date timestamp,
   mod_user varchar(100),
   sort_order int4,
   friendly_name varchar(255),
   metadata text,
   start_date timestamp,
   end_date timestamp,
   page_url varchar(255),
   https_required bool,
   redirect varchar(255),
   primary key (inode)
);
create table chain_link_code (
   id int8 not null,
   class_name varchar(255) unique,
   code text not null,
   last_mod_date date not null,
   language varchar(255) not null,
   primary key (id)
);
create table language (
   id int8 not null,
   language_code varchar(5),
   country_code varchar(255),
   language varchar(255),
   country varchar(255),
   primary key (id)
);
create table user_preferences (
   id int8 not null,
   user_id varchar(100) not null,
   preference varchar(255),
   pref_value text,
   primary key (id)
);
create table users_to_delete (
   id int8 not null,
   user_id varchar(255),
   primary key (id)
);
create table identifier (
   inode varchar(100) not null,
   uri varchar(255),
   host_inode varchar(255),
   primary key (inode),
   unique (uri, host_inode)
);
create table clickstream (
   clickstream_id int8 not null,
   cookie_id varchar(255),
   user_id varchar(255),
   start_date timestamp,
   end_date timestamp,
   referer varchar(255),
   remote_address varchar(255),
   remote_hostname varchar(255),
   user_agent varchar(255),
   bot bool,
   host_id varchar(50),
   last_page_id varchar(50),
   first_page_id varchar(50),
   operating_system varchar(50),
   browser_name varchar(50),
   browser_version varchar(50),
   mobile_device bool,
   number_of_requests int4,
   primary key (clickstream_id)
);
create table web_event_location (
   inode varchar(100) not null,
   web_event_inode varchar(100),
   city varchar(255),
   state varchar(50),
   start_date timestamp,
   end_date timestamp,
   show_on_web bool,
   web_reg_active bool,
   hotel_name varchar(255),
   hotel_link int8,
   past_event_link int8,
   partner_price float4,
   non_partner_price float4,
   short_description varchar(255),
   text_email varchar(1000),
   almost_at_capacity bool,
   full_capacity bool,
   default_contract_partner_price bool,
   primary key (inode)
);
create table multi_tree (
   child varchar(100) not null,
   parent1 varchar(100) not null,
   parent2 varchar(100) not null,
   relation_type varchar(64),
   tree_order int4,
   primary key (child, parent1, parent2)
);
create table tag_inode (
   inode varchar(100) not null,
   tagname varchar(255) not null,
   primary key (inode, tagname)
);
create table workflow_task (
   inode varchar(100) not null,
   creation_date timestamp,
   mod_date timestamp,
   due_date timestamp,
   created_by varchar(255),
   assigned_to varchar(255),
   belongs_to varchar(255),
   title varchar(255),
   description text,
   status varchar(255),
   webasset varchar(255),
   primary key (inode)
);
create table click (
   inode varchar(100) not null,
   link varchar(255),
   click_count int4,
   primary key (inode)
);
create table event_registration (
   inode varchar(100) not null,
   registration_date timestamp,
   full_name varchar(255),
   number_attending int4,
   comments text,
   email varchar(255),
   primary key (inode)
);
create table challenge_question (
   cquestionid int8 not null,
   cqtext varchar(255),
   primary key (cquestionid)
);
create table file_asset (
   inode varchar(100) not null,
   file_name varchar(255),
   file_size int4,
   width int4,
   height int4,
   mime_type varchar(255),
   author varchar(255),
   publish_date timestamp,
   live bool,
   working bool,
   deleted bool,
   locked bool,
   show_on_menu bool,
   title varchar(255),
   friendly_name varchar(255),
   mod_date timestamp,
   mod_user varchar(255),
   sort_order int4,
   primary key (inode)
);
create table layouts_cms_roles (
   id varchar(255) not null,
   layout_id varchar(100) not null,
   role_id varchar(100) not null,
   primary key (id)
);
create table organization (
   inode varchar(100) not null,
   title varchar(255),
   ceo_name varchar(255),
   partner_url varchar(255),
   partner_key varchar(255),
   partner_logo varchar(100),
   street1 varchar(255),
   street2 varchar(255),
   city varchar(255),
   state varchar(255),
   zip varchar(100),
   phone varchar(100),
   fax varchar(100),
   country varchar(255),
   is_system bool,
   parent_organization varchar(100),
   primary key (inode)
);
create table facility (
   inode varchar(100) not null,
   facility_name varchar(255) not null,
   facility_description varchar(255),
   sort_order int4,
   active bool,
   primary key (inode)
);
create table clickstream_request (
   clickstream_request_id int8 not null,
   clickstream_id int8,
   server_name varchar(255),
   protocol varchar(255),
   server_port int4,
   request_uri varchar(255),
   request_order int4,
   query_string text,
   language_id int8,
   timestampper timestamp,
   host_id varchar(255),
   associated_identifier varchar(50),
   primary key (clickstream_request_id)
);
create table chain_state (
   id int8 not null,
   chain_id int8 not null,
   link_code_id int8 not null,
   state_order int8 not null,
   primary key (id)
);
create table content_rating (
   id int8 not null,
   rating float4,
   user_id varchar(255),
   session_id varchar(255),
   identifier varchar(100),
   rating_date timestamp,
   user_ip varchar(255),
   long_live_cookie_id varchar(255),
   primary key (id)
);
create table campaign (
   inode varchar(100) not null,
   title varchar(255),
   from_email varchar(255),
   from_name varchar(255),
   subject varchar(255),
   message text,
   user_id varchar(255),
   start_date timestamp,
   completed_date timestamp,
   active bool,
   locked bool,
   sends_per_hour varchar(15),
   sendemail bool,
   communicationinode varchar(100),
   userfilterinode varchar(100),
   sendto varchar(15),
   isrecurrent bool,
   wassent bool,
   expiration_date timestamp,
   parent_campaign varchar(100),
   primary key (inode)
);
create table banner (
   inode varchar(100) not null,
   title varchar(255),
   caption text,
   new_window bool,
   link varchar(255),
   start_date timestamp,
   end_date timestamp,
   body varchar(255),
   active bool,
   nmbr_views int4,
   nmbr_clicks int4,
   image varchar(100),
   path varchar(500),
   placement varchar(255),
   primary key (inode)
);
create table containers (
   inode varchar(100) not null,
   code text,
   pre_loop text,
   post_loop text,
   live bool,
   working bool,
   deleted bool,
   locked bool,
   show_on_menu bool,
   title varchar(255),
   mod_date timestamp,
   mod_user varchar(100),
   sort_order int4,
   friendly_name varchar(255),
   max_contentlets int4,
   use_div bool,
   staticify bool,
   sort_contentlets_by varchar(255),
   lucene_query text,
   notes varchar(255),
   primary key (inode)
);
create table ecom_order (
   inode varchar(100) not null,
   user_inode varchar(100),
   order_status int4,
   payment_status int4,
   date_posted timestamp,
   last_mod_date timestamp,
   billing_address1 varchar(255),
   billing_address2 varchar(255),
   billing_city varchar(100),
   billing_state varchar(50),
   billing_zip varchar(50),
   billing_country varchar(50),
   billing_phone varchar(50),
   billing_fax varchar(50),
   billing_first_name varchar(100),
   billing_last_name varchar(100),
   billing_contact_name varchar(100),
   billing_contact_phone varchar(50),
   billing_contact_email varchar(100),
   shipping_address1 varchar(255),
   shipping_address2 varchar(255),
   shipping_city varchar(50),
   shipping_state varchar(50),
   shipping_zip varchar(50),
   shipping_country varchar(50),
   shipping_phone varchar(50),
   shipping_fax varchar(50),
   payment_type varchar(10),
   name_on_card varchar(100),
   card_type varchar(50),
   card_number varchar(50),
   card_exp_month int4,
   card_exp_year int4,
   card_verification_value varchar(50),
   order_sub_total float4,
   order_shipping float4,
   order_ship_type int4,
   order_tax float4,
   order_discount float4,
   tax_exempt_number varchar(50),
   discount_codes varchar(50),
   order_total float4,
   order_total_paid float4,
   order_total_due float4,
   invoice_number varchar(50),
   invoice_date timestamp,
   check_number varchar(50),
   check_bank_name varchar(100),
   po_number varchar(50),
   tracking_number varchar(255),
   modified_qb bool,
   modified_fh bool,
   backend_user varchar(100),
   shipping_label varchar(50),
   primary key (inode)
);
create table web_event_attendee (
   inode varchar(100) not null,
   event_registration_inode varchar(100),
   first_name varchar(255),
   last_name varchar(255),
   badge_name varchar(255),
   email varchar(255),
   title varchar(255),
   registration_price float4,
   primary key (inode)
);
create table communication (
   inode varchar(100) not null,
   title varchar(255),
   trackback_link_inode varchar(100),
   communication_type varchar(255),
   from_name varchar(255),
   from_email varchar(255),
   email_subject varchar(255),
   html_page_inode varchar(100),
   text_message text,
   mod_date timestamp,
   modified_by varchar(255),
   ext_comm_id varchar(255),
   primary key (inode)
);
create table workflow_history (
   inode varchar(100) not null,
   creation_date timestamp,
   made_by varchar(255),
   change_desc text,
   primary key (inode)
);
create table host_variable (
   id varchar(255) not null,
   host_id varchar(255),
   variable_name varchar(255),
   variable_key varchar(255),
   variable_value varchar(255),
   user_id varchar(255),
   last_mod_date date,
   primary key (id)
);
create table links (
   inode varchar(100) not null,
   live bool,
   working bool,
   deleted bool,
   locked bool,
   show_on_menu bool,
   title varchar(255),
   mod_date timestamp,
   mod_user varchar(100),
   sort_order int4,
   friendly_name varchar(255),
   protocal varchar(100),
   url varchar(255),
   target varchar(100),
   internal_link_identifier varchar(100),
   link_type varchar(255),
   link_code text,
   primary key (inode)
);
create table event_recurrence (
   inode varchar(100) not null,
   occurs varchar(255),
   rec_interval int4,
   rec_starting timestamp,
   ending timestamp,
   days_of_week varchar(255),
   day_of_month int4,
   primary key (inode)
);
create table user_proxy (
   inode varchar(100) not null,
   user_id varchar(255),
   prefix varchar(255),
   suffix varchar(255),
   title varchar(255),
   school varchar(255),
   how_heard varchar(255),
   company varchar(255),
   long_lived_cookie varchar(255),
   website varchar(255),
   graduation_year int4,
   organization varchar(255),
   mail_subscription bool,
   var1 varchar(255),
   var2 varchar(255),
   var3 varchar(255),
   var4 varchar(255),
   var5 varchar(255),
   var6 varchar(255),
   var7 varchar(255),
   var8 varchar(255),
   var9 varchar(255),
   var10 varchar(255),
   var11 varchar(255),
   var12 varchar(255),
   var13 varchar(255),
   var14 varchar(255),
   var15 varchar(255),
   var16 varchar(255),
   var17 varchar(255),
   var18 varchar(255),
   var19 varchar(255),
   var20 varchar(255),
   var21 varchar(255),
   var22 varchar(255),
   var23 varchar(255),
   var24 varchar(255),
   var25 varchar(255),
   last_result int4,
   last_message varchar(255),
   no_click_tracking bool,
   cquestionid varchar(255),
   cqanswer varchar(255),
   chapter_officer varchar(255),
   primary key (inode),
   unique (user_id)
);
create table chain_state_parameter (
   id int8 not null,
   chain_state_id int8 not null,
   name varchar(255) not null,
   value varchar(255) not null,
   primary key (id)
);
create table folder (
   inode varchar(100) not null,
   name varchar(255),
   path varchar(255) not null,
   title varchar(255) not null,
   show_on_menu bool,
   sort_order int4,
   host_inode varchar(100),
   files_masks varchar(255),
   primary key (inode)
);
create table relationship (
   inode varchar(100) not null,
   parent_structure_inode varchar(255),
   child_structure_inode varchar(255),
   parent_relation_name varchar(255),
   child_relation_name varchar(255),
   relation_type_value varchar(255),
   cardinality int4,
   parent_required bool,
   child_required bool,
   fixed bool,
   primary key (inode)
);
create table field (
   inode varchar(100) not null,
   structure_inode varchar(255),
   field_name varchar(255),
   field_type varchar(255),
   field_relation_type varchar(255),
   field_contentlet varchar(255),
   required bool,
   indexed bool,
   listed bool,
   velocity_var_name varchar(255),
   sort_order int4,
   field_values text,
   regex_check varchar(255),
   hint varchar(255),
   default_value varchar(255),
   fixed bool,
   read_only bool,
   searchable bool,
   unique_ bool,
   primary key (inode)
);
create table cms_layout (
   id varchar(100) not null,
   layout_name varchar(255) not null,
   description varchar(255),
   tab_order int4,
   primary key (id)
);
create table ecom_product_format (
   inode varchar(100) not null,
   product_inode varchar(100) not null,
   format_name varchar(255) not null,
   item_num varchar(50),
   format varchar(100) not null,
   inventory_quantity int4,
   reorder_trigger int4,
   weight float4,
   width int4,
   height int4,
   depth int4,
   primary key (inode)
);
create table report_parameter (
   inode varchar(100) not null,
   report_inode varchar(100),
   parameter_description varchar(1000),
   parameter_name varchar(255),
   class_type varchar(250),
   default_value varchar(4000),
   primary key (inode),
   unique (report_inode, parameter_name)
);
create table chain (
   id int8 not null,
   key_name varchar(255) unique,
   name varchar(255) not null,
   success_value varchar(255) not null,
   failure_value varchar(255) not null,
   primary key (id)
);
create table inode (
   inode varchar(100) not null,
   owner varchar(255),
   idate timestamp,
   type varchar(64),
   identifier varchar(100),
   primary key (inode)
);
create table user_filter (
   inode varchar(100) not null,
   title varchar(255),
   firstname varchar(100),
   middlename varchar(100),
   lastname varchar(100),
   emailaddress varchar(100),
   birthdaytypesearch varchar(100),
   birthday timestamp,
   birthdayfrom timestamp,
   birthdayto timestamp,
   lastlogintypesearch varchar(100),
   lastloginsince varchar(100),
   loginfrom timestamp,
   loginto timestamp,
   createdtypesearch varchar(100),
   createdsince varchar(100),
   createdfrom timestamp,
   createdto timestamp,
   lastvisittypesearch varchar(100),
   lastvisitsince varchar(100),
   lastvisitfrom timestamp,
   lastvisitto timestamp,
   city varchar(100),
   state varchar(100),
   country varchar(100),
   zip varchar(100),
   cell varchar(100),
   phone varchar(100),
   fax varchar(100),
   active_ varchar(255),
   tagname varchar(255),
   var1 varchar(255),
   var2 varchar(255),
   var3 varchar(255),
   var4 varchar(255),
   var5 varchar(255),
   var6 varchar(255),
   var7 varchar(255),
   var8 varchar(255),
   var9 varchar(255),
   var10 varchar(255),
   var11 varchar(255),
   var12 varchar(255),
   var13 varchar(255),
   var14 varchar(255),
   var15 varchar(255),
   var16 varchar(255),
   var17 varchar(255),
   var18 varchar(255),
   var19 varchar(255),
   var20 varchar(255),
   var21 varchar(255),
   var22 varchar(255),
   var23 varchar(255),
   var24 varchar(255),
   var25 varchar(255),
   categories varchar(255),
   primary key (inode)
);
alter table ecom_product_price add constraint fkf3aa85f65fb51eb foreign key (inode) references inode;
create index idx_entity_1 on entity (entity_name);
alter table entity add constraint fkb29de3e35fb51eb foreign key (inode) references inode;
create index idx_user_comments_1 on user_comments (user_id);
alter table user_comments add constraint fkdf1b37e85fb51eb foreign key (inode) references inode;
create index idx_trackback_2 on trackback (url);
create index idx_trackback_1 on trackback (asset_identifier);
create index idx_communication_user_id on recipient (user_id);
create index idx_recipiets_1 on recipient (email);
create index idx_recipiets_2 on recipient (sent);
alter table recipient add constraint fk30e172195fb51eb foreign key (inode) references inode;
create index idx_mailinglist_1 on mailing_list (user_id);
alter table mailing_list add constraint fk7bc2cd925fb51eb foreign key (inode) references inode;
create index idx_user_webform_1 on web_form (form_type);
create index idx_virtual_link_1 on virtual_link (url);
alter table virtual_link add constraint fkd844f8ae5fb51eb foreign key (inode) references inode;
create index idx_event_2 on event (end_date);
create index idx_event_1 on event (start_date);
alter table event add constraint fk5c6729a5fb51eb foreign key (inode) references inode;
create index ix_web_event on web_event (title);
create index ix_web_event_1 on web_event (sort_order);
alter table web_event add constraint fkcfabd1ef5fb51eb foreign key (inode) references inode;
alter table ecom_product add constraint fk24a022ac5fb51eb foreign key (inode) references inode;
alter table template add constraint fkb13acc7a5fb51eb foreign key (inode) references inode;
create index ix_ecom_order_item on ecom_order_item (order_inode);
alter table ecom_order_item add constraint fkebb882875fb51eb foreign key (inode) references inode;
alter table structure add constraint fk89d2d735fb51eb foreign key (inode) references inode;
create index uk_discount_code_id on ecom_discount_code (code_id);
alter table ecom_discount_code add constraint fk994566285fb51eb foreign key (inode) references inode;
create index ix_web_event_registration_3 on web_event_registration (date_posted);
create index ix_web_event_registration_2 on web_event_registration (user_inode);
create index ix_web_event_registration_1 on web_event_registration (event_location_inode);
create index ix_web_event_registration on web_event_registration (event_inode);
alter table web_event_registration add constraint fk60025d095fb51eb foreign key (inode) references inode;
create index idx_permission_2 on permission (permission_type, inode_id);
create index idx_permission_3 on permission (roleid);
alter table recurance add constraint fk457445fc5fb51eb foreign key (inode) references inode;
alter table contentlet add constraint fkfc4ef025fb51eb foreign key (inode) references inode;
alter table workflow_comment add constraint fk94993ddf5fb51eb foreign key (inode) references inode;
alter table report_asset add constraint fk3765ec255fb51eb foreign key (inode) references inode;
create index idx_category_1 on category (category_name);
create index idx_category_2 on category (category_key);
alter table category add constraint fk302bcfe5fb51eb foreign key (inode) references inode;
alter table htmlpage add constraint fkebf39cba5fb51eb foreign key (inode) references inode;
create index idx_preference_1 on user_preferences (preference);
alter table identifier add constraint fk9f88aca95fb51eb foreign key (inode) references inode;
create index idx_user_clickstream11 on clickstream (host_id);
create index idx_user_clickstream12 on clickstream (last_page_id);
create index idx_user_clickstream15 on clickstream (browser_name);
create index idx_user_clickstream_2 on clickstream (user_id);
create index idx_user_clickstream16 on clickstream (browser_version);
create index idx_user_clickstream_1 on clickstream (cookie_id);
create index idx_user_clickstream13 on clickstream (first_page_id);
create index idx_user_clickstream14 on clickstream (operating_system);
create index ix_web_event_location_1 on web_event_location (state);
create index ix_web_event_location on web_event_location (city);
create index ix_web_event_location_3 on web_event_location (end_date);
create index ix_web_event_location_2 on web_event_location (start_date);
alter table web_event_location add constraint fk1d54bc055fb51eb foreign key (inode) references inode;
create index idx_multitree_1 on multi_tree (relation_type);
create index idx_workflow_4 on workflow_task (webasset);
create index idx_workflow_5 on workflow_task (created_by);
create index idx_workflow_2 on workflow_task (belongs_to);
create index idx_workflow_3 on workflow_task (status);
create index idx_workflow_1 on workflow_task (assigned_to);
alter table workflow_task add constraint fk441116055fb51eb foreign key (inode) references inode;
create index idx_click_1 on click (link);
alter table click add constraint fk5a5c5885fb51eb foreign key (inode) references inode;
alter table event_registration add constraint fke1516a3e5fb51eb foreign key (inode) references inode;
create index idx_file_1 on file_asset (mod_user);
alter table file_asset add constraint fk7ed2366d5fb51eb foreign key (inode) references inode;
alter table organization add constraint fk4644ed335fb51eb foreign key (inode) references inode;
alter table facility add constraint fk1dde6ea35fb51eb foreign key (inode) references inode;
create index idx_user_clickstream_request_2 on clickstream_request (request_uri);
create index idx_user_clickstream_request_1 on clickstream_request (clickstream_id);
create index idx_user_clickstream_request_3 on clickstream_request (associated_identifier);
create index idx_campaign_4 on campaign (expiration_date);
create index idx_campaign_3 on campaign (completed_date);
create index idx_campaign_2 on campaign (start_date);
create index idx_campaign_1 on campaign (user_id);
alter table campaign add constraint fkf7a901105fb51eb foreign key (inode) references inode;
alter table banner add constraint fkacc57f2c5fb51eb foreign key (inode) references inode;
alter table containers add constraint fk8a844125fb51eb foreign key (inode) references inode;
alter table ecom_order add constraint fkf088284b5fb51eb foreign key (inode) references inode;
create index ix_web_event_attendee on web_event_attendee (event_registration_inode);
create index ix_web_event_attendee_1 on web_event_attendee (first_name);
create index ix_web_event_attendee_2 on web_event_attendee (last_name);
alter table web_event_attendee add constraint fkcc5ee90a5fb51eb foreign key (inode) references inode;
alter table communication add constraint fkc24acfd65fb51eb foreign key (inode) references inode;
alter table workflow_history add constraint fk933334145fb51eb foreign key (inode) references inode;
alter table links add constraint fk6234fb95fb51eb foreign key (inode) references inode;
alter table event_recurrence add constraint fk29da39f55fb51eb foreign key (inode) references inode;
alter table user_proxy add constraint fk7327d4fa5fb51eb foreign key (inode) references inode;
create index idx_folder_1 on folder (name);
alter table folder add constraint fkb45d1c6e5fb51eb foreign key (inode) references inode;
create index idx_relationship_1 on relationship (parent_structure_inode);
create index idx_relationship_2 on relationship (child_structure_inode);
alter table relationship add constraint fkf06476385fb51eb foreign key (inode) references inode;
create index idx_field_1 on field (structure_inode);
alter table field add constraint fk5cea0fa5fb51eb foreign key (inode) references inode;
alter table ecom_product_format add constraint fk706fb8ea5fb51eb foreign key (inode) references inode;
alter table report_parameter add constraint fk22da125e5fb51eb foreign key (inode) references inode;
create index idx_index_2 on inode (identifier);
create index idx_index_1 on inode (type);
alter table user_filter add constraint fke042126c5fb51eb foreign key (inode) references inode;
create sequence user_preferences_seq;
create sequence chain_state_seq;
create sequence trackback_sequence;
create sequence language_seq;
create sequence permission_reference_seq;
create sequence chain_link_code_seq;
create sequence clickstream_seq;
create sequence content_rating_sequence;
create sequence chain_seq;
create sequence clickstream_request_seq;
create sequence user_to_delete_seq;
create sequence chain_state_parameter_seq;
create sequence permission_seq;
--postgres
CREATE INDEX idx_tree ON tree USING btree (child, parent, relation_type);
CREATE INDEX idx_tree_1 ON tree USING btree (parent);
CREATE INDEX idx_tree_2 ON tree USING btree (child);
CREATE INDEX idx_tree_3 ON tree USING btree (relation_type);
CREATE INDEX idx_tree_4 ON tree USING btree (parent, child, relation_type);
CREATE INDEX idx_tree_5 ON tree USING btree (parent, relation_type);
CREATE INDEX idx_tree_6 ON tree USING btree (child, relation_type);
CREATE INDEX idx_contentlet_1 ON contentlet USING btree (inode, live);
CREATE INDEX idx_contentlet_2 ON contentlet USING btree (inode, working);

CREATE INDEX idx_contentlet_3 ON contentlet USING btree (inode);

CREATE INDEX idx_identifier ON identifier USING btree (inode);
CREATE INDEX idx_permisision_4 ON permission USING btree (permission_type);

CREATE INDEX idx_permission_reference_2 ON permission_reference USING btree(reference_id);
CREATE INDEX idx_permission_reference_3 ON permission_reference USING btree(reference_id,permission_type);
CREATE INDEX idx_permission_reference_4 ON permission_reference USING btree(asset_id,permission_type);
CREATE INDEX idx_permission_reference_5 ON permission_reference USING btree(asset_id,reference_id,permission_type);
CREATE INDEX idx_permission_reference_6 ON permission_reference USING btree(permission_type);

CREATE UNIQUE INDEX idx_field_velocity_structure ON field (velocity_var_name,structure_inode); 
  
alter table tree add constraint FK36739EC4AB08AA foreign key (parent) references inode;
alter table tree add constraint FK36739E5A3F51C foreign key (child) references inode;

alter table chain_state add constraint fk_state_chain foreign key (chain_id) references chain(id);
alter table chain_state add constraint fk_state_code foreign key (link_code_id) references chain_link_code(id);
alter table chain_state_parameter add constraint fk_parameter_state foreign key (chain_state_id) references chain_state(id);

alter table permission add constraint permission_inode_fk foreign key (inode_id) references inode(inode);
alter table permission add constraint permission_role_fk foreign key (roleid) references cms_role(id);

alter table permission_reference add constraint permission_asset_id_fk foreign key (asset_id) references inode(inode);
alter table permission_reference add constraint permission_reference_id_fk foreign key (reference_id) references inode(inode);

alter table contentlet add constraint FK_structure_inode foreign key (structure_inode) references structure(inode);


ALTER TABLE structure ALTER fixed SET NOT NULL;
ALTER TABLE structure ALTER fixed SET DEFAULT false;

ALTER TABLE field ALTER fixed SET NOT NULL;
ALTER TABLE field ALTER fixed SET DEFAULT false;
ALTER TABLE field ALTER read_only SET NOT NULL;
ALTER TABLE field ALTER read_only SET DEFAULT false;

ALTER TABLE campaign ALTER active SET DEFAULT false;

insert into User_ (userId, companyId, createDate, password_, passwordEncrypted, passwordReset, firstName, middleName, lastName, male, birthday, emailAddress, skinId, dottedSkins, roundedSkins, greeting, layoutIds, loginDate, failedLoginAttempts, agreedToTermsOfUse, active_) values ('dotcms.org.default', 'default', current_timestamp, 'password', 'f', 'f', '', '', '', 't', '01/01/1970', 'default@dotcms.org', '01', 'f', 'f', 'Welcome!', '', current_timestamp, 0, 'f', 't');
create index addres_userid_index on address(userid);
create index tag_user_id_index on tag(user_id);
create index tag_inode_tagname on tag_inode(tagname);
create index tag_inode_inode on tag_inode(inode);
-- These two indexes are here instead of the hibernate file because Oracle by default creates an index on a unique field.  So creating an index would try to create the same index twice.
create index idx_chain_link_code_classname on chain_link_code (class_name);
create index idx_chain_key_name on chain (key_name);
CREATE TABLE dist_journal
(
  id bigserial NOT NULL,
  object_to_index character varying(1024) NOT NULL,
  serverid character varying(64),
  journal_type integer NOT NULL,
  time_entered timestamp without time zone NOT NULL,
  CONSTRAINT dist_journal_pkey PRIMARY KEY (id),
  CONSTRAINT dist_journal_object_to_index_key UNIQUE (object_to_index, serverid, journal_type)
);

create table plugin_property (
   plugin_id varchar(255) not null,
   propkey varchar(255) not null,
   original_value varchar(255) not null,
   current_value varchar(255) not null,
   primary key (plugin_id, propkey)
);
alter table plugin_property add constraint fk_plugin_plugin_property foreign key (plugin_id) references plugin(id);

CREATE TABLE dist_process ( id bigserial NOT NULL, object_to_index character varying(1024) NOT NULL, serverid character varying(64), journal_type integer NOT NULL, time_entered timestamp without time zone NOT NULL, CONSTRAINT dist_process_pkey PRIMARY KEY (id));
CREATE INDEX dist_process_index on dist_process (object_to_index, serverid,journal_type);

CREATE TABLE dist_reindex_journal
(
  id bigserial NOT NULL,
  inode_to_index character varying(100) NOT NULL,
  ident_to_index character varying(100) NOT NULL,
  serverid character varying(64),
  priority integer NOT NULL,
  time_entered timestamp without time zone NOT NULL DEFAULT CURRENT_DATE,
  index_val varchar(325),
  dist_action integer NOT NULL DEFAULT 1,
  CONSTRAINT dist_reindex_journal_pkey PRIMARY KEY (id)
);

CREATE INDEX dist_reindex_index1 on dist_reindex_journal (inode_to_index);
CREATE INDEX dist_reindex_index2 on dist_reindex_journal (dist_action);
CREATE INDEX dist_reindex_index3 on dist_reindex_journal (serverid);
CREATE INDEX dist_reindex_index on dist_reindex_journal (serverid,dist_action);


CREATE TABLE quartz_log (id bigserial NOT NULL, JOB_NAME character varying(255) NOT NULL, serverid character varying(64), time_started timestamp without time zone NOT NULL, CONSTRAINT quartz_log_pkey PRIMARY KEY (id));

alter table cms_role add CONSTRAINT cms_role_name_role_key UNIQUE (role_key);
alter table cms_role add CONSTRAINT cms_role_name_db_fqn UNIQUE (db_fqn);
alter table cms_role add constraint fkcms_role_parent foreign key (parent) references cms_role;

alter table users_cms_roles add CONSTRAINT users_cms_roles_parent1 UNIQUE (role_id,user_id);
alter table users_cms_roles add constraint fkusers_cms_roles1 foreign key (role_id) references cms_role; 
alter table users_cms_roles add constraint fkusers_cms_roles2 foreign key (user_id) references user_;
		
ALTER TABLE cms_layout add CONSTRAINT cms_layout_name_parent UNIQUE (layout_name);

alter table portlet add CONSTRAINT portlet_role_key UNIQUE (portletid);
alter table cms_layouts_portlets add CONSTRAINT cms_layouts_portlets_parent1 UNIQUE (layout_id,portlet_id);
alter table cms_layouts_portlets add constraint fkcms_layouts_portlets foreign key (layout_id) references cms_layout;

alter table layouts_cms_roles add constraint fklayouts_cms_roles1 foreign key (role_id) references cms_role; 
alter table layouts_cms_roles add constraint fklayouts_cms_roles2 foreign key (layout_id) references cms_layout;
alter table layouts_cms_roles add CONSTRAINT layouts_cms_roles_parent1 UNIQUE (role_id,layout_id);

alter table contentlet add constraint fk_folder foreign key (folder) references folder(inode);


CREATE OR REPLACE FUNCTION "boolIntResult"("intParam" integer, "boolParam" boolean)
  RETURNS boolean AS
$BODY$select case 
		WHEN $2 AND $1 != 0 then true
		WHEN $2 != true AND $1 = 0 then true
		ELSE false
	END$BODY$
  LANGUAGE 'sql' VOLATILE
;
CREATE OR REPLACE FUNCTION "intBoolResult"("boolParam" boolean, "intParam" integer)
  RETURNS boolean AS
$BODY$select case 
		WHEN $1 AND $2 != 0 then true
		WHEN $1 != true AND $2 = 0 then true
		ELSE false
	END$BODY$
  LANGUAGE 'sql' VOLATILE
 ; 
CREATE OPERATOR =(
  PROCEDURE = "intBoolResult",
  LEFTARG = bool,
  RIGHTARG = int4);
  
CREATE OPERATOR =(
  PROCEDURE = "boolIntResult",
  LEFTARG = int4,
  RIGHTARG = bool);
  
CREATE OR REPLACE FUNCTION "boolBigIntResult"("intParam" bigint, "boolParam" boolean)
  RETURNS boolean AS
$BODY$select case 
		WHEN $2 AND $1 != 0 then true
		WHEN $2 != true AND $1 = 0 then true
		ELSE false
	END$BODY$
  LANGUAGE 'sql' VOLATILE
;
CREATE OR REPLACE FUNCTION "bigIntBoolResult"("boolParam" boolean, "intParam" bigint)
  RETURNS boolean AS
$BODY$select case 
		WHEN $1 AND $2 != 0 then true
		WHEN $1 != true AND $2 = 0 then true
		ELSE false
	END$BODY$
  LANGUAGE 'sql' VOLATILE
;
CREATE OPERATOR =(
   PROCEDURE="bigIntBoolResult",
   LEFTARG=boolean,
   RIGHTARG=bigint);


CREATE OPERATOR =(
  PROCEDURE = "boolBigIntResult",
  LEFTARG = bigint,
  RIGHTARG = bool);
  
CREATE OR REPLACE FUNCTION content_work_version_check() RETURNS trigger AS '
DECLARE
	currentworkinginode varchar(100);
BEGIN
  IF tg_op = ''DELETE'' THEN
     RETURN OLD;
  END IF;
  IF tg_op = ''INSERT'' OR tg_op = ''UPDATE'' THEN
     select inode.inode into currentworkinginode from contentlet, inode where working = true and contentlet.inode = inode.inode and 
     inode.identifier = (select inode.identifier from inode where inode.inode = NEW.inode) and contentlet.language_id = NEW.language_id;
     IF FOUND AND NEW.working = true AND NEW.inode <> currentworkinginode THEN
	RAISE EXCEPTION ''Cannot insert/update multiple working versions in the contentlet table, Working inode: %'', currentworkinginode;
	RETURN NULL;
     ELSE
	RETURN NEW;
     END IF;
  END IF;

  RETURN NULL;
END
' LANGUAGE plpgsql;

CREATE TRIGGER content_work_version_trigger BEFORE INSERT OR UPDATE OR DELETE
    ON contentlet FOR EACH ROW 
    EXECUTE PROCEDURE content_work_version_check ();
  
CREATE OR REPLACE FUNCTION identifier_host_inode_check() RETURNS trigger AS '
DECLARE
	inodeType varchar(100);
BEGIN
  IF (tg_op = ''INSERT'' OR tg_op = ''UPDATE'') AND substr(NEW.uri, 0, 8) <> ''content'' AND 
		(NEW.host_inode IS NULL OR NEW.host_inode = '''') THEN
		RAISE EXCEPTION ''Cannot insert/update a null or empty host inode for this kind of identifier'';
		RETURN NULL;
  ELSE
		RETURN NEW;
  END IF;

  RETURN NULL;
END
' LANGUAGE plpgsql;

CREATE TRIGGER required_identifier_host_inode_trigger BEFORE INSERT OR UPDATE 
    ON identifier FOR EACH ROW 
    EXECUTE PROCEDURE identifier_host_inode_check ();
      
CREATE OR REPLACE FUNCTION file_asset_live_version_check()
  RETURNS trigger AS '
DECLARE    
     currentliveinode varchar(100);
BEGIN 
IF tg_op = ''DELETE'' THEN    
     RETURN OLD; 
END IF; 
IF tg_op = ''INSERT'' OR tg_op = ''UPDATE'' THEN    
     select inode.inode into currentliveinode
          from file_asset, inode
          where live = true
               and file_asset.inode = inode.inode
               and inode.identifier = (select inode.identifier from inode where inode.inode = NEW.inode);
     IF FOUND AND NEW.live = true AND NEW.inode <> currentliveinode THEN         
          RAISE EXCEPTION ''Cannot insert/update multiple live versions in the file_asset table,  inode: %'', currentliveinode;         
          RETURN NULL;    
     ELSE    
          RETURN NEW;    
     END IF;
END IF; 
RETURN NULL;
END
'  LANGUAGE plpgsql;

CREATE TRIGGER file_asset_live_version_trigger
  BEFORE INSERT OR UPDATE OR DELETE
  ON file_asset
  FOR EACH ROW
  EXECUTE PROCEDURE file_asset_live_version_check();

CREATE OR REPLACE FUNCTION content_live_version_check() 
	RETURNS trigger AS '
DECLARE
	currentliveinode varchar(100);
BEGIN
IF tg_op = ''DELETE'' THEN
     RETURN OLD;
END IF;
IF tg_op = ''INSERT'' OR tg_op = ''UPDATE'' THEN
	select inode.inode into currentliveinode from contentlet, inode where live = true and contentlet.inode = inode.inode and
		inode.identifier = (select inode.identifier from inode where inode.inode = NEW.inode) and contentlet.language_id = NEW.language_id;
	IF FOUND AND NEW.live = true AND NEW.inode <> currentliveinode THEN
		RAISE EXCEPTION ''Cannot insert/update multiple live versions in the contentlet table,  inode: %'', currentliveinode;
		RETURN NULL;
	ELSE
		RETURN NEW;
	END IF;
END IF;
RETURN NULL;
END
' LANGUAGE plpgsql;
				
CREATE TRIGGER content_live_version_trigger 
	BEFORE INSERT OR UPDATE OR DELETE
	ON contentlet FOR EACH ROW
	EXECUTE PROCEDURE content_live_version_check();
	
create table import_audit (
	id bigint not null,
	start_date timestamp,
	userid varchar(255), 
	filename varchar(512),
	status int,
	last_inode varchar(100),
	records_to_import bigint,
	serverid varchar(255),
	primary key (id)
	);
	
alter table category alter column category_velocity_var_name set not null;
